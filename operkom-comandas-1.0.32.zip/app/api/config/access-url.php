<?php
/** GET /api/config/access-url.php — devuelve la ruta LAN para compartir la aplicación. */
require_once dirname(__DIR__) . '/helpers/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

function isUsableNetworkHost(string $host): bool
{
    if ($host === '' || in_array(strtolower($host), ['localhost', 'localhost.localdomain'], true)) {
        return false;
    }
    if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return !str_starts_with($host, '127.') && $host !== '0.0.0.0';
    }
    if (filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        return $host !== '::1' && $host !== '::';
    }
    return false;
}

function normalizeHost(string $value): string
{
    $value = trim($value);
    if (str_starts_with($value, '[')) {
        $end = strpos($value, ']');
        return $end === false ? '' : substr($value, 1, $end - 1);
    }
    return preg_replace('/:\d+$/', '', $value) ?: '';
}

function isPrivateIpv4(string $host): bool
{
    if (!filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return false;
    $parts = array_map('intval', explode('.', $host));
    return $parts[0] === 10
        || ($parts[0] === 172 && $parts[1] >= 16 && $parts[1] <= 31)
        || ($parts[0] === 192 && $parts[1] === 168);
}

$requestHost = normalizeHost((string) ($_SERVER['HTTP_HOST'] ?? ''));
$resolvedHosts = gethostbynamel(gethostname()) ?: [];
$candidates = array_merge([
    normalizeHost((string) ($_SERVER['SERVER_ADDR'] ?? '')),
], $resolvedHosts);

// Al abrir la app como localhost, prioriza una IP privada de la LAN sobre
// adaptadores VPN (por ejemplo, Hamachi) o interfaces virtuales.
usort($candidates, static function (string $a, string $b): int {
    return (int) isPrivateIpv4($b) <=> (int) isPrivateIpv4($a);
});
if (isUsableNetworkHost($requestHost)) {
    array_unshift($candidates, $requestHost);
}

$host = '';
foreach ($candidates as $candidate) {
    if (isUsableNetworkHost($candidate)) {
        $host = $candidate;
        break;
    }
}

if ($host === '') {
    sendError('No se encontró una dirección IP de red. Verifica que el equipo esté conectado al Wi-Fi.', 503);
}

$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$port = (int) ($_SERVER['SERVER_PORT'] ?? ($scheme === 'https' ? 443 : 80));
$scriptPath = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
$appPath = rtrim(dirname(dirname(dirname($scriptPath))), '/');
$hostForUrl = str_contains($host, ':') ? "[$host]" : $host;
$url = sprintf('%s://%s:%d%s/', $scheme, $hostForUrl, $port, $appPath);

sendSuccess([
    'url' => $url,
    'host' => $host,
    'port' => $port,
]);
