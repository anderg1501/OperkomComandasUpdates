# Manual de mantenimiento — Operkom Comandas

> Documento operativo para desarrollar, publicar, instalar, actualizar y dar
> soporte a Operkom Comandas. Mantenerlo actualizado junto con el código.

## 1. Propósito y repositorios

Operkom Comandas es una aplicación web local para la toma de pedidos. Cada
cliente instala Apache y PHP propios; la aplicación se conecta a la base de
datos que ya administra el sistema administrativo del cliente. La aplicación
no instala ni gestiona MariaDB.

Hay **dos repositorios distintos**, con responsabilidades diferentes:

| Repositorio | Dirección | Responsabilidad |
| --- | --- | --- |
| Código fuente | [anderg1501/ComandasWeb](https://github.com/anderg1501/ComandasWeb) | Código de la aplicación, API, instalador, actualizador y documentación. |
| Paquetes de actualización | [anderg1501/OperkomComandasUpdates](https://github.com/anderg1501/OperkomComandasUpdates) | Archivo ZIP de cada actualización y el manifiesto `update.json` que consultan los clientes. |

No confundir ambos repositorios. El primero es la fuente de verdad del código.
El segundo es el canal de distribución de actualizaciones.

## 2. Arquitectura

```text
Teléfono / PC de la LAN
          │  http://IP-DEL-SERVIDOR:17820/
          ▼
Apache + PHP (servicio Windows OperkomComandas)
          │
          ├── app/              Interfaz HTML/JS y API PHP actualizable
          ├── ProgramData/      Configuración local persistente del cliente
          ├── Base de datos     Del sistema administrativo del cliente
          └── Servicio 9000     Servicio externo de impresión de comandas
```

### Componentes del código fuente

| Ruta | Contenido |
| --- | --- |
| `index.html` | Estructura de la interfaz y carga de recursos JavaScript/CSS. |
| `assets/js/` | Estado, enrutamiento, llamadas a API y vistas de login, mesas, pedido y configuración. |
| `assets/css/` | Estilos propios y CSS generado por Tailwind. |
| `api/` | Endpoints PHP, autenticación, configuración, pedidos, comandas y actualizaciones. |
| `updater/Update-OperkomComandas.ps1` | Actualizador que ejecutan los equipos instalados. |
| `release/publish-update.ps1` | Empaqueta y publica actualizaciones de código. |
| `installer/` | Plantillas Apache/PHP, runtime, lanzador y proyecto de Inno Setup. |
| `release/build-installer.ps1` | Genera el EXE instalable. |
| `docs/` | Documentación técnica y operativa. |

### Servicio de impresión

La aplicación envía las comandas al servicio local `http://127.0.0.1:9000/print`.
Ese servicio es externo a este repositorio. El formato físico del ticket (fuente,
negrita, tono, tamaño o diseño de las notas) se controla en dicho servicio, no
en HTML, CSS ni PHP de Operkom Comandas. Para modificar la impresión se requiere
el código o proyecto de ese servicio.

## 3. Instalación en el cliente

El instalador instala el producto en estas ubicaciones:

| Elemento | Ruta / valor |
| --- | --- |
| Aplicación, Apache, PHP y actualizador | `C:\Program Files\Operkom\Comandas` |
| Aplicación actualizable | `C:\Program Files\Operkom\Comandas\app` |
| Configuración persistente | `C:\ProgramData\Operkom\Comandas\config\config.local.php` |
| Estado del actualizador | `C:\ProgramData\Operkom\Comandas\update-status.json` |
| Trabajo temporal del actualizador | `C:\ProgramData\Operkom\Comandas\update-work` |
| Servicio Windows | `OperkomComandas` |
| Puerto HTTP | `17820` |
| URL local | `http://127.0.0.1:17820/` |
| URL LAN | `http://IP-DEL-SERVIDOR:17820/` |

El instalador valida Microsoft Visual C++ Redistributable x64 14.50.35719 o
posterior, requerido por Apache. Si no está instalado, lo descarga desde el
enlace oficial de Microsoft, comprueba su SHA-256 y lo instala antes de copiar
Comandas. Esto mantiene pequeño el instalador principal; un equipo nuevo debe
tener Internet durante esa primera instalación.

Apache escucha en `0.0.0.0:17820`. El instalador agrega la regla de Firewall
`Operkom Comandas (LAN)` para TCP 17820, en todos los perfiles de red, pero
solo para la subred local (`RemoteIP=LocalSubnet`).

### Primera configuración

El asistente inicial solicita:

- Host, puerto, nombre, usuario y contraseña de la base de datos.
- Zona horaria.
- Segmentos de red autorizados para abrir el asistente desde la LAN.

Antes de guardar, valida la conexión y la existencia de la base. Las
credenciales se escriben fuera de `app/`; por eso una actualización o una
reinstalación no las debe reemplazar.

`ALLOWED_SEGMENTS` permite el asistente desde segmentos concretos, por ejemplo
`192.168.1,192.168.20`. No controla el uso normal de la aplicación: solo el
acceso al setup de red.

### Validación posterior a una instalación

En el servidor, abrir PowerShell como administrador:

```powershell
Get-Service OperkomComandas
Get-NetTCPConnection -LocalPort 17820 -State Listen
netsh advfirewall firewall show rule name="Operkom Comandas (LAN)" verbose
```

Desde otro equipo de la misma red:

```powershell
Test-NetConnection IP-DEL-SERVIDOR -Port 17820
```

Debe devolver `TcpTestSucceeded : True`. Si no ocurre, confirmar que ambos
equipos estén en la misma LAN y que no sea una red Wi-Fi de invitados ni tenga
aislamiento entre clientes.

## 4. Seguridad y datos que nunca se deben publicar

No subir al repositorio ni incluir en paquetes de actualización:

- `api/config/config.local.php`.
- `C:\ProgramData\Operkom\Comandas\config\config.local.php`.
- Contraseñas, tokens, copias de bases de datos o archivos de sesión.
- `api/sessions/`, `node_modules/`, `installer/payload/`, `installer/output/`
  o `release/.work/`.

El publicador de actualizaciones excluye automáticamente configuración local,
sesiones, `node_modules`, `installer`, `updater` y `release`. Aun así, revisar
siempre el contenido antes de publicar.

Al solicitar registros a un cliente, pedir que oculte contraseñas, cadenas de
conexión y datos personales antes de compartirlos.

## 5. Preparar el entorno de desarrollo

### Requisitos

- Git.
- PowerShell 5.1 o superior.
- Node.js para regenerar Tailwind cuando cambie CSS fuente.
- Inno Setup 6 únicamente para crear instaladores.
- Acceso de escritura a ambos repositorios GitHub.

Clonar el código fuente:

```powershell
git clone https://github.com/anderg1501/ComandasWeb.git
cd ComandasWeb
npm install
```

Clonar también el repositorio de actualizaciones, preferiblemente como carpeta
hermana del código fuente:

```powershell
git clone https://github.com/anderg1501/OperkomComandasUpdates.git
```

Ejemplo de estructura recomendada:

```text
D:\proyectos\
├── ComandasWeb\
└── OperkomComandasUpdates\
```

### Estado Git antes de trabajar

Antes de cambiar código:

```powershell
git status
git pull origin main
git -C ..\OperkomComandasUpdates pull origin main
```

Trabajar en una rama para cambios no triviales:

```powershell
git switch -c codex/descripcion-del-cambio
```

No publicar cambios de otra persona sin revisarlos. Si el árbol de trabajo ya
tiene modificaciones, identificar cuáles pertenecen a la tarea actual antes de
editar o hacer `commit`.

## 6. Tipos de cambios y método correcto de despliegue

| Tipo de cambio | Ejemplos | Despliegue |
| --- | --- | --- |
| Solo aplicación | HTML, JavaScript, CSS, endpoints PHP, lógica de pedidos | Actualización automática. |
| CSS generado | Cambio en `tailwind.input.css` o configuración Tailwind | Regenerar CSS y publicar actualización. |
| Configuración local | Host/puerto de BD, usuario, contraseña, zona horaria, segmentos | Usar el asistente de Configuración; nunca publicar un ZIP. |
| Runtime o servidor | Apache, PHP, extensiones, `httpd.conf`, Firewall, puerto, lanzador, servicio Windows | Nuevo instalador. |
| Actualizador | `updater/`, tarea programada, ruta ProgramData o reglas de rollback | Nuevo instalador; los ZIP no incluyen `updater/`. |
| Servicio de impresión | Diseño del ticket, tono de notas, drivers o puerto 9000 | Proyecto/instalador propio del servicio de impresión. |
| Esquema de BD | Nuevas tablas, columnas, índices o cambios de compatibilidad | Plan de migración y respaldo de BD; no asumir que todas las bases de clientes tienen el mismo esquema. |

Regla principal: una actualización reemplaza solo
`C:\Program Files\Operkom\Comandas\app`. No reemplaza Apache, PHP, el
actualizador ni la configuración de ProgramData.

## 7. Versionado

Usar versiones `MAYOR.MENOR.PARCHE`, por ejemplo `1.0.19`.

- **MAYOR**: cambio incompatible o migración relevante.
- **MENOR**: función importante compatible.
- **PARCHE**: corrección o mejora pequeña compatible.

Antes de publicar, actualizar de forma consistente:

1. `app-version.json` — fuente de versión para el publicador y el actualizador.
2. `package.json` — referencia de desarrollo.
3. Etiquetas y parámetros `?v=` en `index.html` — versión visible y limpieza de
   caché de recursos estáticos.

Comprobación útil:

```powershell
rg -n "1\.0\.19" app-version.json package.json index.html
```

Reemplazar `1.0.19` por la versión que se vaya a publicar. No reutilizar una
versión: el actualizador instala solo versiones estrictamente superiores.

## 8. Flujo de una actualización automática

### 8.1 Desarrollar y validar

1. Aplicar el cambio en el código fuente.
2. Si se modificó `assets/css/tailwind.input.css`, regenerar:

   ```powershell
   npm run build:css
   ```

3. Validar JavaScript modificado:

   ```powershell
   node --check .\assets\js\views\pedido.js
   ```

4. Validar PHP modificado. Si no hay PHP global en desarrollo, se puede usar el
   runtime ya preparado, sin cargar su configuración:

   ```powershell
   .\installer\payload\runtime\php\php.exe -n -l .\api\pedidos\activar-mesa.php
   ```

5. Probar el flujo funcional en una base de pruebas. Una validación de sintaxis
   no reemplaza una prueba de login, mesas, creación de pedido y envío de
   comandas.
6. Cambiar la versión siguiendo la sección 7.

### 8.2 Empaquetar y publicar

Desde la raíz de `ComandasWeb`:

```powershell
.\release\publish-update.ps1 `
  -UpdateRepositoryPath 'D:\ruta\OperkomComandasUpdates' `
  -Publish
```

El script hace lo siguiente:

1. Lee la versión desde `app-version.json`.
2. Crea `operkom-comandas-VERSION.zip` en el repositorio de actualizaciones.
3. Incluye una carpeta `app/` con solo el código distribuible.
4. Calcula SHA-256.
5. Actualiza `update.json` con versión, URL HTTPS, hash y fecha UTC.
6. Con `-Publish`, ejecuta `git add`, `git commit` y `git push origin main` en
   **OperkomComandasUpdates**.

El comando no hace `commit` del repositorio fuente. Después de verificar el
paquete, confirmar también el código fuente:

```powershell
git add app-version.json package.json index.html assets api docs
git commit -m "Publicar versión 1.0.19"
git push origin main
```

Ajustar la lista de archivos si el cambio incluyó otras rutas. Revisar primero
con `git status` y `git diff --stat`.

### 8.3 Verificar el release publicado

En el repositorio de actualizaciones deben existir:

- `operkom-comandas-VERSION.zip`.
- `update.json` con la misma versión y el SHA-256 del ZIP.

Desde un cliente, entrar como administrador en **Configuración → Buscar
actualización**. La instalación exige autorización administrativa. Los usuarios
autenticados reciben una notificación de versión disponible, pero no pueden
instalarla sin dicha autorización.

## 9. Qué sucede dentro del actualizador

El endpoint `api/updates/start.php` crea y ejecuta la tarea programada
`OperkomComandasUpdate` como `SYSTEM`. Se usa una tarea independiente porque
Apache debe detenerse durante el cambio y un proceso hijo del servicio podría
finalizar al mismo tiempo.

El script `updater/Update-OperkomComandas.ps1`:

1. Descarga `update.json` mediante la API de GitHub.
2. Comprueba que la nueva versión sea superior a la instalada.
3. Descarga el ZIP por HTTPS y verifica SHA-256.
4. Detiene el servicio `OperkomComandas`.
5. Renombra `app` a `app.previous`.
6. Instala el nuevo `app`.
7. Inicia el servicio otra vez.
8. Elimina el respaldo temporal si todo funciona.

Si el servicio no inicia tras cambiar `app`, intenta restaurar `app.previous`.
Ese rollback solo cubre una falla durante la actualización; no sustituye una
política de respaldos ni una estrategia de reversión de versiones.

Consultar el estado de una actualización en el servidor:

```powershell
Get-Content "C:\ProgramData\Operkom\Comandas\update-status.json"
Get-ScheduledTask -TaskName OperkomComandasUpdate
Get-Service OperkomComandas
```

## 10. Crear un instalador completo

Usar instalador solo cuando sea necesario según la sección 6.

### 10.1 Generación normal

Instalar [Inno Setup 6](https://jrsoftware.org/isdl.php) y, desde la raíz del
proyecto, ejecutar:

```powershell
.\release\build-installer.ps1
```

El comando obtiene la versión de `app-version.json`, prepara el runtime,
compila con Inno Setup y muestra el SHA-256 del resultado.

Para una versión concreta:

```powershell
.\release\build-installer.ps1 -Version 1.0.20
```

Opciones:

| Opción | Uso |
| --- | --- |
| `-CleanRuntime` | Descarga nuevamente Apache y PHP y verifica sus hashes. Usar si se actualizó `runtime-manifest.json` o el runtime está corrupto. |
| `-SkipRuntimePreparation` | Recompila rápido utilizando un `installer/payload/` ya preparado. No usar si cambió el runtime, el lanzador o las plantillas. |

El archivo final queda en:

```text
installer\output\OperkomComandas-Setup-VERSION.exe
```

### 10.2 Validar antes de distribuir

Después de preparar el runtime, ejecutar:

```powershell
.\installer\test-runtime.ps1
Get-FileHash .\installer\output\OperkomComandas-Setup-VERSION.exe -Algorithm SHA256
```

`test-runtime.ps1` valida la sintaxis Apache e inicia temporalmente Apache,
PHP y la API. Antes de publicar una descarga pública, probar además una
instalación limpia en una máquina virtual o equipo de pruebas.

### 10.3 Personalización del instalador

El proyecto de Inno Setup es `installer/operkom-comandas.iss`. Permite cambiar
nombre, editor, accesos directos, archivos incluidos, tareas y lógica avanzada.
Abrirlo con **Inno Setup Compiler** y usar **Compile / F9** para revisar el
proyecto visualmente.

Cambios en puerto, nombre del servicio, rutas ProgramData o actualizador deben
tratarse como cambios de arquitectura: están relacionados con el lanzador,
plantillas Apache, actualizador, API y pruebas. Documentar y validar todos los
componentes antes de modificar esos valores.

## 11. Base de datos y compatibilidad

La aplicación usa tablas del sistema administrativo, entre ellas:

- `restaurant_detalle_mesas` y áreas relacionadas.
- `factura_espera` y `detalle_factura_espera`.
- `clientes`, inventario y configuración de restaurante.

No asumir que todos los clientes tienen una estructura idéntica. Los campos de
`factura_espera`, por ejemplo, pueden diferir entre instalaciones. Antes de
introducir una columna obligatoria:

1. Consultar el esquema en una base de pruebas representativa.
2. Mantener compatibilidad cuando sea razonable.
3. Si es necesaria una migración, preparar SQL idempotente, respaldo y plan de
   reversión.
4. Probar con datos reales anonimizados.

La creación de comandas inicia la cabecera con el cliente `CONSUMIDOR FINAL`.
Si el cliente no existe, debe crearse en la base administrativa antes de usar
la aplicación.

## 12. Diagnóstico y soporte

### La aplicación no abre en el servidor

```powershell
Get-Service OperkomComandas
Get-NetTCPConnection -LocalPort 17820 -State Listen
Get-Content "C:\Program Files\Operkom\Comandas\runtime\apache\logs\error.log" -Tail 80
```

Si el servicio está detenido:

```powershell
Start-Service OperkomComandas
```

### No abre desde otro equipo

1. Comprobar `Test-NetConnection IP-DEL-SERVIDOR -Port 17820` desde el equipo
   auxiliar.
2. Confirmar que Apache escucha en `0.0.0.0:17820`.
3. Consultar la regla `Operkom Comandas (LAN)`.
4. Revisar red de invitados, VLAN o aislamiento Wi-Fi.
5. Usar la URL raíz `http://IP-DEL-SERVIDOR:17820/`; no agregar
   `/comandasweb`.

### Error `could not find driver`

El PHP instalado no tiene cargado `pdo_mysql`. Validar la instalación con
`installer/test-runtime.ps1` antes de distribuir un instalador y revisar el
`php.ini` del runtime instalado. Este caso normalmente requiere instalador,
porque modifica el runtime PHP.

### Error HTTP 500 de un endpoint

1. Abrir DevTools → Network y seleccionar la petición fallida.
2. Guardar URL, código HTTP y cuerpo JSON de respuesta.
3. En el servidor, extraer las últimas líneas de Apache:

   ```powershell
   Get-Content "C:\Program Files\Operkom\Comandas\runtime\apache\logs\error.log" -Tail 80
   ```

4. Ocultar secretos antes de compartir el registro.
5. No corregir a ciegas una diferencia de esquema: identificar la tabla o
   columna exacta y crear una prueba de compatibilidad.

### Actualización no aparece o no termina

```powershell
Get-Content "C:\ProgramData\Operkom\Comandas\update-status.json"
Get-ScheduledTask -TaskName OperkomComandasUpdate
Get-Service OperkomComandas
```

Comprobar conectividad a GitHub, que `update.json` tenga una versión superior y
que el hash coincida. Una recarga forzada del navegador puede ser necesaria
solo para cargar recursos estáticos nuevos; no reemplaza una actualización del
servidor.

## 13. Reversión y contingencia

### Durante una actualización fallida

El actualizador restaura automáticamente `app.previous` si no puede iniciar el
servicio tras el cambio. Consultar `update-status.json` y el log de Apache.

### Después de publicar una versión defectuosa

No bajar la versión en `update.json`: los clientes comparan versiones y no
instalarán una versión menor. La corrección recomendada es:

1. Recuperar el código de la última versión funcional en el repositorio fuente.
2. Crear una nueva versión superior, por ejemplo `1.0.21`.
3. Probarla.
4. Publicarla normalmente.

Conservar los ZIP históricos y commits del repositorio de actualizaciones. Son
necesarios para reconstruir o auditar una versión anterior.

### Respaldo de cliente

Antes de cambios de base de datos o reinstalaciones mayores:

- Respaldar la base administrativa según su procedimiento oficial.
- Copiar de forma segura `C:\ProgramData\Operkom\Comandas\config\`.
- Registrar versión actual, IP/puerto y estado del servicio.

## 14. Checklist de publicación

### Actualización de código

- [ ] El cambio está probado en una mesa/pedido real de pruebas.
- [ ] JavaScript y PHP modificados pasan validación de sintaxis.
- [ ] Tailwind fue regenerado si correspondía.
- [ ] La versión fue incrementada en todos los archivos visibles.
- [ ] No hay credenciales, sesiones ni archivos generados dentro del paquete.
- [ ] Se ejecutó `publish-update.ps1 -Publish`.
- [ ] Se verificó `update.json`, el ZIP y SHA-256 en el repositorio de updates.
- [ ] Se confirmó el `commit` y `push` del repositorio fuente.
- [ ] Un cliente de prueba actualizó correctamente y muestra la nueva versión.

### Instalador

- [ ] El cambio realmente requiere instalador.
- [ ] `app-version.json` contiene la versión final.
- [ ] Apache/PHP fueron preparados y sus hashes validados.
- [ ] `installer/test-runtime.ps1` pasó.
- [ ] El EXE tiene hash SHA-256 registrado.
- [ ] Se realizó instalación limpia de prueba.
- [ ] Se validaron servicio, acceso local, LAN, configuración inicial y
  preservación de ProgramData al reinstalar.

## 15. Referencia rápida de comandos

```powershell
# Estado del código fuente
git status
git pull origin main

# Regenerar CSS
npm run build:css

# Publicar actualización de código
.\release\publish-update.ps1 `
  -UpdateRepositoryPath 'D:\ruta\OperkomComandasUpdates' `
  -Publish

# Crear instalador
.\release\build-installer.ps1

# Validar runtime del instalador
.\installer\test-runtime.ps1

# Diagnóstico de un cliente
Get-Service OperkomComandas
Get-NetTCPConnection -LocalPort 17820 -State Listen
Get-Content "C:\Program Files\Operkom\Comandas\runtime\apache\logs\error.log" -Tail 80
Get-Content "C:\ProgramData\Operkom\Comandas\update-status.json"
```

## 16. Licenciamiento remoto

El panel central forma parte del portal de soporte `SoporteOPK`, en la vista
`comandasLicencias`. La aplicación local consulta el endpoint HTTPS
`/api/check.php` del mismo portal. No existe un panel administrativo dentro del
repositorio o del instalador de Comandas.

En producción, la URL configurada en el cliente debe ser la raíz del portal,
por ejemplo `https://soporte.operkom.com`, sin agregar `/api/check.php`.

### Alta de un cliente

1. Entra al portal de soporte con el permiso `gestionar_licencias_comandas` y
   abre **Licencias Comandas**.
2. Copia la clave mostrada; no vuelve a mostrarse porque el servidor conserva
   únicamente su hash SHA-256.
3. En el servidor del cliente abre **Configuración → Configurar conexión**.
4. En **Licencia remota** registra la clave. La URL de Soporte es fija y no se
   solicita al usuario.
5. Al guardar, la clave se valida inmediatamente contra el documento fiscal o,
   cuando no existe, contra el nombre de la empresa de la base seleccionada.

El cliente consulta cada cinco minutos. El panel muestra versión, equipo, base
reportada, IP, último contacto y estado. Bloquear o reactivar una empresa tarda
como máximo el intervalo de consulta. Un bloqueo confirmado no entra en gracia.

Cada intento de inicio de sesión fuerza además una validación remota y registra
en el panel central el código y nombre del usuario, el resultado, equipo, base,
IP y versión. El PIN nunca se transmite ni se almacena en el portal.

Si el servidor remoto no responde, una licencia que estaba activa continúa por
72 horas. Al agotarse ese período, los endpoints operativos responden con
`LICENSE_UNREACHABLE`; la configuración y las actualizaciones siguen accesibles
para facilitar la recuperación.

Los estados negativos no se conservan en caché: una licencia desbloqueada se
consulta nuevamente en la siguiente petición. Los estados activos sí utilizan
la caché y el período de gracia para mantener la operación sin Internet.

Las instalaciones sin URL o clave quedan en estado `unconfigured` y no pueden
utilizar los endpoints operativos. La configuración y las actualizaciones
permanecen disponibles para registrar la licencia o recuperar el equipo.

El estado local se guarda en:

```text
C:\ProgramData\Operkom\Comandas\license-state.json
```

El licenciamiento impide el uso normal y ofrece control comercial centralizado,
pero no pretende ser DRM invulnerable frente a una persona con privilegios de
administrador y capacidad de modificar el código instalado.

---

Última revisión: 2026-11-03. Actualizar esta guía cada vez que cambien las
rutas, repositorios, servicio de impresión, mecanismo de actualización o
proceso de instalación.
