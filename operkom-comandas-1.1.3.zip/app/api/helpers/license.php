<?php
/**
 * Control de licencia de la instalación local.
 *
 * El servidor remoto es la autoridad. La última respuesta se conserva fuera
 * de app/ para soportar cortes breves de Internet sin detener el restaurante.
 * Una respuesta explícita de bloqueo nunca usa el período de gracia.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/config-paths.php';
require_once dirname(__DIR__) . '/config/database.php';

function licenseStatePath(): string
{
    return getPersistentDataDirectory() . DIRECTORY_SEPARATOR . 'license-state.json';
}

function licenseIsConfigured(): bool
{
    return trim((string) LICENSE_KEY) !== '';
}

function licenseReadState(): array
{
    $path = licenseStatePath();
    if (!is_file($path)) {
        return [];
    }

    $raw = @file_get_contents($path);
    $state = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($state) ? $state : [];
}

function licenseWriteState(array $state): void
{
    $path = licenseStatePath();
    $directory = dirname($path);
    if (!is_dir($directory)) {
        @mkdir($directory, 0750, true);
    }

    $temporary = $path . '.tmp.' . bin2hex(random_bytes(4));
    $encoded = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (@file_put_contents($temporary, $encoded, LOCK_EX) !== false) {
        @chmod($temporary, 0640);
        if (is_file($path)) {
            @unlink($path);
        }
        @rename($temporary, $path);
    } else {
        @unlink($temporary);
    }
}

function licenseInstallationId(array $state): string
{
    $existing = trim((string) ($state['installation_id'] ?? ''));
    if (preg_match('/^[a-f0-9]{32}$/', $existing)) {
        return $existing;
    }
    return bin2hex(random_bytes(16));
}

function licenseAppVersion(): string
{
    $path = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'app-version.json';
    $raw = is_file($path) ? @file_get_contents($path) : false;
    $data = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($data) && !empty($data['version']) ? (string) $data['version'] : 'unknown';
}

function licenseConfigFingerprint(?string $licenseKey = null): string
{
    return hash('sha256', LICENSE_SERVICE_URL . "\n" . trim($licenseKey ?? (string) LICENSE_KEY));
}

function licenseLimitText($value, int $maxLength): string
{
    $text = trim((string) $value);
    return function_exists('mb_substr')
        ? mb_substr($text, 0, $maxLength, 'UTF-8')
        : substr($text, 0, $maxLength);
}

function licenseBuildCompanyIdentity(array $company): array
{
    $taxIds = [];
    foreach (['nit', 'rif', 'idfiscal1'] as $field) {
        $value = licenseLimitText($company[$field] ?? '', 80);
        if ($value !== '' && !in_array($value, $taxIds, true)) {
            $taxIds[] = $value;
        }
    }
    return [
        'company_name' => licenseLimitText($company['empresa'] ?? '', 180),
        'company_tax_ids' => $taxIds,
    ];
}

function licenseLocalCompanyIdentity(): array
{
    try {
        $company = getDB()->query(
            'SELECT empresa, nit, rif, idfiscal1 FROM confg_empresa LIMIT 1'
        )->fetch(PDO::FETCH_ASSOC);
        return licenseBuildCompanyIdentity(is_array($company) ? $company : []);
    } catch (Throwable $exception) {
        error_log('No fue posible leer la identidad empresarial para validar la licencia: ' . $exception->getMessage());
        return ['company_name' => '', 'company_tax_ids' => []];
    }
}

function licenseCheckRemote(
    string $installationId,
    array $loginAttempt = [],
    ?string $licenseKey = null,
    ?array $companyIdentity = null
): array
{
    $baseUrl = rtrim(LICENSE_SERVICE_URL, '/');
    $parts = parse_url($baseUrl);
    $scheme = is_array($parts) ? strtolower((string) ($parts['scheme'] ?? '')) : '';
    $host = is_array($parts) ? strtolower((string) ($parts['host'] ?? '')) : '';
    $isLocal = in_array($host, ['localhost', '127.0.0.1', '::1'], true);
    if (!is_array($parts) || !isset($parts['host'])
        || isset($parts['user']) || isset($parts['pass'])
        || isset($parts['query']) || isset($parts['fragment'])
        || ($scheme !== 'https' && !($scheme === 'http' && $isLocal))) {
        return ['reachable' => false, 'error' => 'La URL del servidor de licencias no es segura'];
    }
    $url = $baseUrl . '/api/check.php';
    $identity = $companyIdentity ?? licenseLocalCompanyIdentity();
    $requestData = [
        'installation_id' => $installationId,
        'app_version' => licenseAppVersion(),
        'database_name' => defined('DB_NAME') ? (string) DB_NAME : '',
        'host_name' => function_exists('gethostname') ? (string) gethostname() : '',
        'company_name' => licenseLimitText($identity['company_name'] ?? '', 180),
        'company_tax_ids' => array_slice((array) ($identity['company_tax_ids'] ?? []), 0, 5),
    ];
    if ($loginAttempt !== []) {
        $requestData['login_attempt'] = [
            'user_code' => licenseLimitText($loginAttempt['user_code'] ?? '', 80),
            'user_name' => licenseLimitText($loginAttempt['user_name'] ?? '', 180),
            'credentials_valid' => (bool) ($loginAttempt['credentials_valid'] ?? false),
        ];
    }
    $payload = json_encode($requestData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $headers = [
        'Content-Type: application/json',
        'Accept: application/json',
        'Authorization: Bearer ' . trim($licenseKey ?? (string) LICENSE_KEY),
        'User-Agent: OperkomComandas/' . licenseAppVersion(),
    ];

    $statusCode = 0;
    $responseBody = false;
    $error = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $responseBody = curl_exec($ch);
        $statusCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($responseBody === false) {
            $error = (string) curl_error($ch);
        }
        curl_close($ch);
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $headers),
                'content' => $payload,
                'timeout' => 5,
                'ignore_errors' => true,
                'follow_location' => 0,
                'max_redirects' => 0,
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);
        $responseBody = @file_get_contents($url, false, $context);
        foreach (($http_response_header ?? []) as $header) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $header, $matches)) {
                $statusCode = (int) $matches[1];
            }
        }
        if ($responseBody === false) {
            $error = 'No fue posible conectar con el servidor de licencias';
        }
    }

    if (!is_string($responseBody)) {
        return ['reachable' => false, 'error' => $error ?: 'Sin respuesta del servidor de licencias'];
    }

    $data = json_decode($responseBody, true);
    if (!is_array($data) || !array_key_exists('allowed', $data)) {
        return ['reachable' => false, 'error' => 'Respuesta inválida del servidor de licencias'];
    }
    if ($statusCode >= 500 || strtolower((string) ($data['status'] ?? '')) === 'unavailable') {
        return [
            'reachable' => false,
            'error' => trim((string) ($data['message'] ?? '')) ?: 'El servidor de licencias no está disponible',
        ];
    }

    return [
        'reachable' => true,
        'http_status' => $statusCode,
        'allowed' => (bool) $data['allowed'],
        'status' => preg_replace('/[^a-z_]/', '', strtolower((string) ($data['status'] ?? 'unknown'))),
        'message' => trim((string) ($data['message'] ?? '')),
        'company_name' => trim((string) ($data['company_name'] ?? '')),
    ];
}

function licensePersistRemoteState(array $remote, string $installationId, ?string $licenseKey = null): array
{
    $now = time();
    $state = [
        'installation_id' => $installationId,
        'config_fingerprint' => licenseConfigFingerprint($licenseKey),
        'configured' => true,
        'allowed' => (bool) $remote['allowed'],
        'status' => (string) ($remote['status'] ?: ($remote['allowed'] ? 'active' : 'blocked')),
        'message' => (string) ($remote['message'] ?: ($remote['allowed'] ? 'Licencia activa.' : 'Licencia bloqueada.')),
        'company_name' => (string) ($remote['company_name'] ?? ''),
        'last_checked_at' => $now,
        'last_success_at' => $now,
        'next_check_at' => $now + max(60, (int) LICENSE_CHECK_INTERVAL),
    ];
    licenseWriteState($state);
    return $state;
}

/** Retorna el estado efectivo. $force omite el intervalo de caché. */
function getOperationalLicenseStatus(bool $force = false, array $loginAttempt = []): array
{
    $now = time();
    $state = licenseReadState();
    $installationId = licenseInstallationId($state);

    if (!licenseIsConfigured()) {
        return [
            'allowed' => false,
            'status' => 'unconfigured',
            'message' => 'Esta instalación aún no tiene una licencia configurada.',
            'installation_id' => $installationId,
            'configured' => false,
            'last_checked_at' => null,
            'last_success_at' => null,
            'next_check_at' => null,
        ];
    }

    $fingerprint = licenseConfigFingerprint();
    if (($state['config_fingerprint'] ?? '') !== $fingerprint) {
        $state = ['installation_id' => $installationId, 'config_fingerprint' => $fingerprint];
        $force = true;
    }

    if (!$force && (int) ($state['next_check_at'] ?? 0) > $now
        && ($state['allowed'] ?? false) === true) {
        return licensePublicState($state, true);
    }

    // Evita varias consultas remotas simultáneas cuando llegan múltiples
    // peticiones desde teléfonos en el mismo instante.
    $lockPath = licenseStatePath() . '.lock';
    $lockDirectory = dirname($lockPath);
    if (!is_dir($lockDirectory)) {
        @mkdir($lockDirectory, 0750, true);
    }
    $lock = @fopen($lockPath, 'c');
    if ($lock !== false) {
        @flock($lock, LOCK_EX);
        $latest = licenseReadState();
        if (!$force && ($latest['config_fingerprint'] ?? '') === $fingerprint
            && (int) ($latest['next_check_at'] ?? 0) > time()
            && ($latest['allowed'] ?? false) === true) {
            @flock($lock, LOCK_UN);
            fclose($lock);
            return licensePublicState($latest, true);
        }
    }

    $remote = licenseCheckRemote($installationId, $loginAttempt);
    $now = time();
    if ($remote['reachable']) {
        $state = licensePersistRemoteState($remote, $installationId);
    } else {
        $lastSuccess = (int) ($state['last_success_at'] ?? 0);
        $withinGrace = $lastSuccess > 0 && ($now - $lastSuccess) <= max(0, (int) LICENSE_OFFLINE_GRACE);
        $previousAllowed = (bool) ($state['allowed'] ?? false);
        $allowed = $withinGrace && $previousAllowed;
        $state = array_merge($state, [
            'installation_id' => $installationId,
            'config_fingerprint' => $fingerprint,
            'configured' => true,
            'allowed' => $allowed,
            'status' => $allowed ? 'grace' : 'unreachable',
            'message' => $allowed
                ? 'Servidor de licencias sin conexión; usando el período de gracia.'
                : 'No se pudo validar la licencia. Contacta a soporte.',
            'last_checked_at' => $now,
            'next_check_at' => $now + 60,
            'last_error' => (string) ($remote['error'] ?? 'Error de conexión'),
        ]);
        licenseWriteState($state);
    }

    if ($lock !== false) {
        @flock($lock, LOCK_UN);
        fclose($lock);
    }

    return licensePublicState($state, true);
}

function licensePublicState(array $state, bool $configured): array
{
    return [
        'allowed' => (bool) ($state['allowed'] ?? false),
        'status' => (string) ($state['status'] ?? 'unknown'),
        'message' => (string) ($state['message'] ?? ''),
        'company_name' => (string) ($state['company_name'] ?? ''),
        'installation_id' => (string) ($state['installation_id'] ?? ''),
        'configured' => $configured,
        'last_checked_at' => !empty($state['last_checked_at']) ? date(DATE_ATOM, (int) $state['last_checked_at']) : null,
        'last_success_at' => !empty($state['last_success_at']) ? date(DATE_ATOM, (int) $state['last_success_at']) : null,
        'next_check_at' => !empty($state['next_check_at']) ? date(DATE_ATOM, (int) $state['next_check_at']) : null,
    ];
}

function requireOperationalLicense(bool $force = false, array $loginAttempt = []): array
{
    $status = getOperationalLicenseStatus($force || $loginAttempt !== [], $loginAttempt);
    if ($status['allowed']) {
        return $status;
    }

    $httpStatus = match ($status['status']) {
        'blocked', 'expired' => 423,
        'company_mismatch' => 409,
        default => 503,
    };
    http_response_code($httpStatus);
    echo json_encode([
        'success' => false,
        'error' => $status['message'] ?: 'El módulo de comandas no está habilitado para esta empresa.',
        'code' => 'LICENSE_' . strtoupper((string) $status['status']),
        'license' => $status,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
