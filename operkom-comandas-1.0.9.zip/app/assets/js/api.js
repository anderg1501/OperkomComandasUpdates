/**
 * api.js — Capa de comunicación con la API REST.
 * Centraliza todas las llamadas fetch. Nunca se hacen llamadas
 * directas a la API desde las vistas; siempre se usa este módulo.
 */

function _resolveApiBase() {
    return window.OperkomConfig.resolveApiBase();
}

const API_BASE = _resolveApiBase();

function _createApiError({
    userMessage,
    technicalMessage,
    endpoint,
    url,
    method,
    status,
    responseBody,
    cause,
}) {
    const err = new Error(userMessage || technicalMessage || 'Error de API');
    err.name = 'ApiRequestError';
    err.userMessage = userMessage || 'No se pudo completar la solicitud.';
    err.technicalMessage = technicalMessage || '';
    err.endpoint = endpoint || '';
    err.url = url || '';
    err.method = method || 'GET';
    err.status = Number.isInteger(status) ? status : 0;
    err.responseBody = responseBody;
    err.timestamp = new Date().toISOString();
    if (cause) {
        err.cause = cause;
    }
    return err;
}

function _toText(value) {
    if (value === null || value === undefined) {
        return '';
    }
    if (typeof value === 'string') {
        return value;
    }
    try {
        return JSON.stringify(value);
    } catch {
        return String(value);
    }
}

function _formatErrorDetails(err) {
    if (!err) {
        return 'Error desconocido';
    }

    const parts = [];
    parts.push(`tipo=${err.name || 'Error'}`);

    if (err.message) {
        parts.push(`mensaje=${err.message}`);
    }
    if (err.method || err.endpoint) {
        parts.push(`request=${(err.method || 'GET')} ${err.endpoint || ''}`.trim());
    }
    if (err.status) {
        parts.push(`status=${err.status}`);
    }
    if (err.technicalMessage) {
        parts.push(`detalle=${err.technicalMessage}`);
    }
    if (err.timestamp) {
        parts.push(`timestamp=${err.timestamp}`);
    }

    const responseText = _toText(err.responseBody);
    if (responseText) {
        const preview = responseText.length > 700
            ? `${responseText.slice(0, 700)}...`
            : responseText;
        parts.push(`response=${preview}`);
    }

    return parts.join('\n');
}

// ── Fetch base ────────────────────────────────────────────────

function _getHeaders() {
    const raw = sessionStorage.getItem('operkom_session');
    const session = raw ? JSON.parse(raw) : null;
    const headers = { 'Content-Type': 'application/json' };
    if (session?.token) {
        headers['Authorization'] = `Bearer ${session.token}`;
    }
    return headers;
}

async function _apiFetch(endpoint, options = {}) {
    const url = API_BASE + endpoint;
    const method = (options.method || 'GET').toUpperCase();
    const config = {
        ...options,
        headers: { ..._getHeaders(), ...(options.headers || {}) },
    };

    let response;
    try {
        response = await fetch(url, config);
    } catch (err) {
        throw _createApiError({
            userMessage: 'Sin conexión con el servidor. Verifica la red WiFi.',
            technicalMessage: err?.message || 'Falló fetch()',
            endpoint,
            url,
            method,
            cause: err,
        });
    }

    const raw = await response.text();
    let data;
    try {
        data = raw ? JSON.parse(raw) : {};
    } catch {
        throw _createApiError({
            userMessage: `Error inesperado del servidor (${response.status}).`,
            technicalMessage: 'La respuesta no es JSON válido.',
            endpoint,
            url,
            method,
            status: response.status,
            responseBody: raw,
        });
    }

    if (data && typeof data === 'object') {
        Object.defineProperty(data, '__apiMeta', {
            value: { endpoint, url, method, status: response.status },
            enumerable: false,
        });
    }

    // Token expirado o inválido → redirigir al login
    // Solo aplica si ya había una sesión activa (no durante el login mismo)
    if (response.status === 401 && sessionStorage.getItem('operkom_session')) {
        sessionStorage.removeItem('operkom_session');
        Router.navigate('login');
        throw _createApiError({
            userMessage: 'Sesión expirada. Inicia sesión nuevamente.',
            technicalMessage: 'HTTP 401 con sesión activa',
            endpoint,
            url,
            method,
            status: response.status,
            responseBody: data,
        });
    }

    if (!response.ok) {
        throw _createApiError({
            userMessage: data?.error || `Error del servidor (${response.status}).`,
            technicalMessage: data?.error || data?.message || 'La API devolvió un status no exitoso.',
            endpoint,
            url,
            method,
            status: response.status,
            responseBody: data,
        });
    }

    return data;
}

// ── API pública ───────────────────────────────────────────────

const Api = {

    debugError(err) {
        return _formatErrorDetails(err);
    },

    auth: {
        vendedores() {
            return _apiFetch('/auth/vendedores.php');
        },
        administradores() {
            return _apiFetch('/auth/administradores.php');
        },
        login(id_vendedor, pos_pas) {
            return _apiFetch('/auth/login.php', {
                method: 'POST',
                body: JSON.stringify({ id_vendedor, pos_pas }),
            });
        },
        loginConfiguracion(id_vendedor, pos_pas) {
            return _apiFetch('/auth/config-login.php', {
                method: 'POST',
                body: JSON.stringify({ id_vendedor, pos_pas }),
            });
        },
        logout() {
            return _apiFetch('/auth/logout.php', { method: 'POST' });
        },
    },

    mesas: {
        areas() {
            return _apiFetch('/mesas/areas.php');
        },
        byArea(descripcion) {
            return _apiFetch(`/mesas/index.php?id_area=${encodeURIComponent(descripcion)}`);
        },
    },

    productos: {
        categorias() {
            return _apiFetch('/productos/categorias.php');
        },
        todos() {
            return _apiFetch('/productos/todos.php');
        },
        byCategoria(categoria) {
            return _apiFetch(`/productos/index.php?categoria=${encodeURIComponent(categoria)}`);
        },
    },

    notas: {
        byCategoria(categoria) {
            return _apiFetch(`/notas/index.php?categoria=${encodeURIComponent(categoria)}`);
        },
    },

    pedidos: {
        activarMesa(data) {
            return _apiFetch('/pedidos/activar-mesa.php', {
                method: 'POST',
                body: JSON.stringify(data),
            });
        },
        get(docespera) {
            return _apiFetch(`/pedidos/index.php?docespera=${encodeURIComponent(docespera)}`);
        },
        agregarItem(data) {
            return _apiFetch('/pedidos/agregar-item.php', {
                method: 'POST',
                body: JSON.stringify(data),
            });
        },
        removerItem(data) {
            return _apiFetch('/pedidos/remover-item.php', {
                method: 'DELETE',
                body: JSON.stringify(data),
            });
        },
        cambiarCantidad(data) {
            return _apiFetch('/pedidos/cambiar-cantidad.php', {
                method: 'PATCH',
                body: JSON.stringify(data),
            });
        },
        actualizarNotas(data) {
            return _apiFetch('/pedidos/actualizar-notas.php', {
                method: 'PATCH',
                body: JSON.stringify(data),
            });
        },
        liberarMesa(data) {
            return _apiFetch('/pedidos/liberar-mesa.php', {
                method: 'DELETE',
                body: JSON.stringify(data),
            });
        },
        trasladarMesa(data) {
            return _apiFetch('/pedidos/trasladar-mesa.php', {
                method: 'POST',
                body: JSON.stringify(data),
            });
        },
    },

    comandas: {
        enviar(docespera, mesa_nombre) {
            return _apiFetch('/comandas/enviar.php', {
                method: 'POST',
                body: JSON.stringify({ docespera, mesa_nombre }),
            });
        },
    },

    configuracion: {
        obtener(token) {
            return _apiFetch('/config/settings.php', {
                headers: { Authorization: `Bearer ${token}` },
            });
        },
        guardar(token, data) {
            return _apiFetch('/config/settings.php', {
                method: 'PATCH',
                headers: { Authorization: `Bearer ${token}` },
                body: JSON.stringify(data),
            });
        },
    },

    actualizaciones: {
        estado(token) {
            return _apiFetch('/updates/status.php', {
                headers: { Authorization: `Bearer ${token}` },
            });
        },
        iniciar(token) {
            return _apiFetch('/updates/start.php', {
                method: 'POST',
                headers: { Authorization: `Bearer ${token}` },
            });
        },
    },
};
