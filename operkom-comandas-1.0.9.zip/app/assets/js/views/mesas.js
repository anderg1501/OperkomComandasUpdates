/**
 * mesas.js — Vista de selección de mesa.
 */

const MesasView = {
    _autoRefreshTimer: null,
    _autoRefreshMs: 15000,
    _isAutoRefreshing: false,
    _eventsBound: false,
    _areaRequestId: 0,

    init() {
        const session = AppState.session;
        if (!session?.token) { Router.navigate('login'); return; }

        // Header
        document.getElementById('mesas-empresa').textContent = session.empresa || 'Restaurante';
        document.getElementById('mesas-vendedor').textContent = session.nombres.split(' ')[0];

        this._bindEvents();
        this._loadAreas();
        this._startAutoRefresh();
    },

    async _loadAreas({ preserveSelected = false } = {}) {
        try {
            const res = await Api.mesas.areas();
            if (!res.success) { Toast.show(res.error, 'error'); return; }
            if (!this._isActive()) return;

            AppState.areas = res.data;
            this._renderAreaTabs();

            const previousArea = preserveSelected ? AppState.area_seleccionada : null;
            const selectedArea = previousArea
                ? res.data.find(area => area.id === previousArea.id || area.descripcion === previousArea.descripcion)
                : null;

            // Seleccionar la primera área automáticamente o conservar la actual al refrescar.
            if (res.data.length > 0) {
                this._selectArea(selectedArea || res.data[0]);
            } else {
                document.getElementById('mesas-grid').innerHTML =
                    '<p class="col-span-full text-center text-slate-500 py-12">No hay áreas configuradas</p>';
            }
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    _renderAreaTabs() {
        const container = document.getElementById('areas-tabs');
        container.innerHTML = AppState.areas.map(area => `
            <button
                onclick="MesasView._selectArea(${JSON.stringify(area).replace(/"/g, '&quot;')})"
                id="tab-area-${area.id}"
                class="area-tab flex-shrink-0 px-5 py-2.5 rounded-xl text-sm font-semibold
                       transition-all duration-150">
                ${area.descripcion}
            </button>
        `).join('');
    },

    async _selectArea(area, { showLoading = true, silent = false } = {}) {
        const requestId = ++this._areaRequestId;
        AppState.area_seleccionada = area;

        // Actualizar tab activo
        document.querySelectorAll('.area-tab').forEach(t => {
            t.classList.remove('area-tab-active');
        });
        const tab = document.getElementById(`tab-area-${area.id}`);
        if (tab) { tab.classList.add('area-tab-active'); }

        if (showLoading) {
            document.getElementById('mesas-grid').innerHTML =
                '<div class="col-span-full flex justify-center py-12"><div class="loading-spinner"></div></div>';
        }

        try {
            const res = await Api.mesas.byArea(area.descripcion);
            if (!res.success) {
                if (!silent) Toast.show(res.error, 'error');
                return;
            }
            if (requestId !== this._areaRequestId || !this._isActive()) return;
            AppState.mesas = res.data;
            this._renderMesas(area);
        } catch (err) {
            if (!silent) Toast.show(err.message, 'error');
        }
    },

    _renderMesas(area) {
        const container = document.getElementById('mesas-grid');
        const session   = AppState.session;

        if (!AppState.mesas.length) {
            container.innerHTML =
                '<p class="col-span-full text-center text-slate-500 py-12">No hay mesas en esta área</p>';
            return;
        }

        container.innerHTML = AppState.mesas.map(mesa => {
            const libre = mesa.estatus === 0 || mesa.estatus === '0';
            const esMia = !libre && mesa.id_mesero === session.id_vendedor;

            let cardCls, badge, statusTxt, statusCls, clickable = true;

            if (libre) {
                cardCls   = 'border-emerald-300 bg-emerald-50 dark:border-emerald-500/40 dark:bg-emerald-900/20 hover:border-emerald-500 hover:bg-emerald-100 dark:hover:bg-emerald-800/30 dark:hover:border-emerald-400 cursor-pointer active:scale-95';
                badge     = 'bg-emerald-500';
                statusTxt = 'Disponible';
                statusCls = 'text-emerald-700 dark:text-emerald-400';
            } else if (esMia) {
                cardCls   = 'border-amber-300 bg-amber-50 dark:border-amber-500/40 dark:bg-amber-900/20 hover:border-amber-500 hover:bg-amber-100 dark:hover:bg-amber-800/30 dark:hover:border-amber-400 cursor-pointer active:scale-95';
                badge     = 'bg-amber-400';
                statusTxt = 'Mi mesa';
                statusCls = 'text-amber-700 dark:text-amber-400';
            } else {
                cardCls   = 'border-rose-300 bg-rose-50 dark:border-rose-500/30 dark:bg-rose-900/10 opacity-60 cursor-not-allowed';
                badge     = 'bg-rose-500';
                statusTxt = 'Ocupada';
                statusCls = 'text-rose-600 dark:text-rose-400';
                clickable = false;
            }

            const clickAttr = clickable
                ? `onclick="MesasView._activarMesa(${JSON.stringify(mesa).replace(/"/g, '&quot;')})"`
                : '';

            const acum = parseFloat(mesa.acumulado || 0);
            const timerTxt = this._buildMesaTimer(mesa.fecha_activada, mesa.hora_activada);

            return `
                <div ${clickAttr}
                     class="relative rounded-2xl border-2 p-4 transition-all duration-200 select-none ${cardCls}">
                    <div class="flex items-start justify-between mb-2">
                        <span class="text-[#214599] dark:text-blue-100 font-bold text-lg leading-tight">${mesa.nombre}</span>
                        <span class="w-3 h-3 rounded-full mt-1 flex-shrink-0 ${badge}"></span>
                    </div>
                    <div class="text-xs font-medium mb-1 ${statusCls}">
                        ${statusTxt}
                    </div>
                    ${!libre ? `<div class="text-xs text-slate-500 dark:text-slate-400 truncate">${mesa.nombre_mesero ?? ''}</div>` : ''}
                    ${esMia && acum > 0 ? `<div class="text-base font-bold text-amber-600 dark:text-amber-300 mt-1">$${acum.toLocaleString('es-CO')}</div>` : ''}
                    ${esMia && timerTxt ? `<div class="text-xs text-amber-500/80 dark:text-amber-400/70 mt-0.5">⏱ ${timerTxt}</div>` : ''}
                    ${esMia ? `
                    <button onclick="event.stopPropagation(); MesasView._confirmarLiberarMesa(${JSON.stringify(mesa).replace(/"/g, '&quot;')})"
                            class="btn-liberar-mesa mt-2 text-xs px-3 py-1 rounded-md transition-colors">
                        🔓 Liberar
                    </button>` : ''}
                </div>
            `;
        }).join('');
    },

    async _activarMesa(mesa) {
        const area    = AppState.area_seleccionada;
        const session = AppState.session;

        try {
            const payload = {
                id_mesa:        mesa.id,
                id_area:        area.indicador,
                indicador_area: area.descripcion + '-',
                nombre_mesa:    mesa.nombre,
                estacion:       (navigator.userAgent.match(/Android|iPhone|iPad/i)
                                    ? 'Movil' : 'Web') + '-' + Date.now().toString(36).slice(-6),
            };

            const res = await Api.pedidos.activarMesa(payload);
            if (!res.success) { Toast.show(res.error, 'error'); return; }

            AppState.mesa_activa = { ...mesa, area };
            AppState.docespera   = res.data.docespera;

            if (!res.data.es_nueva) {
                // Recuperar ítems existentes del pedido
                const resPedido = await Api.pedidos.get(res.data.docespera);
                if (resPedido.success) {
                    AppState.pedido_items = resPedido.data.items;
                    AppState.pedido_total = resPedido.data.total;
                }
            } else {
                AppState.pedido_items = [];
                AppState.pedido_total = '0';
            }

            Router.navigate('pedido');

        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    async _confirmarLiberarMesa(mesa) {
        const area = AppState.area_seleccionada;
        const docespera = area.descripcion + '-' + mesa.nombre;

        const result = await Swal.fire({
            title: `Liberar mesa`,
            html: `<span class="operkom-swal-text">¿Liberar <strong class="operkom-swal-emphasis">${mesa.nombre}</strong>?</span><br><span class="operkom-swal-sub">Los ítems sin enviar a cocina serán eliminados.</span>`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: '🔓 Sí, liberar',
            cancelButtonText: 'Cancelar',
            buttonsStyling: false,
            customClass: {
                popup:         'operkom-swal-popup',
                title:         'operkom-swal-title',
                htmlContainer: 'operkom-swal-html',
                confirmButton: 'btn btn-primary',
                cancelButton:  'btn btn-danger',
            },
        });
        if (!result.isConfirmed) return;

        try {
            const res = await Api.pedidos.liberarMesa({
                id_mesa:   mesa.id,
                docespera: docespera,
            });
            if (!res.success) { Toast.show(res.error, 'error'); return; }
            Toast.show(`Mesa ${mesa.nombre} liberada`, 'success');
            this._selectArea(area);
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    _buildMesaTimer(fecha, hora) {
        if (!fecha || !hora) return '';
        try {
            const inicio = new Date(`${fecha}T${hora}`);
            const mins   = Math.floor((new Date() - inicio) / 60000);
            if (mins < 0)  return '';
            if (mins < 60) return `${mins} min`;
            const h = Math.floor(mins / 60);
            const m = mins % 60;
            return m > 0 ? `${h}h ${m}m` : `${h}h`;
        } catch { return ''; }
    },

    _bindEvents() {
        if (this._eventsBound) return;
        this._eventsBound = true;

        const btnLogout  = document.getElementById('btn-logout');
        const btnRefresh = document.getElementById('btn-refresh-mesas');

        btnLogout?.addEventListener('click',  () => this._logout());
        btnRefresh?.addEventListener('click', () => this._loadAreas({ preserveSelected: true }));
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) this._refreshMesas();
        });
    },

    _isActive() {
        return AppState.vista_actual === 'mesas';
    },

    _startAutoRefresh() {
        this._stopAutoRefresh();
        this._autoRefreshTimer = window.setInterval(() => this._refreshMesas(), this._autoRefreshMs);
    },

    _stopAutoRefresh() {
        if (this._autoRefreshTimer !== null) {
            window.clearInterval(this._autoRefreshTimer);
            this._autoRefreshTimer = null;
        }
        this._isAutoRefreshing = false;
    },

    async _refreshMesas() {
        if (document.hidden || !this._isActive() || this._isAutoRefreshing) return;

        const area = AppState.area_seleccionada;
        if (!area) return;

        this._isAutoRefreshing = true;
        try {
            await this._selectArea(area, { showLoading: false, silent: true });
        } finally {
            this._isAutoRefreshing = false;
        }
    },

    async _logout() {
        this._stopAutoRefresh();
        try { await Api.auth.logout(); } catch { /* Continuar aunque falle */ }
        sessionStorage.removeItem('operkom_session');
        AppState.session = null;
        AppState.categorias = [];
        AppState.productos  = {};
        Router.navigate('login');
    },
};
