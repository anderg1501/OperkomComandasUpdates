/**
 * config.js — Acceso y opciones administrativas de Operkom Comandas.
 */
const ConfigView = {
    _administradores: [],
    _adminSeleccionado: null,
    _pin: '',
    _token: null,

    init() {
        this._administradores = [];
        this._adminSeleccionado = null;
        this._pin = '';
        this._token = null;
        this._mostrarAdministradores();
    },

    _escapeHtml(text) {
        return String(text || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    },

    cerrar() {
        this._token = null;
        this._pin = '';
        Router.navigate('login');
    },

    async _mostrarAdministradores() {
        const content = document.getElementById('config-content');
        if (!content) return;

        content.innerHTML = `
            <section class="config-panel">
                <div class="config-intro">
                    <span class="config-eyebrow">ACCESO RESTRINGIDO</span>
                    <h2>Configuración</h2>
                    <p>Selecciona un administrador e ingresa su PIN.</p>
                </div>
                <div id="config-admin-grid" class="config-admin-grid">
                    <div class="config-loading"><div class="loading-spinner"></div></div>
                </div>
            </section>`;

        try {
            const res = await Api.auth.administradores();
            if (!res.success) throw new Error(res.error || 'No fue posible cargar administradores');

            this._administradores = res.data || [];
            const grid = document.getElementById('config-admin-grid');
            if (!grid) return;

            if (!this._administradores.length) {
                grid.innerHTML = `<p class="config-empty">No hay vendedores activos con permiso de administrador.</p>`;
                return;
            }

            grid.innerHTML = this._administradores.map((admin, index) => {
                const nombre = this._escapeHtml(admin.nombres);
                const initials = this._escapeHtml(String(admin.nombres || '').trim().split(/\s+/)
                    .map(word => word[0]).slice(0, 2).join('').toUpperCase());
                return `<button class="config-admin-btn" onclick="ConfigView.seleccionarAdministrador(${index})">
                    <span class="config-admin-avatar">${initials}</span>
                    <span>${nombre}</span>
                </button>`;
            }).join('');
        } catch (err) {
            const grid = document.getElementById('config-admin-grid');
            if (grid) {
                grid.innerHTML = `<div class="config-empty">
                    <p>No se pudo cargar el acceso administrativo.</p>
                    <button class="config-text-btn" onclick="ConfigView._mostrarAdministradores()">Reintentar</button>
                </div>`;
            }
            console.error('[ConfigView] administradores:', err);
        }
    },

    seleccionarAdministrador(index) {
        const admin = this._administradores[index];
        if (!admin) return;

        this._adminSeleccionado = admin;
        this._pin = '';
        const content = document.getElementById('config-content');
        if (!content) return;

        content.innerHTML = `
            <section class="config-panel config-pin-panel">
                <button class="config-back-btn" onclick="ConfigView._mostrarAdministradores()" aria-label="Cambiar administrador">
                    ← Cambiar administrador
                </button>
                <div class="config-intro">
                    <span class="config-admin-avatar">${this._escapeHtml(String(admin.nombres || '').trim().split(/\s+/).map(word => word[0]).slice(0, 2).join('').toUpperCase())}</span>
                    <h2>${this._escapeHtml(admin.nombres)}</h2>
                    <p>Ingresa tu PIN de administrador.</p>
                </div>
                <div class="config-pin-dots" aria-label="PIN ingresado">
                    ${Array.from({ length: 6 }, (_, indexDot) => `<span class="config-pin-dot" data-index="${indexDot}"></span>`).join('')}
                </div>
                <div class="config-keypad">
                    ${['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(value => `<button onclick="ConfigView.pinKey('${value}')">${value}</button>`).join('')}
                    <button class="config-key-clear" onclick="ConfigView.pinKey('clear')">C</button>
                    <button onclick="ConfigView.pinKey('0')">0</button>
                    <button class="config-key-clear" onclick="ConfigView.pinKey('back')" aria-label="Borrar último dígito">←</button>
                </div>
                <button id="btn-config-login" class="config-primary-btn" onclick="ConfigView.ingresar()">INGRESAR</button>
            </section>`;
        this._actualizarPin();
    },

    pinKey(value) {
        if (value === 'clear') this._pin = '';
        else if (value === 'back') this._pin = this._pin.slice(0, -1);
        else if (this._pin.length < 20) this._pin += value;
        this._actualizarPin();
    },

    _actualizarPin() {
        document.querySelectorAll('.config-pin-dot').forEach((dot, index) => {
            dot.classList.toggle('is-filled', index < this._pin.length);
        });
    },

    async ingresar() {
        if (!this._adminSeleccionado || !this._pin) {
            Toast.show('Ingresa el PIN del administrador', 'error');
            return;
        }

        const button = document.getElementById('btn-config-login');
        button.disabled = true;
        button.textContent = 'VERIFICANDO...';

        try {
            const res = await Api.auth.loginConfiguracion(this._adminSeleccionado.id_vendedor, this._pin);
            if (!res.success) throw new Error(res.error || 'No fue posible validar el acceso');
            this._token = res.data.token;
            this._mostrarOpciones();
        } catch (err) {
            this._pin = '';
            this._actualizarPin();
            Toast.show(err.userMessage || err.message || 'PIN incorrecto', 'error');
        } finally {
            if (button?.isConnected) {
                button.disabled = false;
                button.textContent = 'INGRESAR';
            }
        }
    },

    async _mostrarOpciones() {
        const content = document.getElementById('config-content');
        if (!content || !this._token) return;

        content.innerHTML = `<section class="config-panel"><div class="config-loading"><div class="loading-spinner"></div></div></section>`;
        try {
            const res = await Api.configuracion.obtener(this._token);
            if (!res.success) throw new Error(res.error || 'No fue posible cargar la configuración');

            content.innerHTML = `
                <section class="config-panel">
                    <div class="config-intro config-intro-left">
                        <span class="config-eyebrow">ADMINISTRACIÓN</span>
                        <h2>Parámetros</h2>
                        <p>Administra las preferencias de operación y la conexión del sistema.</p>
                    </div>
                    <div class="config-section">
                        <span class="config-section-title">PEDIDOS</span>
                    <label class="config-setting-row" for="setting-agrupar-items">
                        <span>
                            <strong>Agrupar productos iguales</strong>
                            <small>Suma la cantidad en una sola línea cuando el producto no tiene notas y aún no ha sido enviado a cocina.</small>
                        </span>
                        <input id="setting-agrupar-items" type="checkbox" ${res.data.agrupar_items ? 'checked' : ''}>
                        <span class="config-switch" aria-hidden="true"></span>
                    </label>
                    <button id="btn-save-settings" class="config-primary-btn" onclick="ConfigView.guardar()">GUARDAR CAMBIOS</button>
                    </div>
                    <div class="config-section config-section-connection">
                        <span class="config-section-title">SISTEMA</span>
                        <button type="button" class="config-action-row" onclick="ConfigView.reconfigurarConexion()">
                            <span class="config-action-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                    <ellipse cx="12" cy="5" rx="7" ry="3"></ellipse>
                                    <path d="M5 5v7c0 1.66 3.13 3 7 3s7-1.34 7-3V5M5 12v7c0 1.66 3.13 3 7 3s7-1.34 7-3v-7"></path>
                                </svg>
                            </span>
                            <span class="config-action-content">
                                <strong>Conexión a la base de datos</strong>
                                <small>Actualiza el servidor, base de datos, usuario o contraseña de MySQL.</small>
                            </span>
                            <span class="config-action-arrow" aria-hidden="true">›</span>
                        </button>
                        <p class="config-action-note">Se comprobará la conexión antes de guardar y se creará una copia de respaldo de la configuración actual.</p>
                        <button id="btn-check-update" type="button" class="config-action-row" onclick="ConfigView.buscarActualizacion()">
                            <span class="config-action-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                    <path d="M20 11a8.1 8.1 0 0 0-15.5-2M4 5v4h4M4 13a8.1 8.1 0 0 0 15.5 2M20 19v-4h-4"></path>
                                </svg>
                            </span>
                            <span class="config-action-content">
                                <strong>Buscar actualización</strong>
                                <small>Descarga e instala la versión más reciente sin modificar la configuración local.</small>
                            </span>
                            <span class="config-action-arrow" aria-hidden="true">›</span>
                        </button>
                    </div>
                </section>`;
        } catch (err) {
            content.innerHTML = `<section class="config-panel config-empty">
                <p>No se pudo cargar la configuración.</p>
                <button class="config-text-btn" onclick="ConfigView._mostrarOpciones()">Reintentar</button>
            </section>`;
            console.error('[ConfigView] opciones:', err);
        }
    },

    async guardar() {
        const toggle = document.getElementById('setting-agrupar-items');
        const button = document.getElementById('btn-save-settings');
        if (!toggle || !button || !this._token) return;

        button.disabled = true;
        button.textContent = 'GUARDANDO...';
        try {
            const res = await Api.configuracion.guardar(this._token, {
                agrupar_items: toggle.checked,
            });
            if (!res.success) throw new Error(res.error || 'No fue posible guardar los cambios');
            Toast.show('Configuración guardada', 'success');
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No fue posible guardar', 'error');
        } finally {
            button.disabled = false;
            button.textContent = 'GUARDAR CAMBIOS';
        }
    },

    reconfigurarConexion() {
        if (!this._token) return;

        const continuar = window.confirm(
            'Abrirás la configuración de conexión. Los datos se validarán antes de reemplazar la configuración actual.'
        );
        if (continuar) {
            window.location.href = 'setup.html?edit=1';
        }
    },

    async buscarActualizacion() {
        if (!this._token) return;

        const button = document.getElementById('btn-check-update');
        if (button) button.disabled = true;

        try {
            const status = await Api.actualizaciones.estado(this._token);
            if (!status.success) throw new Error(status.error || 'No fue posible comprobar actualizaciones');

            if (!status.data.update_available) {
                Toast.show(`La aplicación ya está actualizada (v${status.data.current_version}).`, 'success');
                return;
            }

            const confirmacion = window.confirm(
                `Hay una actualización disponible (v${status.data.available_version}). ` +
                'La aplicación se reiniciará durante unos segundos. ¿Deseas instalarla ahora?'
            );
            if (!confirmacion) return;

            const result = await Api.actualizaciones.iniciar(this._token);
            if (!result.success || !result.data.started) {
                throw new Error(result.error || result.data?.message || 'No se pudo iniciar la actualización');
            }

            Toast.show('Actualización iniciada. La aplicación se recargará en unos segundos.', 'success');
            setTimeout(() => window.location.reload(), 8000);
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No fue posible actualizar la aplicación', 'error');
        } finally {
            if (button?.isConnected) button.disabled = false;
        }
    },
};
