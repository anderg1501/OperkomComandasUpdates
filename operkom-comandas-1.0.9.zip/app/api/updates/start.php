<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
require_once __DIR__ . '/update-helper.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

requireUpdateAdministrator();
$currentVersion = getCurrentAppVersion();

try {
    $manifest = fetchUpdateManifest();
    if (!isUpdateAvailable($currentVersion, $manifest['version'])) {
        sendSuccess(['started' => false, 'message' => 'La aplicación ya está actualizada.']);
    }

    $scriptPath = dirname(__DIR__, 3) . '/updater/Update-OperkomComandas.ps1';
    if (!file_exists($scriptPath)) {
        sendError('El actualizador local no está instalado.', 500);
    }

    $safeScriptPath = str_replace('"', '""', $scriptPath);
    $command = 'cmd.exe /C start "" /B powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' . $safeScriptPath . '"';
    $handle = @popen($command, 'r');
    if ($handle === false) {
        sendError('No se pudo iniciar el actualizador.', 500);
    }
    pclose($handle);

    sendSuccess([
        'started' => true,
        'version' => $manifest['version'],
        'message' => 'La actualización se está instalando. La aplicación se recargará en unos segundos.',
    ]);
} catch (RuntimeException $e) {
    sendError($e->getMessage(), 503);
}
