<?php
/**
 * POST /api/pedidos/agregar-item
 * Agrega un producto al pedido activo de una mesa.
 * Calcula impuestos, inserta en detalle_factura_espera
 * y actualiza el total en factura_espera.
 *
 * Body JSON:
 *   docespera   — clave del pedido (indicador_area + nombre_mesa)
 *   id_producto — inventario.id_producto
 *   cantidad    — número entero >= 1
 *   notas       — observaciones del mesero (puede ser vacío)
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/helpers/app-settings.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

validateToken();

$body       = getRequestBody();
$docespera  = trim($body['docespera']   ?? '');
$id_prod    = trim($body['id_producto'] ?? '');
$cantidad   = max(1, (int) ($body['cantidad'] ?? 1));
$notas      = substr(trim($body['notas'] ?? ''), 0, 255);

if ($docespera === '' || $id_prod === '') {
    sendError('Faltan campos requeridos: docespera, id_producto');
}

$db = getDB();

// ── Verificar que el pedido existe ────────────────────────────
$stmt = $db->prepare(
    "SELECT id FROM factura_espera WHERE docespera = :docespera LIMIT 1"
);
$stmt->execute([':docespera' => $docespera]);
if (!$stmt->fetch()) {
    sendError('El pedido no existe. Activar la mesa primero.');
}

// ── Obtener producto del inventario ───────────────────────────
$stmt = $db->prepare(
    "SELECT id_producto, descripcion1, categoria, existencias, exento,
            impuesto_descripcionv, impuestov, costo_actual, precio_venta1, compuesto,
            departamento, marca, unidad
       FROM inventario
      WHERE id_producto = :id_producto
        AND activo     = '1'
        AND serial    != '1'
        AND tyc       != '1'
      LIMIT 1"
);
$stmt->execute([':id_producto' => $id_prod]);
$producto = $stmt->fetch();

if (!$producto) {
    sendError('Producto no encontrado o no disponible');
}

// ── Obtener impresora de la categoría ─────────────────────────
// Compatible con BDs donde inventario.categoria guarda el ID o el nombre directamente
$stmt = $db->prepare(
    "SELECT imp_comanda FROM categoria_producto
      WHERE id_categoria = :cat
         OR categoria    = :cat2
      LIMIT 1"
);
$stmt->execute([':cat' => $producto['categoria'], ':cat2' => $producto['categoria']]);
$cat = $stmt->fetch();
$imp_comanda = $cat ? trim($cat['imp_comanda']) : '';

// ── Calcular valores fiscales ─────────────────────────────────
// Formato colombiano/VB6: punto=miles, coma=decimal (ej: "2.000,00")
function parsePrecioPhp(string $val): float {
    $s = trim($val);
    if ($s === '' || $s === '0') return 0.0;
    if (strpos($s, ',') !== false) {
        return (float) str_replace(['.', ','], ['', '.'], $s);
    }
    return (float) $s;
}

$pu     = parsePrecioPhp($producto['precio_venta1']);
$fiscal = calcularImpuesto($producto, $pu, $cantidad);

// Si está habilitado, sumar solo a una línea igual que aún no fue comandada.
// Las notas distintas o los ítems enviados a cocina deben conservar su propia línea.
// El bloqueo por pedido + producto evita que pulsaciones simultáneas creen líneas duplicadas.
$groupLockName = null;
if (getAppBooleanSetting($db, 'agrupar_items', false)) {
    $groupLockName = 'operkom_group_' . substr(hash('sha256', $docespera . "\0" . $id_prod . "\0" . $notas), 0, 40);
    $stmtLock = $db->prepare('SELECT GET_LOCK(:lock_name, 3)');
    $stmtLock->execute([':lock_name' => $groupLockName]);
    if ((int) $stmtLock->fetchColumn() !== 1) {
        sendError('No fue posible procesar el producto. Intenta nuevamente.', 409);
    }

    $stmtExistente = $db->prepare(
        "SELECT id, cantidad
           FROM detalle_factura_espera
          WHERE DocEspera = :docespera
            AND idarticulo = :id_producto
            AND COALESCE(res_notas, '') = :notas
            AND (res_comanda = '0' OR res_comanda = '' OR res_comanda IS NULL)
          ORDER BY id ASC
          LIMIT 1"
    );
    $stmtExistente->execute([
        ':docespera' => $docespera,
        ':id_producto' => $producto['id_producto'],
        ':notas' => $notas,
    ]);
    $itemExistente = $stmtExistente->fetch();

    if ($itemExistente) {
        $nuevaCantidad = max(1, (int) $itemExistente['cantidad']) + $cantidad;
        $fiscal = calcularImpuesto($producto, $pu, $nuevaCantidad);

        $stmtActualizar = $db->prepare(
            "UPDATE detalle_factura_espera
                SET cantidad = :cantidad, totalp = :totalp, iva = :iva,
                    tfiscal = :tfiscal, imp = :imp, pv = :pv, pvb = :pvb
              WHERE id = :id AND DocEspera = :docespera"
        );
        $stmtActualizar->execute([
            ':cantidad' => (string) $nuevaCantidad,
            ':totalp' => $fiscal['totalp'],
            ':iva' => $fiscal['iva'],
            ':tfiscal' => $fiscal['tfiscal'],
            ':imp' => $fiscal['imp'],
            ':pv' => $fiscal['pv'],
            ':pvb' => $fiscal['pvb'],
            ':id' => $itemExistente['id'],
            ':docespera' => $docespera,
        ]);

        $total = recalcularTotal($db, $docespera);
        releaseGroupLock($db, $groupLockName);
        sendSuccess([
            'item' => [
                'id' => (int) $itemExistente['id'],
                'idarticulo' => $producto['id_producto'],
                'articulo' => $producto['descripcion1'],
                'pu' => number_format($pu, 2, ',', '.'),
                'cantidad' => (string) $nuevaCantidad,
                'pv' => $fiscal['pv'],
                'res_notas' => $notas,
                'categoria_d' => $producto['categoria'],
                'res_imp_com' => $imp_comanda,
            ],
            'total_pedido' => $total,
            'agrupado' => true,
        ]);
    }
}

// ── Calcular posición en el pedido (res_index) ───────────────
$stmtIdx = $db->prepare(
    "SELECT COUNT(*) FROM detalle_factura_espera WHERE DocEspera = :docespera"
);
$stmtIdx->execute([':docespera' => $docespera]);
$res_index = (string)((int)$stmtIdx->fetchColumn() + 1);

// ── Insertar en detalle_factura_espera ────────────────────────
$stmt = $db->prepare(
    "INSERT INTO detalle_factura_espera
        (docespera, autobck, idarticulo, articulo, pu, cantidad, totalp,
         iva, tfiscal, imp, pv, pvb, usa_e, costo_venta, departamento_d,
         categoria_d, d_compuesto, res_notas, res_imp_com, pv_original,
         comision_p, comision_m, marca, unidad, res_indx)
     VALUES
        (:docespera, '1', :idarticulo, :articulo, :pu, :cantidad, :totalp,
         :iva, :tfiscal, :imp, :pv, :pvb, :usa_e, :costo_venta, :departamento_d,
         :categoria_d, :d_compuesto, :res_notas, :res_imp_com, :pv_original,
         '0,00', '0,00', :marca, :unidad, :res_index)"
);
$stmt->execute([
    ':docespera'      => $docespera,
    ':idarticulo'     => $producto['id_producto'],
    ':articulo'       => $producto['descripcion1'],
    ':pu'             => number_format($pu, 2, ',', '.'),
    ':cantidad'       => (string) $cantidad,
    ':totalp'         => $fiscal['totalp'],
    ':iva'            => $fiscal['iva'],
    ':tfiscal'        => $fiscal['tfiscal'],
    ':imp'            => $fiscal['imp'],
    ':pv'             => $fiscal['pv'],
    ':pvb'            => $fiscal['pvb'],
    ':usa_e'          => $producto['existencias'],
    ':costo_venta'    => $producto['costo_actual'],
    ':departamento_d' => $producto['departamento'] ?? '',
    ':categoria_d'    => $producto['categoria'],
    ':d_compuesto'    => $producto['compuesto'],
    ':res_notas'      => $notas,
    ':res_imp_com'    => $imp_comanda,
    ':pv_original'    => number_format($pu, 2, ',', '.'),
    ':marca'          => $producto['marca'] ?? '',
    ':unidad'         => $producto['unidad'] ?? '',
    ':res_index'      => $res_index,   // vinculado a columna res_indx
]);

$newItemId = (int) $db->lastInsertId();

// ── Recalcular total del pedido ───────────────────────────────
$total = recalcularTotal($db, $docespera);
releaseGroupLock($db, $groupLockName);

sendSuccess([
    'item' => [
        'id'          => $newItemId,
        'idarticulo'  => $producto['id_producto'],
        'articulo'    => $producto['descripcion1'],
        'pu'          => number_format($pu, 2, ',', '.'),
        'cantidad'    => (string) $cantidad,
        'pv'          => $fiscal['pv'],
        'res_notas'   => $notas,
        'categoria_d' => $producto['categoria'],
        'res_imp_com' => $imp_comanda,
    ],
    'total_pedido' => $total,
    'agrupado'     => false,
]);

// ── Helpers ───────────────────────────────────────────────────
function recalcularTotal(PDO $db, string $docespera): string
{
    // SUM compatible con valores en formato inglés ("1000.00") o colombiano ("1.000,00")
    $stmt = $db->prepare(
        "SELECT COALESCE(SUM(CAST(
            CASE WHEN pv LIKE '%,%'
                 THEN REPLACE(REPLACE(pv, '.', ''), ',', '.')
                 ELSE pv
            END AS DECIMAL(15,2))), 0)
           FROM detalle_factura_espera
          WHERE docespera = :docespera"
    );
    $stmt->execute([':docespera' => $docespera]);
    $total = number_format(floatval($stmt->fetchColumn()), 2, ',', '.');

    $db->prepare(
        "UPDATE factura_espera SET total = :total WHERE docespera = :docespera"
    )->execute([':total' => $total, ':docespera' => $docespera]);

    // Actualizar acumulado y pendiente en la mesa
    $db->prepare(
        "UPDATE restaurant_detalle_mesas rdm
           JOIN restaurant_mesas_area rma ON rdm.id_area = rma.descripcion
            SET rdm.acumulado = :total,
                rdm.pendiente = :total_p
          WHERE CONCAT(rma.descripcion, '-', rdm.nombre) = :docespera"
    )->execute([':total' => $total, ':total_p' => $total, ':docespera' => $docespera]);

    return $total;
}

function releaseGroupLock(PDO $db, ?string $lockName): void
{
    if (!$lockName) return;
    $stmt = $db->prepare('SELECT RELEASE_LOCK(:lock_name)');
    $stmt->execute([':lock_name' => $lockName]);
}
