<?php
/**
 * POST /api/pedidos/activar-mesa
 * Activa una mesa: crea el registro en factura_espera (si no existe)
 * y marca la mesa como ocupada en restaurant_detalle_mesas.
 *
 * Body JSON:
 *   id_mesa        — id de restaurant_detalle_mesas
 *   id_area        — indicador del área (restaurant_mesas_area.indicador, varchar 10)
 *   indicador_area — siglas del área (restaurant_mesas_area.indicador)
 *   nombre_mesa    — nombre de la mesa (restaurant_detalle_mesas.nombre)
 *   estacion       — identificador del dispositivo
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$user = validateToken();
$body = getRequestBody();

$id_mesa        = trim($body['id_mesa']        ?? '');
$id_area        = trim($body['id_area']        ?? '');
$indicador_area = trim($body['indicador_area'] ?? '');
$nombre_mesa    = trim($body['nombre_mesa']    ?? '');
$estacion       = substr(trim($body['estacion'] ?? 'Web'), 0, 50);

if ($id_mesa === '' || $id_area === '' || $indicador_area === '' || $nombre_mesa === '') {
    sendError('Faltan campos requeridos: id_mesa, id_area, indicador_area, nombre_mesa');
}

// Construir la clave de negocio del pedido
$docespera = $indicador_area . $nombre_mesa;

$db = getDB();

// ── Verificar si ya existe un pedido para esta mesa ───────────
$stmt = $db->prepare(
    "SELECT id, total FROM factura_espera WHERE docespera = :docespera LIMIT 1"
);
$stmt->execute([':docespera' => $docespera]);
$pedidoExistente = $stmt->fetch();

$esNuevo = false;

if (!$pedidoExistente) {
    // Crear nuevo registro de pedido
    $hora = date('H:i:s');
    $stmt = $db->prepare(
        "INSERT INTO factura_espera
            (fecha, hora, docespera, autobck, estacion, id_vendedor, vendedor, total, res_id_mesero, res_mesero)
         VALUES
            (CURDATE(), :hora, :docespera, '0', :estacion, :id_vendedor, :vendedor, '0', :id_vendedor2, :vendedor2)"
    );
    $stmt->execute([
        ':hora'        => $hora,
        ':docespera'   => $docespera,
        ':estacion'    => $estacion,
        ':id_vendedor' => $user['id_vendedor'],
        ':vendedor'    => $user['nombres'],
        ':id_vendedor2' => $user['id_vendedor'],
        ':vendedor2'   => $user['nombres'],
    ]);
    $esNuevo = true;
    $total   = '0';
} else {
    $total = $pedidoExistente['total'];
}

// ── Marcar mesa como ocupada ──────────────────────────────────
$acumSet = $esNuevo ? ", acumulado = '0,00', pendiente = '0,00'" : '';
$stmt = $db->prepare(
    "UPDATE restaurant_detalle_mesas
        SET status         = '2',
            id_mesero      = :id_mesero,
            fecha_activada = CURDATE(),
            hora_activada  = CURTIME()
            {$acumSet}
      WHERE id = :id_mesa"
);
$stmt->execute([
    ':id_mesero' => $user['id_vendedor'],
    ':id_mesa'   => $id_mesa,
]);

sendSuccess([
    'docespera' => $docespera,
    'es_nueva'  => $esNuevo,
    'total'     => $total,
]);
