<?php
/**
 * DELETE /api/pedidos/remover-item
 * Remueve un ítem del pedido.
 * - Ítem pendiente (res_comanda = 0): requiere pos_remover.
 * - Ítem comandado: requiere pos_remitemcom.
 * Si quien está usando la aplicación no cuenta con el permiso, puede
 * autorizar la acción con código y PIN de otro vendedor autorizado.
 *
 * Body JSON:
 *   docespera — clave del pedido
 *   id_item   — detalle_factura_espera.id (campo agregado con ALTER TABLE)
 *   autorizador_id / autorizador_pin — obligatorios solo si la sesión activa
 *     no tiene el permiso requerido para el estado actual del ítem.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendError('Método no permitido', 405);
}

$user = validateToken();

$body      = getRequestBody();
$docespera = trim($body['docespera'] ?? '');
$id_item   = (int) ($body['id_item'] ?? 0);
$autorizadorId  = trim($body['autorizador_id'] ?? '');
$autorizadorPin = trim($body['autorizador_pin'] ?? '');

if ($docespera === '' || $id_item <= 0) {
    sendError('Faltan campos requeridos: docespera, id_item');
}

$db = getDB();

// Leer el estado en servidor: nunca confiar en el estado enviado por el navegador.
$stmt = $db->prepare(
    "SELECT id, res_comanda FROM detalle_factura_espera
      WHERE id = :id AND DocEspera = :docespera
      LIMIT 1"
);
$stmt->execute([':id' => $id_item, ':docespera' => $docespera]);
$item = $stmt->fetch();
if (!$item) {
    sendError('Ítem no encontrado en este pedido', 404);
}

$comandado = $item['res_comanda'] !== null
    && $item['res_comanda'] !== ''
    && $item['res_comanda'] !== '0';
$permiso = $comandado ? 'pos_remitemcom' : 'pos_remover';
$descripcionPermiso = $comandado ? 'productos ya comandados' : 'productos pendientes por comandar';
$autorizadoPor = null;

// La sesión puede autorizar directamente. Si no, se valida el vendedor que
// ingresó su código y PIN para esta operación puntual.
if ((int) ($user[$permiso] ?? 0) === 1) {
    $autorizadoPor = $user['nombres'] ?? null;
} else {
    if ($autorizadorId === '' || $autorizadorPin === '') {
        sendError("Se requiere autorización para remover {$descripcionPermiso}", 403);
    }

    $idNormalizado = normalizarCodigoRemocion($autorizadorId);
    $stmt = $db->prepare(
        "SELECT id_vendedor, nombres, pos_pas, {$permiso}
           FROM vendedores
          WHERE (id_vendedor = :id_vendedor
              OR TRIM(LEADING '0' FROM id_vendedor) = :id_normalizado)
            AND activo = '1'
          LIMIT 1"
    );
    $stmt->execute([
        ':id_vendedor' => $autorizadorId,
        ':id_normalizado' => $idNormalizado,
    ]);
    $autorizador = $stmt->fetch();

    if (!$autorizador || !pinValidoRemocion((string) $autorizador['pos_pas'], $autorizadorPin)) {
        sendError('Código o contraseña de autorización incorrectos', 403);
    }
    if ((int) ($autorizador[$permiso] ?? 0) !== 1) {
        sendError("El usuario no tiene permiso para remover {$descripcionPermiso}", 403);
    }
    $autorizadoPor = $autorizador['nombres'];
}

// Eliminar ítem
$stmt = $db->prepare(
    "DELETE FROM detalle_factura_espera WHERE id = :id AND DocEspera = :docespera"
);
$stmt->execute([':id' => $id_item, ':docespera' => $docespera]);

// Recalcular total — compatible con formato inglés y colombiano
$stmtTotal = $db->prepare(
    "SELECT COALESCE(SUM(CAST(
        CASE WHEN pv LIKE '%,%'
             THEN REPLACE(REPLACE(pv, '.', ''), ',', '.')
             ELSE pv
        END AS DECIMAL(15,2))), 0)
       FROM detalle_factura_espera
      WHERE DocEspera = :docespera"
);
$stmtTotal->execute([':docespera' => $docespera]);
$total = number_format(floatval($stmtTotal->fetchColumn()), 2, ',', '.');

$db->prepare(
    "UPDATE factura_espera SET total = :total WHERE docespera = :docespera"
)->execute([':total' => $total, ':docespera' => $docespera]);

// Actualizar acumulado y pendiente en la mesa
$db->prepare(
    "UPDATE restaurant_detalle_mesas rdm
       JOIN restaurant_mesas_area rma ON rdm.id_area = rma.descripcion
        SET rdm.acumulado = :total,
            rdm.pendiente = :total_p
      WHERE CONCAT(rma.descripcion, '-', rdm.nombre) = :docespera"
)->execute([':total' => $total, ':total_p' => $total, ':docespera' => $docespera]);

sendSuccess([
    'id_item'      => $id_item,
    'total_pedido' => $total,
    'autorizado_por' => $autorizadoPor,
]);

function normalizarCodigoRemocion(string $value): string
{
    $value = ltrim(trim($value), '0');
    return $value === '' ? '0' : $value;
}

function pinValidoRemocion(string $pinGuardado, string $pinIngresado): bool
{
    $pinGuardado = trim($pinGuardado);
    $pinIngresado = trim($pinIngresado);
    return hash_equals($pinGuardado, $pinIngresado)
        || normalizarCodigoRemocion($pinGuardado) === normalizarCodigoRemocion($pinIngresado);
}
