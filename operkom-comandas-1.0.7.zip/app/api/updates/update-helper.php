<?php

const UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/anderg1501/OperkomComandasUpdates/main/update.json';

function getCurrentAppVersion(): string
{
    $versionPath = dirname(__DIR__, 2) . '/app-version.json';
    if (!file_exists($versionPath)) {
        return '0.0.0';
    }

    $data = json_decode((string) file_get_contents($versionPath), true);
    return is_array($data) && isset($data['version']) ? (string) $data['version'] : '0.0.0';
}

function fetchUpdateManifest(): array
{
    // El parámetro evita respuestas antiguas guardadas por proxies o CDN.
    $manifestUrl = UPDATE_MANIFEST_URL . '?_=' . rawurlencode((string) time());
    $context = stream_context_create([
        'http' => ['timeout' => 8],
        'https' => ['timeout' => 8],
    ]);
    $body = @file_get_contents($manifestUrl, false, $context);

    // Las primeras instalaciones distribuidas no tenían OpenSSL habilitado en
    // PHP. curl.exe viene con Windows moderno y permite que esos equipos sigan
    // pudiendo actualizarse sin reinstalar toda la aplicación.
    if ($body === false && function_exists('shell_exec')) {
        $command = 'curl.exe --fail --location --silent --show-error --max-time 12 ' . escapeshellarg($manifestUrl) . ' 2>NUL';
        $downloaded = @shell_exec($command);
        if (is_string($downloaded) && $downloaded !== '') {
            $body = $downloaded;
        }
    }

    if ($body === false) {
        throw new RuntimeException('No se pudo consultar el servicio de actualizaciones. Verifica la conexión a Internet.');
    }

    $manifest = json_decode($body, true);
    if (!is_array($manifest)
        || !isset($manifest['version'], $manifest['package_url'], $manifest['sha256'])
        || !preg_match('/^\d+(\.\d+){2,3}$/', (string) $manifest['version'])
        || !preg_match('/^https:\/\//', (string) $manifest['package_url'])
        || !preg_match('/^[A-Fa-f0-9]{64}$/', (string) $manifest['sha256'])) {
        throw new RuntimeException('El manifiesto de actualización no es válido.');
    }

    return $manifest;
}

function isUpdateAvailable(string $currentVersion, string $availableVersion): bool
{
    return version_compare($availableVersion, $currentVersion, '>');
}

function requireUpdateAdministrator(): void
{
    $user = validateToken();
    if ((int) ($user['pos_admin'] ?? 0) !== 1) {
        sendError('Se requiere un usuario administrador para actualizar la aplicación', 403);
    }
}
