<?php
/**
 * Operkom Comandas Web — Configuración global
 * Los valores reales se cargan desde config.local.php (no versionado)
 * Si config.local.php no existe, se redirige al asistente de setup.
 */

// ── Cargar configuración local si existe (debe ir antes de defaults DB) ──────
require_once __DIR__ . '/config-paths.php';
$configLocalPath = getLocalConfigPath();
if (file_exists($configLocalPath)) {
    require_once $configLocalPath;
}

// ── Zona horaria de la aplicación ───────────────────────────
if (!defined('APP_TIMEZONE')) {
    define('APP_TIMEZONE', 'America/Bogota');
}
date_default_timezone_set(APP_TIMEZONE);

// ── Base de datos — valores por defecto si no fueron definidos ───────────────
if (!defined('DB_HOST')) {
    define('DB_HOST', '');
}
if (!defined('DB_PORT')) {
    define('DB_PORT', 3306);
}
if (!defined('DB_NAME')) {
    define('DB_NAME', '');
}
if (!defined('DB_USER')) {
    define('DB_USER', '');
}
if (!defined('DB_PASS')) {
    define('DB_PASS', '');
}
if (!defined('DB_CHARSET')) {
    define('DB_CHARSET', 'utf8mb4');
}

// ── Licenciamiento remoto ────────────────────────────────────
// Una instalación queda en modo de transición mientras no tenga URL y clave.
// Al completar ambos valores desde Configuración, el control remoto se aplica
// a todos los endpoints operativos. Esto permite desplegar la actualización
// antes de matricular uno por uno a los clientes existentes.
if (!defined('LICENSE_SERVER_URL')) {
    define('LICENSE_SERVER_URL', '');
}
if (!defined('LICENSE_KEY')) {
    define('LICENSE_KEY', '');
}
if (!defined('LICENSE_CHECK_INTERVAL')) {
    define('LICENSE_CHECK_INTERVAL', 300); // 5 minutos
}
if (!defined('LICENSE_OFFLINE_GRACE')) {
    define('LICENSE_OFFLINE_GRACE', 259200); // 72 horas
}
if (!defined('LICENSE_REQUIRE_CONFIGURATION')) {
    define('LICENSE_REQUIRE_CONFIGURATION', false);
}

// ── Servicio de impresión ─────────────────────────────────────
define('PRINT_SERVICE_URL', 'http://127.0.0.1:9000/print');
define('PRINT_TIMEOUT',     2);

// ── Sesiones ─────────────────────────────────────────────────
define('SESSION_PATH',   __DIR__ . '/../sessions/');
define('SESSION_EXPIRE', 86400);   // 24 horas en segundos

// ── Headers HTTP ─────────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
// CORS: permitir frontend en Apache/XAMPP y en dev server (localhost:3000)
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowedOrigins = [
    'http://localhost',
    'http://127.0.0.1',
    'http://localhost:3000',
    'http://127.0.0.1:3000',
    'http://localhost:8081',
    'http://127.0.0.1:8081',
];
if (in_array($origin, $allowedOrigins, true)) {
    header('Access-Control-Allow-Origin: ' . $origin);
    header('Vary: Origin');
} else {
    // Fallback para despliegues donde no se envía Origin (same-origin)
    header('Access-Control-Allow-Origin: *');
}

header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('X-Content-Type-Options: nosniff');


// Responder preflight CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
