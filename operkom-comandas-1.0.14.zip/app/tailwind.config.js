/** @type {import('tailwindcss').Config} */
module.exports = {
    darkMode: 'class',
    content: [
        './index.html',
        './setup.html',
        './assets/js/**/*.js',
    ],
    theme: {
        extend: {
            screens: {
                tablet: '900px',
            },
        },
    },
    plugins: [],
};
