/**
 * cache.js — Gestión del caché en localStorage.
 * Categorías y productos se almacenan 24 horas para navegación inmediata.
 */

const CACHE_VERSION = 'v3';   // Incrementar cuando cambie la estructura de datos

const CACHE_KEYS = {
    categorias: `operkom_cache_categorias_${CACHE_VERSION}`,
    productos:  `operkom_cache_productos_${CACHE_VERSION}`,
    empresa:    `operkom_cache_empresa_${CACHE_VERSION}`,
};

const CACHE_TTL = 30 * 60 * 1000; // 30 minutos

const Cache = {

    set(key, data) {
        try {
            const entry = { ts: Date.now(), data };
            localStorage.setItem(key, JSON.stringify(entry));
        } catch (e) {
            // localStorage puede estar lleno o deshabilitado; no es crítico
            console.warn('[Cache] Error al escribir:', key, e);
        }
    },

    get(key) {
        try {
            const raw = localStorage.getItem(key);
            if (!raw) return null;
            const entry = JSON.parse(raw);
            if (!entry || Date.now() - entry.ts > CACHE_TTL) {
                localStorage.removeItem(key);
                return null;
            }
            return entry.data;
        } catch {
            return null;
        }
    },

    invalidate(key) {
        localStorage.removeItem(key);
    },

    invalidateAll() {
        Object.values(CACHE_KEYS).forEach(k => localStorage.removeItem(k));
    },

    // Elimina keys de versiones anteriores que quedaron en localStorage
    purgeOldVersions() {
        const currentKeys = new Set(Object.values(CACHE_KEYS));
        Object.keys(localStorage)
            .filter(k => k.startsWith('operkom_cache_') && !currentKeys.has(k))
            .forEach(k => localStorage.removeItem(k));
    },
};
