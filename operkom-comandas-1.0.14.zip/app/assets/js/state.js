/**
 * state.js — Estado global de la aplicación Operkom Comandas Web
 * Objeto único que centraliza todo el estado de la SPA.
 * No se modifica directamente desde afuera; cada módulo lo actualiza
 * a través de sus propias funciones.
 */
const AppState = {
    // ── Sesión activa ──────────────────────────────────────────
    /** @type {{token, id_vendedor, nombres, pos_remover, empresa}|null} */
    session: null,

    // ── Navegación ────────────────────────────────────────────
    /** @type {'login'|'mesas'|'pedido'} */
    vista_actual: 'login',

    // ── Áreas y mesas ─────────────────────────────────────────
    /** @type {Array<{id, descripcion, indicador, deposito}>} */
    areas: [],

    /** @type {{id, descripcion, indicador, deposito}|null} */
    area_seleccionada: null,

    /** @type {Array<{id, nombre, estatus, acumulado, id_mesero, id_area}>} */
    mesas: [],

    /** @type {{id, nombre, estatus, id_area}|null} */
    mesa_activa: null,

    // ── Pedido activo ─────────────────────────────────────────
    /** Clave del pedido: indicador_area + nombre_mesa  (ej: "SGMesa 5") */
    docespera: null,

    /** @type {Array<{id, idarticulo, articulo, pu, cantidad, pv, res_notas, categoria_d, res_imp_com}>} */
    pedido_items: [],

    /** Total del pedido como string numérico (igual que en BD) */
    pedido_total: '0',

    // ── Catálogo (desde localStorage) ────────────────────────
    /** @type {Array<{id_categoria, categoria, imagen, imp_comanda, color_css}>} */
    categorias: [],

    /**
     * Productos indexados por id_categoria para acceso O(1).
     * @type {Object.<string, Array>}
     */
    productos: {},

    /** id_categoria de la categoría seleccionada actualmente */
    categoria_activa: null,

    // ── UI ────────────────────────────────────────────────────
    loading: false,

    /** Ítem del pedido que se está editando en el modal */
    item_editando: null,
};
