/**
 * login.js — Vista de autenticación del mesero.
 * Flujo: 1) Seleccionar nombre de la lista → 2) Ingresar PIN con teclado numérico
 */

const LoginView = {

    _selectedId:   null,   // id_vendedor seleccionado
    _pin:          '',     // PIN ingresado (máx 20 chars)

    _escapeHtml(text) {
        return String(text || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    },

    _renderMeserosError(err) {
        // Detectar si es error de configuracion (BD no disponible)
        const isConfigError = err?.status === 503 || 
                              err?.userMessage?.includes('configurada') ||
                              err?.technicalMessage?.includes('configurada') ||
                              err?.message?.includes('configurada');
        
        if (isConfigError) {
            return `<div class="col-span-full rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-left">
                <p class="text-amber-300 font-semibold">[CONFIG] Sistema no configurado</p>
                <p class="text-amber-200/90 text-sm mt-1">La base de datos aun no ha sido configurada.</p>
                <div class="mt-3 flex gap-2">
                    <button class="px-3 py-2 rounded-md bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold"
                        onclick="window.location.href = 'setup.html'">Ir a Configuracion</button>
                    <button class="px-3 py-2 rounded-md bg-slate-600 hover:bg-slate-700 text-white text-xs font-semibold"
                        onclick="LoginView._cargarMeseros()">Reintentar</button>
                </div>
            </div>`;
        }
        
        // Error generico
        const msg = err?.userMessage || err?.message || 'Error al cargar meseros';
        const technical = Api.debugError ? Api.debugError(err) : (err?.stack || err?.message || 'Sin detalle técnico');
        return `<div class="col-span-full rounded-xl border border-rose-500/40 bg-rose-500/10 p-4 text-left">
            <p class="text-rose-300 font-semibold">No se pudo cargar la lista de meseros</p>
            <p class="text-rose-200/90 text-sm mt-1">${LoginView._escapeHtml(msg)}</p>
            <div class="mt-3 flex gap-2">
                <button class="px-3 py-2 rounded-md bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold"
                    onclick="LoginView._cargarMeseros()">Reintentar</button>
                <button class="px-3 py-2 rounded-md bg-slate-600 hover:bg-slate-700 text-white text-xs font-semibold"
                    onclick="window.location.href = 'setup.html?edit=1'">Cambiar conexión</button>
            </div>
            <details class="mt-3 text-xs text-slate-200/90">
                <summary class="cursor-pointer select-none">Ver detalle técnico</summary>
                <pre class="mt-2 whitespace-pre-wrap break-words rounded-md bg-slate-900/70 p-3 border border-slate-700/60">${LoginView._escapeHtml(technical)}</pre>
            </details>
        </div>`;
    },

    // ─────────────────────────────────────────────────────────────────────
    // Init
    // ─────────────────────────────────────────────────────────────────────

    init() {
        // Si ya hay sesión activa, navegar directo a mesas
        const raw = sessionStorage.getItem('operkom_session');
        if (raw) {
            try {
                const session = JSON.parse(raw);
                if (session?.token) {
                    AppState.session = session;
                    LoginView._restoreCache();
                    Router.navigate('mesas');
                    return;
                }
            } catch { /* sesión corrupta, continuar */ }
        }

        LoginView._selectedId = null;
        LoginView._pin        = '';

        // Mostrar nombre empresa si está en caché
        const empresa = Cache.get(CACHE_KEYS.empresa);
        if (empresa?.empresa) {
            const el = document.getElementById('login-empresa');
            if (el) el.textContent = empresa.empresa;
        }

        // Mostrar paso 1 (meseros), ocultar paso 2 (PIN)
        document.getElementById('login-step-mesero').classList.remove('hidden');
        document.getElementById('login-step-pin').classList.add('hidden');

        LoginView._cargarMeseros();
    },

    // ─────────────────────────────────────────────────────────────────────
    // Paso 1: cargar y mostrar meseros
    // ─────────────────────────────────────────────────────────────────────

    async _cargarMeseros() {
        const grid = document.getElementById('login-meseros-grid');
        if (!grid) return;

        grid.innerHTML = `<div class="col-span-full text-center text-slate-600 py-6">
            <div class="loading-spinner mx-auto"></div></div>`;

        try {
            const res = await Api.auth.vendedores();
            if (!res.success) {
                const meta = res?.__apiMeta || {};
                const apiErr = new Error(res.error || 'La API respondió success=false al cargar meseros.');
                apiErr.name = 'ApiLogicalError';
                apiErr.userMessage = res.error || 'No fue posible listar meseros.';
                apiErr.technicalMessage = res.error || '';
                apiErr.endpoint = meta.endpoint || '/auth/vendedores.php';
                apiErr.method = meta.method || 'GET';
                apiErr.status = meta.status || 200;
                apiErr.responseBody = res;
                apiErr.timestamp = new Date().toISOString();
                throw apiErr;
            }

            const empresaApi = (res.data?.[0]?.empresa || '').trim();
            if (empresaApi) {
                const elEmpresa = document.getElementById('login-empresa');
                if (elEmpresa) elEmpresa.textContent = empresaApi;
                Cache.set(CACHE_KEYS.empresa, { empresa: empresaApi });
            }

            if (!res.data?.length) {
                grid.innerHTML = `<p class="col-span-full text-center text-slate-500 py-6">
                    Sin meseros activos</p>`;
                return;
            }
            grid.innerHTML = res.data.map(v => {
                const nombreSafe = v.nombres.replace(/"/g, '&quot;');
                const idSafe     = String(v.id_vendedor).replace(/'/g, '');
                const initials   = v.nombres.trim().split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
                return `<button class="mesero-btn"
                    onclick="LoginView.seleccionarMesero('${idSafe}', '${nombreSafe}')">
                    <span class="mesero-avatar">${initials}</span>
                    <span class="mesero-nombre">${v.nombres}</span>
                </button>`;
            }).join('');
        } catch (err) {
            grid.innerHTML = LoginView._renderMeserosError(err);
            console.error('[LoginView] _cargarMeseros:', err);
        }
    },

    // ─────────────────────────────────────────────────────────────────────
    // Paso 2: mostrar teclado PIN
    // ─────────────────────────────────────────────────────────────────────

    seleccionarMesero(id, nombre) {
        LoginView._selectedId = id;
        LoginView._pin        = '';

        const el = document.getElementById('login-nombre-seleccionado');
        if (el) el.textContent = nombre;

        document.getElementById('login-step-mesero').classList.add('hidden');
        document.getElementById('login-step-pin').classList.remove('hidden');

        LoginView._updatePinDots();
    },

    volverMeseros() {
        LoginView._selectedId = null;
        LoginView._pin        = '';
        document.getElementById('login-step-pin').classList.add('hidden');
        document.getElementById('login-step-mesero').classList.remove('hidden');
    },

    // ─────────────────────────────────────────────────────────────────────
    // Teclado numérico
    // ─────────────────────────────────────────────────────────────────────

    pinKey(value) {
        if (value === 'clear') {
            LoginView._pin = '';
        } else if (value === 'back') {
            LoginView._pin = LoginView._pin.slice(0, -1);
        } else {
            if (LoginView._pin.length >= 20) return;
            LoginView._pin += value;
        }
        LoginView._updatePinDots();
    },

    _updatePinDots() {
        const len  = LoginView._pin.length;
        document.querySelectorAll('.pin-dot').forEach((dot, i) => {
            dot.classList.toggle('bg-orange-500', i < len);
            dot.classList.toggle('bg-slate-700',  i >= len);
        });
    },

    // ─────────────────────────────────────────────────────────────────────
    // Autenticar
    // ─────────────────────────────────────────────────────────────────────

    async submitPin() {
        if (!LoginView._selectedId) {
            Toast.show('Selecciona un mesero primero', 'error');
            return;
        }
        if (!LoginView._pin) {
            Toast.show('Ingresa tu PIN', 'error');
            return;
        }

        const btn = document.getElementById('btn-login');
        btn.disabled    = true;
        btn.textContent = 'Verificando...';

        try {
            const res = await Api.auth.login(LoginView._selectedId, LoginView._pin);

            if (!res.success) {
                LoginView._pin = '';
                LoginView._updatePinDots();
                Toast.show(res.error || 'PIN incorrecto', 'error');
                return;
            }

            const session = {
                token:       res.data.token,
                id_vendedor: res.data.id_vendedor,
                nombres:     res.data.nombres,
                pos_remover: res.data.pos_remover,
                empresa:     res.data.empresa,
            };
            sessionStorage.setItem('operkom_session', JSON.stringify(session));
            AppState.session = session;

            Cache.set(CACHE_KEYS.empresa, { empresa: res.data.empresa });
            const elEmpresa = document.getElementById('login-empresa');
            if (elEmpresa) elEmpresa.textContent = res.data.empresa;

            LoginView._loadCache();
            Router.navigate('mesas');

        } catch (err) {
            Toast.show(err.userMessage || err.message || 'Error de conexión', 'error');
        } finally {
            btn.disabled    = false;
            btn.textContent = 'INGRESAR';
        }
    },

    // ─────────────────────────────────────────────────────────────────────
    // Caché background
    // ─────────────────────────────────────────────────────────────────────

    async _loadCache() {
        try {
            let categorias = Cache.get(CACHE_KEYS.categorias);
            if (!categorias) {
                const res = await Api.productos.categorias();
                if (res.success) {
                    Cache.set(CACHE_KEYS.categorias, res.data);
                    categorias = res.data;
                }
            }
            AppState.categorias = categorias || [];
        } catch (err) {
            console.warn('[LoginView] Error cargando caché:', err);
        }
    },

    _restoreCache() {
        const cats = Cache.get(CACHE_KEYS.categorias);
        if (cats) AppState.categorias = cats;
        if (!cats) LoginView._loadCache();
    },
};
