/**
 * pedido.js — Vista principal de toma de pedido.
 * Gestiona los tres paneles: Categorías | Productos | Pedido actual.
 * También maneja los modales de notas y acciones de ítem.
 */

const PedidoView = {

    _eventsBound: false,   // guard contra doble binding de event listeners
    _busqueda:    '',      // texto de búsqueda activo
    _timerInterval: null,  // intervalo del timer de mesa
    _lpLastConfirm: 0,    // timestamp de la última confirmación del picker de cantidad
    _skipNextTap: null,   // id_producto cuya tarjeta tiene bloqueado el siguiente onclick
    _pickerProductoId: null, // id_producto pendiente en el picker de cantidad

    // ── Inicialización ────────────────────────────────────────

    init() {
        const session = AppState.session;
        if (!session?.token || !AppState.mesa_activa) {
            Router.navigate('login');
            return;
        }

        const mesa = AppState.mesa_activa;
        const area = mesa.area;

        // Header
        document.getElementById('pedido-mesa-nombre').textContent = mesa.nombre;
        document.getElementById('pedido-area-nombre').textContent = area.descripcion;
        document.getElementById('pedido-mesero-nombre').textContent = session.nombres.split(' ')[0];
        document.getElementById('mobile-mesa-header').textContent = `${mesa.nombre} — ${area.descripcion}`;

        // Asegurar que el caché esté cargado
        if (!AppState.categorias.length) {
            this._loadCacheYRenderizar();
        } else {
            this._renderCategorias();
            const activa = AppState.categoria_activa || '__TODOS__';
            this._selectCategoria(activa);
        }

        this._renderPedido();
        this._bindEvents();
        this._iniciarTimerMesa();
    },

    async _loadCacheYRenderizar() {
        try {
            const resCats = await Api.productos.categorias();
            if (resCats.success) {
                Cache.set(CACHE_KEYS.categorias, resCats.data);
                AppState.categorias = resCats.data;
            }
        } catch (err) {
            Toast.show('Error cargando catálogo', 'error');
        }

        this._renderCategorias();
        if (AppState.categorias.length) {
            this._selectCategoria('__TODOS__');
        }
    },

    // Carga todos los productos de todas las categorías en paralelo
    async _loadTodos() {
        const panel = document.getElementById('panel-productos');
        panel.innerHTML = '<div class="col-span-full flex justify-center py-12"><div class="loading-spinner"></div></div>';

        const cats = AppState.categorias;
        // Cargar solo las categorías que aún no están en caché
        const pendientes = cats.filter(c => !AppState.productos[c.id_categoria]);

        await Promise.all(pendientes.map(c =>
            Api.productos.byCategoria(c.id_categoria)
                .then(res => { if (res.success) AppState.productos[c.id_categoria] = res.data; })
                .catch(() => {})
        ));

        // Combinar todos en orden de categorías
        const todos = cats.flatMap(c => AppState.productos[c.id_categoria] || []);
        AppState.productos['__TODOS__'] = todos;

        this._renderProductos('__TODOS__');
    },

    async loadPedido() {
        if (!AppState.docespera) return;
        try {
            const res = await Api.pedidos.get(AppState.docespera);
            if (res.success) {
                AppState.pedido_items = res.data.items;
                AppState.pedido_total = res.data.total;
                this._renderPedido();
            }
        } catch (err) {
            console.warn('[PedidoView] Error cargando pedido:', err);
        }
    },

    // ── Categorías ────────────────────────────────────────────

    _renderCategorias() {
        const cats = AppState.categorias;
        if (!cats.length) return;

        const buildBtn = (id, label, extraCls = '', imagen = null, colorCss = null) => {
            const isActive = id === (AppState.categoria_activa || '__TODOS__');
            return `
                <button
                    onclick="PedidoView._selectCategoria('${id}')"
                    id="cat-btn-${id}"
                    data-cat="${id}"
                    class="cat-btn ${extraCls} text-left rounded-xl transition-all duration-150 font-semibold
                           ${isActive ? 'cat-btn-active' : ''}"
                    >
                    ${imagen ? `<img src="${imagen}" alt="" class="w-6 h-6 rounded-md object-cover flex-shrink-0" onerror="this.style.display='none'">` : ''}
                    <span class="truncate">${label}</span>
                </button>
            `;
        };

        const hasFavs = this._hasFavoritos();

        const freqBtnL = hasFavs ? buildBtn('__FRECUENTES__', '★ Frecuentes', 'flex items-center gap-2 w-full px-3 py-3 text-sm') : '';
        const freqBtnM = hasFavs ? buildBtn('__FRECUENTES__', '★ Frecuentes', 'flex items-center gap-1.5 flex-shrink-0 px-3 py-2 text-sm whitespace-nowrap') : '';

        const todosBtn_lateral  = buildBtn('__TODOS__', 'Todos', 'flex items-center gap-2 w-full px-3 py-3 text-sm');
        const todosBtn_mobile   = buildBtn('__TODOS__', 'Todos', 'flex items-center gap-1.5 flex-shrink-0 px-3 py-2 text-sm whitespace-nowrap');

        // Panel lateral (desktop)
        const panel = document.getElementById('panel-categorias');
        if (panel) {
            panel.innerHTML = freqBtnL + todosBtn_lateral + cats.map(c =>
                buildBtn(c.id_categoria, c.categoria, 'flex items-center gap-2 w-full px-3 py-3 text-sm', c.imagen, c.color_css)
            ).join('');
        }

        // Scroll horizontal (móvil)
        const panelMobile = document.getElementById('panel-categorias-mobile');
        if (panelMobile) {
            panelMobile.innerHTML = freqBtnM + todosBtn_mobile + cats.map(c =>
                buildBtn(c.id_categoria, c.categoria, 'flex items-center gap-1.5 flex-shrink-0 px-3 py-2 text-sm whitespace-nowrap', c.imagen, c.color_css)
            ).join('');
        }
    },

    _selectCategoria(id_categoria) {
        AppState.categoria_activa = id_categoria;

        // Limpiar búsqueda al cambiar categoría
        PedidoView._busqueda = '';
        const inp = document.getElementById('buscador-productos');
        if (inp) inp.value = '';
        document.getElementById('btn-limpiar-busqueda')?.classList.add('hidden');

        // Resaltar botón activo
        document.querySelectorAll('.cat-btn').forEach(b => {
            const isActive = b.dataset.cat === id_categoria;
            b.classList.toggle('cat-btn-active', isActive);
        });

        // Caso especial: FRECUENTES
        if (id_categoria === '__FRECUENTES__') {
            if (!AppState.productos['__TODOS__']) {
                this._loadTodos().then(() => {
                    AppState.productos['__FRECUENTES__'] = this._getFavProductos();
                    this._renderProductos('__FRECUENTES__');
                });
            } else {
                AppState.productos['__FRECUENTES__'] = this._getFavProductos();
                this._renderProductos('__FRECUENTES__');
            }
            return;
        }

        // Caso especial: TODOS
        if (id_categoria === '__TODOS__') {
            if (AppState.productos['__TODOS__']) {
                this._renderProductos('__TODOS__');
            } else {
                this._loadTodos();
            }
            return;
        }

        // Si ya tenemos los productos en memoria, renderizar directo
        if (AppState.productos[id_categoria]) {
            this._renderProductos(id_categoria);
            return;
        }

        // Carga lazy desde la API
        const panel = document.getElementById('panel-productos');
        panel.innerHTML = '<div class="col-span-full flex justify-center py-12"><div class="loading-spinner"></div></div>';

        Api.productos.byCategoria(id_categoria)
            .then(res => {
                if (res.success) {
                    AppState.productos[id_categoria] = res.data;
                    // Invalidar caché de TODOS para que se regenere con el nuevo dato
                    delete AppState.productos['__TODOS__'];
                }
                this._renderProductos(id_categoria);
            })
            .catch(() => {
                this._renderProductos(id_categoria);
            });
    },

    // ── Productos ─────────────────────────────────────────────

    _renderProductos(id_categoria) {
        const panel    = document.getElementById('panel-productos');
        let productos  = AppState.productos[id_categoria] || [];

        // Aplicar filtro de búsqueda si está activo
        const busqueda = (PedidoView._busqueda || '').trim().toLowerCase();
        if (busqueda) {
            productos = productos.filter(p =>
                p.descripcion1.toLowerCase().includes(busqueda)
            );
        }

        if (!productos.length) {
            panel.innerHTML = `
                <div class="col-span-full flex flex-col items-center justify-center py-16 text-slate-600">
                    <svg class="w-12 h-12 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                              d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                    </svg>
                    <p>${busqueda ? 'Sin resultados para "' + busqueda + '"' : 'No hay productos en esta categoría'}</p>
                </div>`;
            return;
        }

        panel.innerHTML = productos.map(prod => this._buildProductCard(prod)).join('');
    },

    _buildProductCard(prod) {
        const precio    = parsePrecio(prod.precio_venta1);
        const precioFmt = formatPrecio(precio);
        const imgUrl    = this._imgUrl(prod.imagen);

        return `
            <div data-producto-id="${prod.id_producto}"
                 onclick="PedidoView._onCardTap('${prod.id_producto}')"
                 class="product-card relative rounded-2xl overflow-hidden cursor-pointer select-none
                        active:scale-95 transition-none
                        border border-slate-200 dark:border-slate-700/50
                        bg-white dark:bg-slate-800 flex flex-col"
                       >

                ${imgUrl ? `
                <div class="h-32 sm:h-36 overflow-hidden flex-shrink-0 bg-white dark:bg-slate-700/40 flex items-center justify-center p-1">
                    <img src="${imgUrl}" alt="${prod.descripcion1}"
                         class="max-h-full max-w-full object-contain"
                         onerror="this.parentElement.style.display='none'">
                </div>` : `<div class="h-8"></div>`}

                <!-- Info -->
                <div class="flex-1 px-2.5 pb-2.5 pt-1.5 flex flex-col justify-between">
                    <p class="font-semibold text-xs leading-snug line-clamp-2
                               text-slate-800 dark:text-slate-100">
                        ${prod.descripcion1}
                    </p>
                    <p class="product-price font-bold text-sm mt-1">
                        $${precioFmt}
                    </p>
                </div>

                <!-- Botón + -->
                <div class="product-add-btn absolute top-2 right-2 w-6 h-6 rounded-full shadow
                            flex items-center justify-center">
                    <svg class="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M12 4v16m8-8H4"/>
                    </svg>
                </div>
            </div>
        `;
    },

    // Convierte ruta de BD (separadores '|') a URL del proxy de imagen
    _imgUrl(rawPath) {
        if (!rawPath) return null;
        return `${API_BASE}/productos/imagen.php?p=${encodeURIComponent(rawPath)}`;
    },

    // ── Tap en tarjeta de producto ─────────────────────────────
    // Wrapper centralizado para proteger contra long-press y ghost clicks.

    _onCardTap(id_producto) {
        // Si el long-press marcó esta tarjeta, es el click del release → ignorar
        if (PedidoView._skipNextTap === id_producto) {
            PedidoView._skipNextTap = null;
            return;
        }
        // Ignorar ghost click generado tras confirmar en el picker
        if (Date.now() - PedidoView._lpLastConfirm < 800) return;
        PedidoView.agregarProducto(id_producto);
    },

    // ── Agregar producto al pedido ────────────────────────────

    async agregarProducto(id_producto, cantidad = 1) {
        if (!AppState.docespera) { Toast.show('Selecciona una mesa primero', 'error'); return; }

        // Feedback visual inmediato
        this._flashProductCard(id_producto);
        this._registrarFavorito(id_producto);

        try {
            const res = await Api.pedidos.agregarItem({
                docespera:   AppState.docespera,
                id_producto: id_producto,
                cantidad:    cantidad,
                notas:       '',
            });

            if (!res.success) { Toast.show(res.error, 'error'); return; }

            const index = AppState.pedido_items.findIndex(item => item.id === res.data.item.id);
            if (index >= 0) {
                AppState.pedido_items[index] = res.data.item;
            } else {
                AppState.pedido_items.push(res.data.item);
            }
            AppState.pedido_total = res.data.total_pedido;
            this._renderPedido();

        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    _flashProductCard(id_producto) {
        const card = document.querySelector(`[data-producto-id="${id_producto}"]`);
        if (!card) return;

        // Solo se actualiza la tarjeta pulsada: sin renders ni esperas de red.
        card.classList.remove('product-card--added');
        clearTimeout(card._productFeedbackTimer);
        cancelAnimationFrame(card._productFeedbackFrame);

        card._productFeedbackFrame = requestAnimationFrame(() => {
            card.classList.add('product-card--added');
            card._productFeedbackTimer = setTimeout(() => {
                card.classList.remove('product-card--added');
            }, 850);
        });
    },

    // ── Panel de pedido ───────────────────────────────────────

    _renderPedido() {
        const items    = AppState.pedido_items;
        const total    = parsePrecio(AppState.pedido_total || '0');
        const totalFmt = `$${formatPrecio(total)}`;
        const count    = items.length;

        const listHTML = items.length
            ? items.map(item => this._buildItemRow(item)).join('')
            : `<div class="flex flex-col items-center justify-center h-full text-slate-600 py-8">
                   <svg class="w-10 h-10 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                             d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                   </svg>
                   <p class="text-sm">Pedido vacío</p>
               </div>`;

        // Panel desktop
        document.getElementById('pedido-items-list').innerHTML   = listHTML;
        document.getElementById('pedido-total-display').textContent = totalFmt;

        // Panel mobile (sheet)
        document.getElementById('mobile-items-list').innerHTML    = listHTML;
        document.getElementById('mobile-total-display').textContent = totalFmt;

        // Badge móvil
        document.getElementById('mobile-items-count').textContent = count;
        document.getElementById('mobile-total').textContent       = totalFmt;

        // Habilitar/deshabilitar botón comanda
        const btns = document.querySelectorAll('.btn-enviar-comanda');
        btns.forEach(b => { b.disabled = count === 0; });
    },

    _buildItemRow(item) {
        const precio    = parsePrecio(item.pv);
        const precioFmt = formatPrecio(precio);
        const session   = AppState.session;
        const comandado = item.res_comanda !== '0' && item.res_comanda !== '' && item.res_comanda != null;
        const canEdit   = !comandado;
        const canRemove = !comandado && session?.pos_remover === 1;

        return `
            <div class="item-pedido px-2.5 pt-2 pb-1.5 rounded-xl
                        hover:bg-slate-200/60 dark:hover:bg-slate-700/40 transition-colors
                        ${comandado ? 'opacity-60' : ''}" data-item-id="${item.id}">

                <!-- Línea 1: cantidad × nombre + precio -->
                <div class="flex items-start gap-1.5 min-w-0">
                    <span class="text-orange-500 dark:text-orange-400 font-bold text-xs flex-shrink-0 mt-0.5">${item.cantidad}×</span>
                    <p class="text-slate-800 dark:text-slate-100 text-xs font-medium leading-snug flex-1 min-w-0 break-words">${item.articulo}</p>
                    <span class="text-slate-700 dark:text-slate-200 text-xs font-semibold flex-shrink-0 mt-0.5">$${precioFmt}</span>
                </div>

                ${item.res_notas
                    ? `<p class="text-xs text-slate-500 dark:text-slate-400 italic truncate mt-0.5 pl-5">📝 ${item.res_notas}</p>`
                    : ''}

                <!-- Línea 2: botones de acción -->
                <div class="flex items-center gap-1.5 mt-1.5 pl-5">
                    ${comandado
                        ? `<span class="text-xs text-emerald-400 font-semibold">✓ Comandado</span>`
                        : `
                        ${canEdit ? `
                        <button onclick="PedidoView.cambiarCantidad(${item.id}, -1)"
                                title="Quitar uno"
                                class="h-7 w-7 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 flex items-center
                                       justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors flex-shrink-0">
                            <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M20 12H4"/>
                            </svg>
                        </button>
                        <button onclick="PedidoView.cambiarCantidad(${item.id}, +1)"
                                title="Agregar uno"
                                class="h-7 w-7 rounded-lg bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 flex items-center
                                       justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors flex-shrink-0">
                            <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M12 4v16m8-8H4"/>
                            </svg>
                        </button>` : ''}

                        <button onclick="PedidoView._abrirNotasDirecto(${item.id})"
                                title="Agregar nota"
                                class="h-7 w-7 rounded-lg bg-amber-100 dark:bg-slate-700 hover:bg-amber-200 dark:hover:bg-amber-700
                                       text-amber-600 dark:text-amber-400 hover:text-amber-800 dark:hover:text-white transition-colors
                                       flex items-center justify-center flex-shrink-0">
                            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5
                                         m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                            </svg>
                        </button>

                        ${canRemove ? `
                        <button onclick="PedidoView.removerItemDirecto(${item.id})"
                                title="Eliminar"
                                class="h-7 px-2 rounded-lg bg-rose-100 dark:bg-rose-900/60 hover:bg-rose-600 dark:hover:bg-rose-700 flex items-center
                                       gap-1 text-rose-600 dark:text-rose-400 hover:text-white transition-colors text-xs flex-shrink-0">
                            <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"
                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7
                                         m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                            <span class="hidden sm:inline">Borrar</span>
                        </button>` : ''}
                    `}
                </div>
            </div>
        `;
    },

    // ── Cambiar cantidad inline ───────────────────────────────

    async cambiarCantidad(itemId, delta) {
        if (!AppState.docespera) return;
        try {
            const res = await Api.pedidos.cambiarCantidad({
                docespera: AppState.docespera,
                id_item:   itemId,
                delta,
            });
            if (!res.success) { Toast.show(res.error, 'error'); return; }

            if (res.data.eliminado) {
                AppState.pedido_items = AppState.pedido_items.filter(i => i.id !== itemId);
            } else {
                const item = AppState.pedido_items.find(i => i.id === itemId);
                if (item) {
                    item.cantidad = String(res.data.nueva_cantidad);
                    // Recalcular pv del ítem localmente para evitar otro fetch
                    const pu    = parsePrecio(item.pu);
                    item.pv     = String((pu * res.data.nueva_cantidad).toFixed(2));
                }
            }
            AppState.pedido_total = res.data.total_pedido;
            this._renderPedido();
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    // ── Remover ítem directamente (botón basura inline) ───────

    async removerItemDirecto(itemId) {
        if (!AppState.docespera) return;
        try {
            const res = await Api.pedidos.removerItem({
                docespera: AppState.docespera,
                id_item:   itemId,
            });
            if (!res.success) { Toast.show(res.error, 'error'); return; }

            AppState.pedido_items = AppState.pedido_items.filter(i => i.id !== itemId);
            AppState.pedido_total = res.data.total_pedido;
            this._renderPedido();
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    // ── Modal: acciones de ítem ───────────────────────────────

    _abrirModalItem(itemId) {
        const item = AppState.pedido_items.find(i => i.id === itemId);
        if (!item) return;
        AppState.item_editando = item;

        document.getElementById('modal-item-nombre').textContent  = item.articulo;
        document.getElementById('modal-item-notas').textContent   = item.res_notas || 'Sin notas';
        document.getElementById('modal-item-cantidad').textContent = item.cantidad;

        const session   = AppState.session;
        const btnRemove = document.getElementById('btn-modal-remover');
        if (btnRemove) {
            btnRemove.style.display = session?.pos_remover === 1 ? '' : 'none';
        }

        document.getElementById('modal-item').classList.remove('hidden');
    },

    /** Abre el modal de notas directamente desde el ítem, sin pasar por modal-item */
    _abrirNotasDirecto(itemId) {
        const item = AppState.pedido_items.find(i => i.id === itemId);
        if (!item) return;
        AppState.item_editando = item;
        this.abrirModalNotas();
    },

    cerrarModalItem() {
        document.getElementById('modal-item').classList.add('hidden');
        AppState.item_editando = null;
    },

    abrirModalNotas() {
        const item = AppState.item_editando;
        if (!item) return;

        this.cerrarModalItem();          // cierra modal-item (también pone item_editando=null)
        AppState.item_editando = item;   // restaurar — necesario para guardarNotas()

        document.getElementById('modal-notas-titulo').textContent = item.articulo;
        document.getElementById('modal-notas-custom').value       = item.res_notas || '';

        // Cargar notas preestablecidas de la categoría
        const categoria = item.categoria_d;
        document.getElementById('modal-notas-preset').innerHTML =
            '<p class="text-slate-500 text-sm">Cargando notas...</p>';

        Api.notas.byCategoria(categoria).then(res => {
            if (!res.success || !res.data.length) {
                document.getElementById('modal-notas-preset').innerHTML =
                    '<p class="text-slate-500 text-sm italic">No hay notas preestablecidas para esta categoría.</p>';
                return;
            }

            const notasActuales = (item.res_notas || '').split(', ').filter(Boolean);
            document.getElementById('modal-notas-preset').innerHTML = res.data.map(n => `
                <label class="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-700/50 cursor-pointer">
                    <input type="checkbox" value="${n.notas}"
                           class="w-5 h-5 rounded accent-orange-500"
                           ${notasActuales.includes(n.notas) ? 'checked' : ''}>
                    <span class="text-white text-sm">${n.notas}</span>
                </label>
            `).join('');
        }).catch(() => {
            document.getElementById('modal-notas-preset').innerHTML =
                '<p class="text-slate-500 text-sm italic">No se pudieron cargar las notas.</p>';
        });

        document.getElementById('modal-notas').classList.remove('hidden');
    },

    cerrarModalNotas() {
        document.getElementById('modal-notas').classList.add('hidden');
    },

    async guardarNotas() {
        const item = AppState.item_editando;
        if (!item) return;

        // Combinar checkboxes + texto libre
        const checked = [...document.querySelectorAll('#modal-notas-preset input[type=checkbox]:checked')]
            .map(c => c.value);
        const custom = document.getElementById('modal-notas-custom').value.trim();
        const notas  = [...checked, ...(custom ? [custom] : [])].join(', ');

        const btn = document.querySelector('#modal-notas button[onclick="PedidoView.guardarNotas()"]');
        if (btn) { btn.disabled = true; btn.textContent = 'Guardando...'; }

        try {
            const res = await Api.pedidos.actualizarNotas({
                docespera: AppState.docespera,
                id_item:   item.id,
                notas,
            });

            if (!res.success) {
                Toast.show(res.error || 'Error al guardar nota', 'error');
                return;
            }

            // Actualizar en memoria
            item.res_notas = notas;
            this._renderPedido();
            this.cerrarModalNotas();
            Toast.show('Nota guardada', 'success');

        } catch (err) {
            Toast.show(err.message || 'Error de conexión', 'error');
        } finally {
            if (btn) { btn.disabled = false; btn.textContent = 'Guardar'; }
        }
    },

    async removerItemModal() {
        const item = AppState.item_editando;
        if (!item) return;
        this.cerrarModalItem();

        try {
            const res = await Api.pedidos.removerItem({
                docespera: AppState.docespera,
                id_item:   item.id,
            });

            if (!res.success) { Toast.show(res.error, 'error'); return; }

            AppState.pedido_items = AppState.pedido_items.filter(i => i.id !== item.id);
            AppState.pedido_total = res.data.total_pedido;
            AppState.item_editando = null;

            this._renderPedido();
            Toast.show('Ítem eliminado', 'success');

        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    // ── Enviar Comanda ────────────────────────────────────────

    async enviarComanda() {
        if (!AppState.pedido_items.length) {
            Toast.show('El pedido está vacío', 'error');
            return;
        }

        // Verificar que haya ítems sin comandar
        const hayNuevos = AppState.pedido_items.some(
            item => item.res_comanda === '0' || item.res_comanda === '' || item.res_comanda == null
        );
        if (!hayNuevos) {
            Toast.show('Todos los ítems ya fueron comandados', 'warning');
            return;
        }

        const btns = document.querySelectorAll('.btn-enviar-comanda');
        btns.forEach(b => { b.disabled = true; b.textContent = 'Enviando...'; });

        try {
            const mesa_nombre = AppState.mesa_activa?.nombre || AppState.docespera;
            const res = await Api.comandas.enviar(AppState.docespera, mesa_nombre);

            if (!res.success) {
                Toast.show(res.error || 'Error al enviar comanda', 'error');
                return;
            }

            if (res.data.advertencias?.length) {
                res.data.advertencias.forEach(w => Toast.show(w, 'warning', 5000));
            }
            Toast.show(`✓ Comanda enviada a ${res.data.tickets_enviados} impresora(s)`, 'success');

            this.cerrarSheetMobile();
            this.volverAMesas();

        } catch (err) {
            Toast.show(err.message, 'error');
        } finally {
            btns.forEach(b => { b.disabled = false; b.textContent = 'ENVIAR COMANDA'; });
        }
    },

    // ── Sheet mobile ──────────────────────────────────────────

    toggleSheetMobile() {
        const sheet = document.getElementById('mobile-order-sheet');
        const isHidden = sheet.classList.contains('hidden');
        if (isHidden) {
            sheet.classList.remove('hidden');
            requestAnimationFrame(() => sheet.querySelector('.sheet-panel').classList.remove('translate-y-full'));
        } else {
            this.cerrarSheetMobile();
        }
    },

    cerrarSheetMobile() {
        const sheet = document.getElementById('mobile-order-sheet');
        const panel = sheet.querySelector('.sheet-panel');
        if (panel) panel.classList.add('translate-y-full');
        setTimeout(() => sheet.classList.add('hidden'), 300);
    },

    // ── Volver a mesas ────────────────────────────────────────

    volverAMesas() {        this._detenerTimerMesa();        AppState.mesa_activa   = null;
        AppState.docespera     = null;
        AppState.pedido_items  = [];
        AppState.pedido_total  = '0';
        Router.navigate('mesas');
    },

    // ── Liberar mesa ──────────────────────────────────────────

    async liberarMesa() {
        const mesa = AppState.mesa_activa;
        if (!mesa || !AppState.docespera) return;

        const result = await Swal.fire({
            title: 'Limpiar mesa',
            html: `<span class="text-slate-300">¿Limpiar <strong class="text-white">${mesa.nombre}</strong>?</span><br><span class="text-slate-400 text-sm">Los ítems sin enviar a cocina serán eliminados.</span>`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, limpiar',
            cancelButtonText: 'Cancelar',
            buttonsStyling: false,
            customClass: {
                popup:         'operkom-swal-popup',
                title:         'operkom-swal-title',
                htmlContainer: 'operkom-swal-html',
                confirmButton: 'btn btn-danger',
                cancelButton:  'btn btn-secondary',
            },
        });
        if (!result.isConfirmed) return;

        try {
            const res = await Api.pedidos.liberarMesa({
                id_mesa:   mesa.id,
                docespera: AppState.docespera,
            });
            if (!res.success) { Toast.show(res.error, 'error'); return; }
            Toast.show(`Mesa ${mesa.nombre} limpiada`, 'success');
            this._detenerTimerMesa();
            AppState.mesa_activa  = null;
            AppState.docespera    = null;
            AppState.pedido_items = [];
            AppState.pedido_total = '0';
            Router.navigate('mesas');
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    // ── Búsqueda de productos ─────────────────────────────────

    _filtrarProductos(txt) {
        PedidoView._busqueda = txt;
        const limpiar = document.getElementById('btn-limpiar-busqueda');
        if (limpiar) limpiar.classList.toggle('hidden', !txt);
        this._renderProductos(AppState.categoria_activa || '__TODOS__');
    },

    // ── Selector de cantidad (long-press) ─────────────────────

    _abrirPickerCantidad(id_producto) {
        // Buscar el producto en todas las fuentes disponibles
        const todas = [
            ...(AppState.productos[AppState.categoria_activa] || []),
            ...(AppState.productos['__TODOS__'] || []),
        ];
        const prod = todas.find(p => String(p.id_producto) === String(id_producto));

        document.getElementById('modal-cantidad-nombre').textContent = prod?.descripcion1 || '';

        // Guardar el id en propiedad del objeto — los botones lo leerán desde aquí
        PedidoView._pickerProductoId = String(id_producto);

        const grid = document.getElementById('modal-cantidad-grid');
        grid.innerHTML = [1,2,3,4,5,6,7,8,9,10].map(n => `
            <button onclick="PedidoView._elegirCantidad(${n})"
                    class="btn btn-secondary h-11 rounded-xl font-bold
                           text-base transition-colors active:scale-95">
                ${n}
            </button>
        `).join('');
        document.getElementById('modal-cantidad').classList.remove('hidden');
    },

    _elegirCantidad(cantidad) {
        const id = PedidoView._pickerProductoId;
        if (!id) return;
        PedidoView._lpLastConfirm = Date.now();
        PedidoView.cerrarModalCantidad();
        PedidoView.agregarProducto(id, cantidad);
    },

    cerrarModalCantidad() {
        PedidoView._pickerProductoId = null;
        document.getElementById('modal-cantidad').classList.add('hidden');
    },

    // ── Timer de mesa ─────────────────────────────────────────

    _iniciarTimerMesa() {
        this._detenerTimerMesa();
        const mesa = AppState.mesa_activa;
        if (!mesa?.fecha_activada || !mesa?.hora_activada) return;

        const actualizar = () => {
            const el = document.getElementById('pedido-timer');
            if (!el) return;
            const txt = this._buildTimerText(mesa.fecha_activada, mesa.hora_activada);
            if (txt) {
                el.textContent = '⏱ ' + txt;
                el.classList.remove('hidden');
            }
        };
        actualizar();
        this._timerInterval = setInterval(actualizar, 60000);
    },

    _detenerTimerMesa() {
        if (this._timerInterval) {
            clearInterval(this._timerInterval);
            this._timerInterval = null;
        }
        const el = document.getElementById('pedido-timer');
        if (el) el.classList.add('hidden');
    },

    _buildTimerText(fecha, hora) {
        try {
            const inicio = new Date(`${fecha}T${hora}`);
            const mins   = Math.floor((new Date() - inicio) / 60000);
            if (mins < 0)  return '';
            if (mins < 60) return `${mins} min`;
            const h = Math.floor(mins / 60);
            const m = mins % 60;
            return m > 0 ? `${h}h ${m}m` : `${h}h`;
        } catch { return ''; }
    },

    // ── Favoritos locales ─────────────────────────────────────

    _FAV_KEY: 'operkom_fav_v1',

    _hasFavoritos() {
        try {
            const raw = localStorage.getItem(this._FAV_KEY);
            if (!raw) return false;
            return Object.keys(JSON.parse(raw)).length > 0;
        } catch { return false; }
    },

    _registrarFavorito(id_producto) {
        try {
            const raw  = localStorage.getItem(this._FAV_KEY);
            const favs = raw ? JSON.parse(raw) : {};
            favs[id_producto] = (favs[id_producto] || 0) + 1;
            localStorage.setItem(this._FAV_KEY, JSON.stringify(favs));
        } catch { /* localStorage puede estar lleno */ }
    },

    _getFavProductos(n = 8) {
        try {
            const raw = localStorage.getItem(this._FAV_KEY);
            if (!raw) return [];
            const favs = JSON.parse(raw);

            const topIds = Object.entries(favs)
                .sort((a, b) => b[1] - a[1])
                .slice(0, n)
                .map(([id]) => id);
            if (!topIds.length) return [];

            // Buscar en todos los productos cargados (deduplicados)
            const todas = Object.entries(AppState.productos)
                .filter(([k]) => k !== '__FRECUENTES__')
                .flatMap(([, v]) => v);
            const seen = new Set();
            const uniq = todas.filter(p => {
                if (seen.has(p.id_producto)) return false;
                seen.add(p.id_producto);
                return true;
            });

            return topIds
                .map(id => uniq.find(p => String(p.id_producto) === String(id)))
                .filter(Boolean);
        } catch { return []; }
    },

    // ── Trasladar mesa ────────────────────────────────────────

    async abrirModalTrasladar() {
        const mesa = AppState.mesa_activa;
        if (!mesa) return;

        const grid = document.getElementById('trasladar-mesas-grid');
        grid.innerHTML = '<div class="col-span-3 text-center py-8"><div class="loading-spinner mx-auto"></div></div>';
        document.getElementById('modal-trasladar').classList.remove('hidden');

        try {
            const res = await Api.mesas.byArea(mesa.area.descripcion);
            if (!res.success) { Toast.show(res.error, 'error'); return; }

            const libres = res.data.filter(m =>
                (m.estatus === 0 || m.estatus === '0') && String(m.id) !== String(mesa.id)
            );

            if (!libres.length) {
                grid.innerHTML = '<p class="col-span-3 text-center text-slate-500 text-sm py-6">No hay mesas disponibles para trasladar.</p>';
                return;
            }

            grid.innerHTML = libres.map(m => {
                const nombreEsc = m.nombre.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
                return `
                    <button onclick="PedidoView._confirmarTrasladar('${m.id}', '${nombreEsc}')"
                            class="rounded-xl bg-emerald-900/30 border border-emerald-500/30
                                   hover:bg-emerald-800/50 hover:border-emerald-400
                                   text-emerald-300 font-bold text-sm py-3 px-2
                                   transition-all active:scale-95 truncate">
                        ${m.nombre}
                    </button>
                `;
            }).join('');
        } catch (err) {
            grid.innerHTML = '<p class="col-span-3 text-center text-rose-400 text-sm py-6">Error al cargar mesas.</p>';
        }
    },

    cerrarModalTrasladar() {
        document.getElementById('modal-trasladar').classList.add('hidden');
    },

    async _confirmarTrasladar(id_mesa_destino, nombre_mesa_destino) {
        const mesa = AppState.mesa_activa;
        this.cerrarModalTrasladar();

        const result = await Swal.fire({
            title: 'Trasladar pedido',
            html: `<span class="text-slate-300">¿Trasladar de <strong class="text-white">${mesa.nombre}</strong> a <strong class="text-white">${nombre_mesa_destino}</strong>?</span>`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: '↔ Trasladar',
            cancelButtonText: 'Cancelar',
            buttonsStyling: false,
            customClass: {
                popup:         'operkom-swal-popup',
                title:         'operkom-swal-title',
                htmlContainer: 'operkom-swal-html',
                confirmButton: 'btn btn-primary',
                cancelButton:  'btn btn-secondary',
            },
        });
        if (!result.isConfirmed) return;

        try {
            const res = await Api.pedidos.trasladarMesa({
                docespera_origen:    AppState.docespera,
                id_mesa_origen:      mesa.id,
                id_mesa_destino:     id_mesa_destino,
                nombre_mesa_destino: nombre_mesa_destino,
            });
            if (!res.success) { Toast.show(res.error, 'error'); return; }

            // Actualizar estado local
            AppState.docespera   = res.data.docespera_destino;
            AppState.mesa_activa = { ...AppState.mesa_activa, nombre: nombre_mesa_destino, id: Number(id_mesa_destino) };

            // Actualizar encabezados
            document.getElementById('pedido-mesa-nombre').textContent = nombre_mesa_destino;
            document.getElementById('pedido-mesa-header').textContent = nombre_mesa_destino;
            document.getElementById('mobile-mesa-header').textContent = `${nombre_mesa_destino} — ${mesa.area.descripcion}`;

            await this.loadPedido();
            Toast.show(`Pedido trasladado a ${nombre_mesa_destino}`, 'success');
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    // ── Recargar menú ──────────────────────────────────────────

    async recargarMenu() {
        const btn = document.getElementById('btn-reload-menu');
        if (btn) btn.classList.add('animate-spin');
        Cache.invalidate(CACHE_KEYS.categorias);
        AppState.categorias = [];
        AppState.productos  = {};   // vaciar caché en memoria — se recarga lazy al hacer click
        AppState.categoria_activa = null;
        try {
            await this._loadCacheYRenderizar();
            Toast.show('Menú actualizado', 'success');
        } catch (err) {
            Toast.show('Error al actualizar menú', 'error');
        } finally {
            if (btn) btn.classList.remove('animate-spin');
        }
    },

    _bindEvents() {
        // Prevenir doble binding — solo vincular eventos la primera vez
        if (PedidoView._eventsBound) return;
        PedidoView._eventsBound = true;

        document.getElementById('btn-volver-mesas')
            ?.addEventListener('click', () => PedidoView.volverAMesas());

        document.getElementById('btn-reload-menu')
            ?.addEventListener('click', () => PedidoView.recargarMenu());

        const mobileOrderBar = document.getElementById('mobile-order-bar');
        mobileOrderBar?.addEventListener('click', event => {
            if (event.target.closest('.btn-enviar-comanda')) return;
            PedidoView.toggleSheetMobile();
        });
        mobileOrderBar?.addEventListener('keydown', event => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                PedidoView.toggleSheetMobile();
            }
        });

        document.getElementById('modal-item-overlay')
            ?.addEventListener('click', () => PedidoView.cerrarModalItem());

        document.getElementById('modal-notas-overlay')
            ?.addEventListener('click', () => PedidoView.cerrarModalNotas());

        document.getElementById('mobile-sheet-overlay')
            ?.addEventListener('click', () => PedidoView.cerrarSheetMobile());

        // ── Búsqueda ──────────────────────────────────────────
        document.getElementById('buscador-productos')
            ?.addEventListener('input', e => PedidoView._filtrarProductos(e.target.value));

        document.getElementById('btn-limpiar-busqueda')
            ?.addEventListener('click', () => {
                const inp = document.getElementById('buscador-productos');
                if (inp) inp.value = '';
                PedidoView._filtrarProductos('');
            });

        // ── Long-press en tarjetas de producto ───────────────────
        const productoPanel = document.getElementById('panel-productos');
        let _lpTimer = null;
        let _lpStartX = 0, _lpStartY = 0;

        productoPanel?.addEventListener('pointerdown', e => {
            const card = e.target.closest('[data-producto-id]');
            if (!card) return;
            _lpStartX = e.clientX;
            _lpStartY = e.clientY;
            _lpTimer = setTimeout(() => {
                _lpTimer = null;
                // Marcar la tarjeta para que su onclick sea ignorado
                PedidoView._skipNextTap = card.dataset.productoId;
                PedidoView._abrirPickerCantidad(card.dataset.productoId);
            }, 450);
        });

        productoPanel?.addEventListener('pointerup', () => {
            clearTimeout(_lpTimer);
            _lpTimer = null;
        });

        productoPanel?.addEventListener('pointercancel', () => {
            clearTimeout(_lpTimer);
            _lpTimer = null;
        });

        productoPanel?.addEventListener('pointermove', e => {
            if (!_lpTimer) return;
            const dx = e.clientX - _lpStartX;
            const dy = e.clientY - _lpStartY;
            if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                clearTimeout(_lpTimer);
                _lpTimer = null;
            }
        });

        // ── Modales nuevos ────────────────────────────────────
        document.getElementById('modal-cantidad-overlay')
            ?.addEventListener('click', () => PedidoView.cerrarModalCantidad());

        document.getElementById('modal-trasladar-overlay')
            ?.addEventListener('click', () => PedidoView.cerrarModalTrasladar());
    },
};
