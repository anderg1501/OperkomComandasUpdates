/* theme.js - gestor de tema global (solo estado) */

const ThemeToggle = {
    _key: 'operkom_theme',

    init() {
        const saved = localStorage.getItem(this._key) || 'light';
        this.apply(saved);
    },

    toggle() {
        const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
        const next = current === 'dark' ? 'light' : 'dark';
        this.apply(next);
        localStorage.setItem(this._key, next);
    },

    apply(theme) {
        const html = document.documentElement;
        html.setAttribute('data-theme', theme);
        html.classList.toggle('dark', theme === 'dark');
        this._updateMetaThemeColor(theme);
        this._updateIcons(theme);
    },

    _updateMetaThemeColor(theme) {
        const meta = document.querySelector('meta[name="theme-color"]');
        if (!meta) return;
        meta.setAttribute('content', theme === 'dark' ? '#031D33' : '#005190');
    },

    _updateIcons(theme) {
        document.querySelectorAll('.theme-icon-sun').forEach(el => {
            el.classList.toggle('hidden', theme === 'light');
        });
        document.querySelectorAll('.theme-icon-moon').forEach(el => {
            el.classList.toggle('hidden', theme === 'dark');
        });
    },
};

// Aplicar tema temprano para evitar parpadeo inicial.
(function bootstrapTheme() {
    const saved = localStorage.getItem('operkom_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    document.documentElement.classList.toggle('dark', saved === 'dark');
})();
