/**
 * app.js — Controlador principal de la SPA Operkom Comandas Web.
 * Punto de entrada: inicializa la app y define utilidades globales.
 */

// ── Toast notifications ───────────────────────────────────────

const Toast = {
    show(message, type = 'info', duration = 3500) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const toneClass = {
            success: 'btn-primary',
            error:   'btn-danger',
            warning: 'btn-secondary',
            info:    'btn-secondary',
        };
        const icons = {
            success: '✓', error: '✕', warning: '⚠', info: 'ℹ',
        };

        const el = document.createElement('div');
        el.className = `btn ${toneClass[type] || toneClass.info} flex items-center gap-3 px-4 py-3 text-sm font-medium
                        shadow-2xl border transition-all duration-300`;
        el.innerHTML = `
            <span class="text-base font-bold flex-shrink-0">${icons[type] || icons.info}</span>
            <span>${message}</span>
        `;

        container.appendChild(el);

        // Animación de salida
        setTimeout(() => {
            el.style.opacity    = '0';
            el.style.transform  = 'translateX(100%)';
            setTimeout(() => el.remove(), 300);
        }, duration);
    },
};

// ── Aviso de actualizaciones ──────────────────────────────────

const UpdateNotifier = {
    _checking: false,
    _timer: null,

    start() {
        this.check();
        if (this._timer === null) {
            this._timer = setInterval(() => this.check(), 15 * 60 * 1000);
        }
    },

    async check() {
        if (this._checking || !AppState.session?.token) return;
        this._checking = true;

        try {
            const result = await Api.actualizaciones.aviso();
            if (!result.success || !result.data?.update_available) return;

            const version = result.data.available_version;
            const noticeKey = 'operkom_update_notice_version';
            if (sessionStorage.getItem(noticeKey) === version) return;
            sessionStorage.setItem(noticeKey, version);
            this._show(version);
        } catch (err) {
            // Es una comprobación auxiliar: nunca debe mostrar un error al mesero.
            console.warn('[UpdateNotifier] No se pudo comprobar la actualización:', err);
        } finally {
            this._checking = false;
        }
    },

    _show(version) {
        const container = document.getElementById('toast-container');
        if (!container || document.getElementById('update-available-toast')) return;

        const toast = document.createElement('div');
        toast.id = 'update-available-toast';
        toast.className = 'update-available-toast';

        const text = document.createElement('div');
        const title = document.createElement('strong');
        title.textContent = `Nueva versión disponible: v${version}`;
        const description = document.createElement('span');
        description.textContent = 'Requiere PIN de administrador para instalarla.';
        text.append(title, description);

        const action = document.createElement('button');
        action.type = 'button';
        action.textContent = 'Actualizar ahora';
        action.addEventListener('click', () => {
            toast.remove();
            ConfigView.solicitarActualizacion();
        });

        const dismiss = document.createElement('button');
        dismiss.type = 'button';
        dismiss.className = 'update-toast-dismiss';
        dismiss.setAttribute('aria-label', 'Cerrar aviso de actualización');
        dismiss.textContent = '×';
        dismiss.addEventListener('click', () => toast.remove());

        toast.append(text, action, dismiss);
        container.appendChild(toast);
    },
};

// ── Inicialización ────────────────────────────────────────────

// ── Formateo de precios (varchar con formato local: "4.500,00") ──────────────
/**
 * Convierte un string de precio con punto como sep.miles y coma como decimal
 * (formato VB6/español: "4.500,00" o "4500,00" o "4500.00") a número.
 */
function parsePrecio(val) {
    if (!val || val === '' || val === '0') return 0;
    const s = String(val).trim();
    // Detectar si el formato usa punto como miles y coma como decimal
    // Caso: "4.500,00" → quitar puntos, cambiar coma por punto
    if (s.includes(',')) {
        return parseFloat(s.replace(/\./g, '').replace(',', '.')) || 0;
    }
    // Caso: "4500.00" → parseFloat normal
    return parseFloat(s) || 0;
}

/** Formatea un número como precio colombiano: 4500 → "4.500" */
function formatPrecio(num) {
    return num.toLocaleString('es-CO', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

document.addEventListener('DOMContentLoaded', () => {
    // Limpiar keys de versiones anteriores del caché
    Cache.purgeOldVersions();
    // Aplicar tema guardado
    ThemeToggle.init();
    // La primera vista es siempre el login; LoginView.init() comprueba
    // si ya hay sesión y redirige si corresponde.
    Router.navigate('login');
});
