/**
 * router.js — Navegación entre vistas de la SPA.
 * Muestra la vista solicitada y llama a su función de inicialización.
 * Nunca recarga la página.
 */

const Router = {

    navigate(vista) {
        const previousView = AppState.vista_actual;
        if (previousView === 'mesas' && vista !== 'mesas' && typeof MesasView !== 'undefined') {
            MesasView._stopAutoRefresh();
        }

        // Ocultar todas las vistas
        document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));

        const target = document.getElementById(`view-${vista}`);
        if (!target) {
            console.error(`[Router] Vista no encontrada: view-${vista}`);
            return;
        }

        target.classList.remove('hidden');
        AppState.vista_actual = vista;

        // Inicializar la vista correspondiente
        const init = { login: LoginView, mesas: MesasView, pedido: PedidoView, config: ConfigView };
        if (init[vista]) {
            init[vista].init();
        }
    },
};
