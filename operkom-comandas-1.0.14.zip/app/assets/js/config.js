/**
 * Configuración compartida del frontend.
 */
(function configureOperkom() {
    function resolveApiBase() {
        const explicit = window.OPERKOM_API_BASE || '';
        if (explicit) {
            return String(explicit).replace(/\/$/, '');
        }

        const path = String(window.location.pathname || '');
        // Acepta tanto /comandasweb como /comandasweb/ y rutas internas.
        const projectPath = path.match(/^(.*\/comandasweb)(?:\/|$)/i);
        if (projectPath) {
            return `${projectPath[1]}/api`;
        }

        // Mantiene la compatibilidad con un frontend local separado.
        const { protocol, hostname, port } = window.location;
        if (port === '3000') {
            return `${protocol}//${hostname}/comandasweb/api`;
        }

        return '/api';
    }

    window.OperkomConfig = Object.freeze({ resolveApiBase });
})();
