<?php
/**
 * GET /api/setup/check-config
 * Verifica si la configuración de BD está completa.
 * Accesible SOLO desde localhost para seguridad.
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/config-helper.php';
require_once dirname(__DIR__) . '/helpers/response.php';


// Validar que solo sea desde localhost o segmentos permitidos
$allowedIPs = ['127.0.0.1', '::1', 'localhost'];
$clientIP   = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
$clientIP   = explode(',', $clientIP)[0];
$clientIP   = trim($clientIP);

// config.php already loaded the persistent configuration.
$allowedSegments = defined('ALLOWED_SEGMENTS')
    ? array_filter(array_map('trim', explode(',', ALLOWED_SEGMENTS)))
    : [];

$ipAllowed = in_array($clientIP, $allowedIPs, true);
foreach ($allowedSegments as $segment) {
    if (strpos($clientIP, $segment . '.') === 0) {
        $ipAllowed = true;
        break;
    }
}
if (!$ipAllowed) {
    http_response_code(403);
    sendError('Acceso denegado. Setup solo disponible desde localhost o segmentos configurados.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Metodo no permitido', 405);
}

// The constants are the source of truth; parsing the PHP file as text was
// brittle when a value contained quotes or other special characters.
$isConfigured = hasLocalConfig();
$isComplete = isConfigured();

sendSuccess([
    'configured'       => $isComplete,
    'has_local_config' => $isConfigured,
    'partial_info'     => [
        'db_host'      => DB_HOST ?: null,
        'db_port'      => DB_PORT,
        'db_name'      => DB_NAME ?: null,
        'db_user'      => DB_USER ?: null,
        'app_timezone' => APP_TIMEZONE,
    ],
]);
