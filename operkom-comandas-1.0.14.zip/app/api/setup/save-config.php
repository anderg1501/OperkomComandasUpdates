<?php
/**
 * POST /api/setup/save-config
 * Guarda las credenciales de BD en config.local.php.
 * Solo accesible desde localhost.
 * Incluye validación de conexión antes de guardar.
 */

require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/config/config.php';

// ── Validar que solo sea desde localhost o una red autorizada ──
$allowedIPs = ['127.0.0.1', '::1', 'localhost'];
$clientIP   = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
$clientIP   = explode(',', $clientIP)[0];
$clientIP   = trim($clientIP);

$ipAllowed = in_array($clientIP, $allowedIPs, true);
$allowedSegments = defined('ALLOWED_SEGMENTS')
    ? array_filter(array_map('trim', explode(',', ALLOWED_SEGMENTS)))
    : [];
foreach ($allowedSegments as $segment) {
    if (strpos($clientIP, $segment . '.') === 0) {
        $ipAllowed = true;
        break;
    }
}
if (!$ipAllowed) {
    http_response_code(403);
    sendError('Acceso denegado. Setup solo disponible desde localhost o segmentos configurados.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$body = json_decode(file_get_contents('php://input'), true) ?? [];


$dbHost   = trim($body['db_host']   ?? '');
$dbPortRaw = trim((string) ($body['db_port'] ?? '3306'));
$dbName   = trim($body['db_name']   ?? '');
$dbUser   = trim($body['db_user']   ?? '');
$dbPassInput = $body['db_pass'] ?? '';
$dbPassProvided = is_string($dbPassInput) && $dbPassInput !== '';
$keepDbPass = filter_var($body['keep_db_pass'] ?? false, FILTER_VALIDATE_BOOLEAN);
$dbPass = $dbPassProvided ? trim($dbPassInput) : '';
if (!$dbPassProvided && $keepDbPass && defined('DB_PASS')) {
    $dbPass = DB_PASS;
}
$timezone = trim($body['app_timezone'] ?? 'America/Bogota');
$allowedSegmentsInput = isset($body['allowed_segments']) ? trim($body['allowed_segments']) : '';

// ── Validaciones básicas ───────────────────────────────────────
if (empty($dbHost) || $dbPortRaw === '' || empty($dbName) || empty($dbUser)) {
    sendError('Todos los campos son requeridos');
}

$dbPort = filter_var($dbPortRaw, FILTER_VALIDATE_INT, [
    'options' => ['min_range' => 1, 'max_range' => 65535],
]);
if ($dbPort === false) {
    sendError('El puerto de base de datos debe estar entre 1 y 65535');
}

// Validar zona horaria contra la lista oficial de PHP
$validTimezones = DateTimeZone::listIdentifiers();
if (!in_array($timezone, $validTimezones, true)) {
    sendError('Zona horaria inválida');
}

if (strlen($dbHost) > 255 || strlen($dbName) > 255 || strlen($dbUser) > 255) {
    sendError('Valores demasiado largos');
}

// ── Validar caracteres permitidos ──────────────────────────────
if (!preg_match('/^[a-zA-Z0-9._:-]+$/', $dbHost)) {
    sendError('DB_HOST contiene caracteres inválidos');
}

if (!preg_match('/^[a-zA-Z0-9_-]+$/', $dbName)) {
    sendError('DB_NAME contiene caracteres inválidos');
}

if (!preg_match('/^[a-zA-Z0-9_-]+$/', $dbUser)) {
    sendError('DB_USER contiene caracteres inválidos');
}

// ── Probar conexión a la BD ────────────────────────────────────
try {
    $pdo = new PDO(
        "mysql:host={$dbHost};port={$dbPort};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 5,
        ]
    );
    
    // Verificar que la BD existe
    $stmt = $pdo->prepare("SELECT 1 FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?");
    $stmt->execute([$dbName]);
    if (!$stmt->fetch()) {
        sendError("Base de datos '{$dbName}' no encontrada en el servidor");
    }
    
    $pdo = null;
} catch (PDOException $e) {
    // No revelar detalles internos de error
    sendError('Error de conexión: ' . $e->getMessage());
}

// ── Generar contenido de config.local.php ───────────────────────
$configContent = "<?php\n";
$configContent .= "/**\n";
$configContent .= " * Configuración local - Generado por asistente de setup\n";
$configContent .= " * NO compartir - contiene credenciales de BD\n";
$configContent .= " * Timestamp: " . date('Y-m-d H:i:s') . "\n";
$configContent .= " */\n\n";
$configContent .= "// ── Credenciales de base de datos (asistente de setup) ──────────\n";

$configContent .= "define('DB_HOST', " . var_export($dbHost, true) . ");\n";
$configContent .= "define('DB_PORT', " . var_export($dbPort, true) . ");\n";
$configContent .= "define('DB_NAME', " . var_export($dbName, true) . ");\n";
$configContent .= "define('DB_USER', " . var_export($dbUser, true) . ");\n";
$configContent .= "define('DB_PASS', " . var_export($dbPass, true) . ");\n";
// Guardar segmentos de red permitidos
$configContent .= "define('ALLOWED_SEGMENTS', " . var_export($allowedSegmentsInput, true) . ");\n";
$configContent .= "define('APP_TIMEZONE', " . var_export($timezone, true) . ");\n";

// ── Guardar archivo fuera del código actualizable ──────────────
$configLocalPath = getPersistentConfigPath();
$configDirectory = dirname($configLocalPath);

if (!is_dir($configDirectory) && !mkdir($configDirectory, 0750, true) && !is_dir($configDirectory)) {
    sendError('No se pudo crear el directorio de configuración. Verifica permisos en ' . $configDirectory);
}

// Backup si ya existe
if (file_exists($configLocalPath)) {
    $backupPath = $configLocalPath . '.bak.' . time();
    copy($configLocalPath, $backupPath);
}

// Escribir con permisos restrictivos
$result = file_put_contents($configLocalPath, $configContent, LOCK_EX);

if ($result === false) {
    sendError('No se pudo escribir el archivo de configuración. Verifica permisos en ' . $configDirectory);
}

// Establecer permisos (solo lectura)
@chmod($configLocalPath, 0640);

sendSuccess([
    'message'  => 'Configuración guardada exitosamente',
    'config'   => [
        'db_host'      => $dbHost,
        'db_port'      => $dbPort,
        'db_name'      => $dbName,
        'db_user'      => $dbUser,
        'app_timezone' => $timezone,
    ],
]);
