<?php
/**
 * Script de verificación de columnas en detalle_factura_espera
 * ELIMINAR después de usar.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';

header('Content-Type: text/plain; charset=utf-8');

$db = getDB();

$stmt = $db->query("SHOW COLUMNS FROM detalle_factura_espera");
$cols = array_column($stmt->fetchAll(PDO::FETCH_ASSOC), 'Field');

echo "=== COLUMNAS EN detalle_factura_espera ===\n";
echo implode(', ', $cols) . "\n\n";

$requeridas = ['pvb', 'comision_p', 'comision_m', 'marca', 'unidad', 'res_indx', 'departamento_d', 'pv_original'];
foreach ($requeridas as $col) {
    echo (in_array($col, $cols) ? "OK" : "FALTA") . ": $col\n";
}
