<?php
/**
 * GET /api/productos?categoria={id_categoria}
 * Retorna los productos activos de una categoría específica.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

validateToken();

$categoria = trim($_GET['categoria'] ?? '');
if ($categoria === '') {
    sendError('Parámetro categoria requerido');
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id_producto, descripcion1, categoria, existencias, exento,
            impuesto_descripcionv, impuestov, costo_actual, precio_venta1,
            imagen, compuesto, btncol
       FROM inventario
      WHERE activo    = '1'
        AND serial   != '1'
        AND tyc      != '1'
        AND (categoria = :cat1
             OR categoria = (SELECT cp.categoria FROM categoria_producto cp
                              WHERE cp.ID_Categoria = :cat2 LIMIT 1))
      ORDER BY descripcion1 ASC"
);
$stmt->execute([':cat1' => $categoria, ':cat2' => $categoria]);
$rows = $stmt->fetchAll();

$productos = normalizarProductos($rows);

sendSuccess($productos);

// ── Helper ────────────────────────────────────────────────────
function normalizarProductos(array $rows): array
{
    $result = [];
    foreach ($rows as $row) {
        $imagen = trim($row['imagen']);
        $result[] = [
            'id_producto'   => $row['id_producto'],
            'descripcion1'  => $row['descripcion1'],
            'categoria'     => $row['categoria'],
            'existencias'   => $row['existencias'],
            'exento'        => $row['exento'],
            'impuestov'     => $row['impuestov'],
            'costo_actual'  => $row['costo_actual'],
            'precio_venta1' => $row['precio_venta1'],
            'compuesto'     => $row['compuesto'],
            'imagen'        => $imagen !== '' ? $imagen : null,
            'color_css'     => vb6ColorToCss($row['btncol']),
        ];
    }
    return $result;
}
