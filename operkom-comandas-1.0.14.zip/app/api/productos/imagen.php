<?php
/**
 * GET /api/productos/imagen.php?p={ruta_con_pipes}
 * Sirve una imagen del sistema de archivos local.
 * Las rutas se almacenan en BD con '|' como separador (ej: D:|Fotos|prod.jpg).
 * No requiere token: las imágenes de producto no son datos sensibles.
 */

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    exit;
}

$rawPath = trim($_GET['p'] ?? '');
if ($rawPath === '') {
    http_response_code(400);
    exit;
}

// Convertir separadores almacenados (|) a separadores reales del SO
$filePath = str_replace('|', DIRECTORY_SEPARATOR, $rawPath);

// Solo extensiones de imagen permitidas
$ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
    http_response_code(404);
    exit;
}

// Resolver ruta absoluta real (elimina ../ y enlaces simbólicos)
$realPath = realpath($filePath);
if ($realPath === false || !is_file($realPath)) {
    http_response_code(404);
    exit;
}

// Verificar MIME type real del contenido (no confiar solo en la extensión)
$finfo    = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($realPath);

if (!in_array($mimeType, ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], true)) {
    http_response_code(403);
    exit;
}

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . filesize($realPath));
header('Cache-Control: public, max-age=86400');
header('X-Content-Type-Options: nosniff');

while (ob_get_level()) ob_end_clean();
readfile($realPath);
