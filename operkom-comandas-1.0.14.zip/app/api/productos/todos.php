<?php
/**
 * GET /api/productos/todos
 * Retorna TODOS los productos activos agrupados por id_categoria.
 * Este endpoint se usa para llenar el caché localStorage al iniciar sesión.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

validateToken();

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id_producto, descripcion1, categoria, existencias, exento,
            impuestov, costo_actual, precio_venta1, imagen, compuesto, btncol
       FROM inventario
      WHERE activo  = '1'
        AND serial != '1'
        AND tyc    != '1'
      ORDER BY categoria ASC, descripcion1 ASC"
);
$stmt->execute();
$rows = $stmt->fetchAll();

// Agrupar por categoría para acceso O(1) desde el frontend
$grouped = [];
foreach ($rows as $row) {
    $cat   = $row['categoria'];
    $imagen = trim($row['imagen']);
    $grouped[$cat][] = [
        'id_producto'   => $row['id_producto'],
        'descripcion1'  => $row['descripcion1'],
        'categoria'     => $cat,
        'existencias'   => $row['existencias'],
        'exento'        => $row['exento'],
        'impuestov'     => $row['impuestov'],
        'costo_actual'  => $row['costo_actual'],
        'precio_venta1' => $row['precio_venta1'],
        'compuesto'     => $row['compuesto'],
            'imagen'        => $imagen !== '' ? $imagen : null,
        'color_css'     => vb6ColorToCss($row['btncol']),
    ];
}

sendSuccess($grouped);
