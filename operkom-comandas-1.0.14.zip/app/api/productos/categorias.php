<?php
/**
 * GET /api/productos/categorias
 * Retorna todas las categorías con imagen y color CSS convertido desde VB6.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

validateToken();

$db   = getDB();
$stmt = $db->prepare(
    "SELECT ID_Categoria, categoria, imagen, imp_comanda, btncol
       FROM categoria_producto
      ORDER BY categoria ASC"
);
$stmt->execute();
$rows = $stmt->fetchAll();

$categorias = [];
foreach ($rows as $row) {
    $imagen = trim($row['imagen']);
    $categorias[] = [
        'id_categoria' => $row['ID_Categoria'],
        'categoria'    => $row['categoria'],
        'imagen'       => $imagen !== '' ? $imagen : null,
        'imp_comanda'  => $row['imp_comanda'],
        'color_css'    => vb6ColorToCss($row['btncol']),
    ];
}

sendSuccess($categorias);
