<?php
/**
 * PATCH /api/pedidos/cambiar-cantidad
 * Cambia la cantidad de un ítem NO comandado.
 *
 * Body JSON:
 *   docespera — clave del pedido
 *   id_item   — detalle_factura_espera.id
 *   delta     — +1 o -1 (si cantidad llega a 0 el ítem se elimina)
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PATCH') {
    sendError('Método no permitido', 405);
}

validateToken();

$body      = getRequestBody();
$docespera = trim($body['docespera'] ?? '');
$id_item   = (int) ($body['id_item'] ?? 0);
$delta     = (int) ($body['delta']   ?? 0);

if ($docespera === '' || $id_item <= 0 || !in_array($delta, [1, -1], true)) {
    sendError('Faltan campos requeridos: docespera, id_item, delta (+1 o -1)');
}

$db = getDB();

// Obtener ítem y verificar que no esté comandado
$stmt = $db->prepare(
    "SELECT id, cantidad, pu, iva, res_comanda
       FROM detalle_factura_espera
      WHERE id = :id AND DocEspera = :docespera
      LIMIT 1"
);
$stmt->execute([':id' => $id_item, ':docespera' => $docespera]);
$item = $stmt->fetch();

if (!$item) {
    sendError('Ítem no encontrado', 404);
}

if ($item['res_comanda'] !== '0' && $item['res_comanda'] !== '') {
    sendError('Este ítem ya fue comandado y no se puede modificar', 403);
}

$cantidad_actual = max(1, (int) $item['cantidad']);
$nueva_cantidad  = $cantidad_actual + $delta;

if ($nueva_cantidad <= 0) {
    // Eliminar el ítem si llega a 0
    $db->prepare("DELETE FROM detalle_factura_espera WHERE id = :id AND DocEspera = :docespera")
       ->execute([':id' => $id_item, ':docespera' => $docespera]);
} else {
    // Recalcular pv y pvb según nueva cantidad
    $pu            = parsePrecioPhp($item['pu']);
    $nuevo_pv_float = $pu * $nueva_cantidad;
    $nuevo_pv      = number_format($nuevo_pv_float, 2, ',', '.');

    // pvb = pv sin IVA; si exento o sin tasa, pvb = pv
    $iva_val = $item['iva'];
    if ($iva_val === 'E' || $iva_val === '' || floatval($iva_val) <= 0) {
        $nuevo_pvb = number_format($nuevo_pv_float, 2, ',', '.');
    } else {
        $tasa = floatval($iva_val) / 100.0;
        $nuevo_pvb = number_format($nuevo_pv_float / (1 + $tasa), 2, ',', '.');
    }

    $db->prepare(
        "UPDATE detalle_factura_espera
            SET cantidad = :cantidad, pv = :pv, pvb = :pvb
          WHERE id = :id AND DocEspera = :docespera"
    )->execute([
        ':cantidad'  => (string) $nueva_cantidad,
        ':pv'        => $nuevo_pv,
        ':pvb'       => $nuevo_pvb,
        ':id'        => $id_item,
        ':docespera' => $docespera,
    ]);
}

// Recalcular total del pedido — compatible con formato inglés y colombiano
$stmtTotal = $db->prepare(
    "SELECT COALESCE(SUM(CAST(
        CASE WHEN pv LIKE '%,%'
             THEN REPLACE(REPLACE(pv, '.', ''), ',', '.')
             ELSE pv
        END AS DECIMAL(15,2))), 0)
       FROM detalle_factura_espera
      WHERE DocEspera = :docespera"
);
$stmtTotal->execute([':docespera' => $docespera]);
$total = number_format(floatval($stmtTotal->fetchColumn()), 2, ',', '.');

$db->prepare("UPDATE factura_espera SET total = :total WHERE docespera = :docespera")
   ->execute([':total' => $total, ':docespera' => $docespera]);

// Actualizar acumulado y pendiente en la mesa
$db->prepare(
    "UPDATE restaurant_detalle_mesas rdm
       JOIN restaurant_mesas_area rma ON rdm.id_area = rma.descripcion
        SET rdm.acumulado = :total,
            rdm.pendiente = :total_p
      WHERE CONCAT(rma.descripcion, '-', rdm.nombre) = :docespera"
)->execute([':total' => $total, ':total_p' => $total, ':docespera' => $docespera]);

sendSuccess([
    'eliminado'      => $nueva_cantidad <= 0,
    'nueva_cantidad' => max(0, $nueva_cantidad),
    'total_pedido'   => $total,
]);

// ── Helper ────────────────────────────────────────────────────
function parsePrecioPhp($val): float {
    if (!$val || $val === '') return 0.0;
    $s = trim((string) $val);
    if (strpos($s, ',') !== false) {
        return (float) str_replace(['.', ','], ['', '.'], $s);
    }
    return (float) $s;
}
