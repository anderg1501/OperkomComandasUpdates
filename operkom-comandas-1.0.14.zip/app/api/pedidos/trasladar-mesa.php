<?php
/**
 * POST /api/pedidos/trasladar-mesa
 * Traslada el pedido activo de una mesa a otra mesa libre del mismo área.
 *
 * Body JSON:
 *   docespera_origen    — DocEspera actual (ej: "SALON-SL 7")
 *   id_mesa_origen      — id de restaurant_detalle_mesas origen
 *   id_mesa_destino     — id de restaurant_detalle_mesas destino
 *   nombre_mesa_destino — nombre de la mesa destino (ej: "SL 8")
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

validateToken();
$body = getRequestBody();

$docespera_origen    = trim($body['docespera_origen']    ?? '');
$id_mesa_origen      = trim($body['id_mesa_origen']      ?? '');
$id_mesa_destino     = trim($body['id_mesa_destino']     ?? '');
$nombre_mesa_destino = trim($body['nombre_mesa_destino'] ?? '');

if (!$docespera_origen || !$id_mesa_origen || !$id_mesa_destino || !$nombre_mesa_destino) {
    sendError('Faltan campos requeridos: docespera_origen, id_mesa_origen, id_mesa_destino, nombre_mesa_destino');
}

$db = getDB();

try {
    // Verificar que la mesa destino esté libre
    $stmt = $db->prepare(
        "SELECT id FROM restaurant_detalle_mesas WHERE id = :id AND status = 0 LIMIT 1"
    );
    $stmt->execute([':id' => $id_mesa_destino]);
    if (!$stmt->fetch()) {
        sendError('La mesa destino no está disponible');
    }

    // Obtener datos de la mesa origen para copiarlos al destino
    $stmt = $db->prepare(
        "SELECT status, acumulado, pendiente, id_mesero, fecha_activada, hora_activada
           FROM restaurant_detalle_mesas WHERE id = :id LIMIT 1"
    );
    $stmt->execute([':id' => $id_mesa_origen]);
    $mesaOrigen = $stmt->fetch();
    if (!$mesaOrigen) {
        sendError('Mesa origen no encontrada');
    }

    // Construir el DocEspera destino usando el mismo prefijo de área
    // docespera_origen = "SALON-SL 7"  →  prefijo = "SALON-"
    $pos = strrpos($docespera_origen, '-');
    if ($pos === false) {
        sendError('Formato de docespera_origen inválido');
    }
    $prefijo_area      = substr($docespera_origen, 0, $pos + 1);  // "SALON-"
    $docespera_destino = $prefijo_area . $nombre_mesa_destino;    // "SALON-SL 8"

    $db->beginTransaction();

    // 1. Redirigir los ítems del pedido
    $stmt = $db->prepare(
        "UPDATE detalle_factura_espera SET DocEspera = :nuevo WHERE DocEspera = :viejo"
    );
    $stmt->execute([':nuevo' => $docespera_destino, ':viejo' => $docespera_origen]);

    // 2. Redirigir la cabecera del pedido
    $stmt = $db->prepare(
        "UPDATE factura_espera SET docespera = :nuevo WHERE docespera = :viejo"
    );
    $stmt->execute([':nuevo' => $docespera_destino, ':viejo' => $docespera_origen]);

    // 3. Liberar la mesa origen
    $stmt = $db->prepare(
        "UPDATE restaurant_detalle_mesas
            SET status = 0, acumulado = '0,00', pendiente = '0,00', id_mesero = NULL
          WHERE id = :id"
    );
    $stmt->execute([':id' => $id_mesa_origen]);

    // 4. Activar la mesa destino con los datos heredados del origen
    $stmt = $db->prepare(
        "UPDATE restaurant_detalle_mesas
            SET status = :status, acumulado = :acumulado, pendiente = :pendiente,
                id_mesero = :id_mesero, fecha_activada = :fecha, hora_activada = :hora
          WHERE id = :id"
    );
    $stmt->execute([
        ':status'    => $mesaOrigen['status'],
        ':acumulado' => $mesaOrigen['acumulado'],
        ':pendiente' => $mesaOrigen['pendiente'],
        ':id_mesero' => $mesaOrigen['id_mesero'],
        ':fecha'     => $mesaOrigen['fecha_activada'],
        ':hora'      => $mesaOrigen['hora_activada'],
        ':id'        => $id_mesa_destino,
    ]);

    $db->commit();

    sendSuccess([
        'docespera_destino'   => $docespera_destino,
        'nombre_mesa_destino' => $nombre_mesa_destino,
    ]);

} catch (PDOException $e) {
    if ($db->inTransaction()) $db->rollBack();
    sendError('Error de base de datos: ' . $e->getMessage());
}
