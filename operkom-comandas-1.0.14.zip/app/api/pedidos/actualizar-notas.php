<?php
/**
 * PATCH /api/pedidos/actualizar-notas
 * Actualiza las notas (res_notas) de un ítem del pedido.
 * Solo permite editar ítems que aún NO han sido comandados (res_comanda = '0').
 *
 * Body JSON:
 *   docespera — clave del pedido
 *   id_item   — id del ítem en detalle_factura_espera
 *   notas     — nuevo texto de notas (puede ser vacío para borrar)
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'PATCH') {
    sendError('Método no permitido', 405);
}

validateToken();

$body      = getRequestBody();
$docespera = trim($body['docespera'] ?? '');
$id_item   = (int) ($body['id_item'] ?? 0);
$notas     = substr(trim($body['notas'] ?? ''), 0, 255);

if ($docespera === '' || $id_item <= 0) {
    sendError('Faltan campos requeridos: docespera, id_item');
}

$db = getDB();

// Verificar que el ítem existe, pertenece al pedido y no está comandado
$stmt = $db->prepare(
    "SELECT id, res_comanda FROM detalle_factura_espera
      WHERE id = :id AND DocEspera = :docespera LIMIT 1"
);
$stmt->execute([':id' => $id_item, ':docespera' => $docespera]);
$item = $stmt->fetch();

if (!$item) {
    sendError('Ítem no encontrado en el pedido', 404);
}

if ($item['res_comanda'] !== '0' && $item['res_comanda'] !== '') {
    sendError('No se pueden editar notas de ítems ya comandados', 409);
}

// Actualizar notas
$stmt = $db->prepare(
    "UPDATE detalle_factura_espera SET res_notas = :notas WHERE id = :id"
);
$stmt->execute([':notas' => $notas, ':id' => $id_item]);

sendSuccess(['id_item' => $id_item, 'notas' => $notas]);
