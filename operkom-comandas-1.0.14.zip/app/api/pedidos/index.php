<?php
/**
 * GET /api/pedidos?docespera={docespera}
 * Retorna el pedido activo de una mesa con todos sus ítems.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

validateToken();

$docespera = trim($_GET['docespera'] ?? '');
if ($docespera === '') {
    sendError('Parámetro docespera requerido');
}

$db = getDB();

// Cabecera del pedido
$stmt = $db->prepare(
    "SELECT total FROM factura_espera WHERE docespera = :docespera LIMIT 1"
);
$stmt->execute([':docespera' => $docespera]);
$cabecera = $stmt->fetch();

// Si no existe el pedido, retorna vacío (no es error)
$total = $cabecera ? $cabecera['total'] : '0';

// Detalle de ítems
$stmt = $db->prepare(
    "SELECT id, idarticulo, articulo, pu, cantidad, totalp,
            iva, tfiscal, imp, pv, res_notas, res_imp_com, categoria_d,
            pv_original, res_comanda
       FROM detalle_factura_espera
      WHERE DocEspera = :docespera
      ORDER BY id ASC"
);
$stmt->execute([':docespera' => $docespera]);
$items = $stmt->fetchAll();

// Normalizar tipos numéricos
foreach ($items as &$item) {
    $item['id']       = (int) $item['id'];
    $item['cantidad'] = (string) $item['cantidad'];
}
unset($item);

sendSuccess([
    'docespera' => $docespera,
    'total'     => $total,
    'items'     => $items,
]);
