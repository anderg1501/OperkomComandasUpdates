<?php
/**
 * DELETE /api/pedidos/remover-item
 * Remueve un ítem del pedido. Requiere pos_remover = 1 en la sesión.
 *
 * Body JSON:
 *   docespera — clave del pedido
 *   id_item   — detalle_factura_espera.id (campo agregado con ALTER TABLE)
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendError('Método no permitido', 405);
}

$user = validateToken();

// Verificar permiso
if ((int) $user['pos_remover'] !== 1) {
    sendError('No tienes permiso para remover productos del pedido', 403);
}

$body      = getRequestBody();
$docespera = trim($body['docespera'] ?? '');
$id_item   = (int) ($body['id_item'] ?? 0);

if ($docespera === '' || $id_item <= 0) {
    sendError('Faltan campos requeridos: docespera, id_item');
}

$db = getDB();

// Verificar que el ítem pertenece a este pedido antes de eliminar
$stmt = $db->prepare(
    "SELECT id FROM detalle_factura_espera
      WHERE id = :id AND DocEspera = :docespera
      LIMIT 1"
);
$stmt->execute([':id' => $id_item, ':docespera' => $docespera]);
if (!$stmt->fetch()) {
    sendError('Ítem no encontrado en este pedido', 404);
}

// Eliminar ítem
$stmt = $db->prepare(
    "DELETE FROM detalle_factura_espera WHERE id = :id AND DocEspera = :docespera"
);
$stmt->execute([':id' => $id_item, ':docespera' => $docespera]);

// Recalcular total — compatible con formato inglés y colombiano
$stmtTotal = $db->prepare(
    "SELECT COALESCE(SUM(CAST(
        CASE WHEN pv LIKE '%,%'
             THEN REPLACE(REPLACE(pv, '.', ''), ',', '.')
             ELSE pv
        END AS DECIMAL(15,2))), 0)
       FROM detalle_factura_espera
      WHERE DocEspera = :docespera"
);
$stmtTotal->execute([':docespera' => $docespera]);
$total = number_format(floatval($stmtTotal->fetchColumn()), 2, ',', '.');

$db->prepare(
    "UPDATE factura_espera SET total = :total WHERE docespera = :docespera"
)->execute([':total' => $total, ':docespera' => $docespera]);

// Actualizar acumulado y pendiente en la mesa
$db->prepare(
    "UPDATE restaurant_detalle_mesas rdm
       JOIN restaurant_mesas_area rma ON rdm.id_area = rma.descripcion
        SET rdm.acumulado = :total,
            rdm.pendiente = :total_p
      WHERE CONCAT(rma.descripcion, '-', rdm.nombre) = :docespera"
)->execute([':total' => $total, ':total_p' => $total, ':docespera' => $docespera]);

sendSuccess([
    'id_item'      => $id_item,
    'total_pedido' => $total,
]);
