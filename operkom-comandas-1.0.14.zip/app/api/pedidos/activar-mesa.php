<?php
/**
 * POST /api/pedidos/activar-mesa
 * Activa una mesa: crea el registro en factura_espera (si no existe)
 * y marca la mesa como ocupada en restaurant_detalle_mesas.
 *
 * Body JSON:
 *   id_mesa        — id de restaurant_detalle_mesas
 *   id_area        — indicador del área (restaurant_mesas_area.indicador, varchar 10)
 *   indicador_area — siglas del área (restaurant_mesas_area.indicador)
 *   nombre_mesa    — nombre de la mesa (restaurant_detalle_mesas.nombre)
 *   estacion       — identificador del dispositivo
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$user = validateToken();
$body = getRequestBody();

$id_mesa        = trim($body['id_mesa']        ?? '');
$id_area        = trim($body['id_area']        ?? '');
$indicador_area = trim($body['indicador_area'] ?? '');
$nombre_mesa    = trim($body['nombre_mesa']    ?? '');

if ($id_mesa === '' || $id_area === '' || $indicador_area === '' || $nombre_mesa === '') {
    sendError('Faltan campos requeridos: id_mesa, id_area, indicador_area, nombre_mesa');
}

// Construir la clave de negocio del pedido
$docespera = $indicador_area . $nombre_mesa;

$db = getDB();

// ── Verificar si ya existe un pedido para esta mesa ───────────
$stmt = $db->prepare(
    "SELECT id, total FROM factura_espera WHERE docespera = :docespera LIMIT 1"
);
$stmt->execute([':docespera' => $docespera]);
$pedidoExistente = $stmt->fetch();

$esNuevo = false;

if (!$pedidoExistente) {
    // Cada comanda inicia a nombre del cliente genérico configurado en el
    // administrativo. El mesero se conserva en restaurant_detalle_mesas, no
    // en la cabecera de factura que posteriormente procesa facturación.
    $stmtCliente = $db->query(
        "SELECT ID_cliente, rif, nombres, direccion1
           FROM clientes
          WHERE UPPER(TRIM(nombres)) = 'CONSUMIDOR FINAL'
          ORDER BY id ASC
          LIMIT 1"
    );
    $cliente = $stmtCliente->fetch();
    if (!$cliente) {
        sendError('No existe el cliente CONSUMIDOR FINAL en la base de datos. Créalo antes de abrir comandas.', 503);
    }

    $rifCliente = trim((string) ($cliente['rif'] ?? ''));
    if ($rifCliente === '') {
        $rifCliente = trim((string) ($cliente['ID_cliente'] ?? ''));
    }

    // Crear nuevo registro de pedido con la cabecera que espera el módulo de
    // facturación. NFactura queda vacío hasta que el administrativo asigne el
    // consecutivo definitivo al facturar la comanda.
    $hora = date('H:i:s');
    $stmt = $db->prepare(
        "INSERT INTO factura_espera
            (fecha, hora, docespera, autobck, NFactura, rif, nombres, direccion,
             total, subtotal, impuesto, exento, servicio)
         VALUES
            (CURDATE(), :hora, :docespera, '1', '', :rif, :nombres, :direccion,
             '0,00', '0,00', '0,00', '0,00', '0,00')"
    );
    $stmt->execute([
        ':hora'      => $hora,
        ':docespera' => $docespera,
        ':rif'       => $rifCliente,
        ':nombres'   => trim((string) ($cliente['nombres'] ?? 'CONSUMIDOR FINAL')),
        ':direccion' => trim((string) ($cliente['direccion1'] ?? '')),
    ]);
    $esNuevo = true;
    $total   = '0';
} else {
    $total = $pedidoExistente['total'];
}

// ── Marcar mesa como ocupada ──────────────────────────────────
$acumSet = $esNuevo ? ", acumulado = '0,00', pendiente = '0,00'" : '';
$stmt = $db->prepare(
    "UPDATE restaurant_detalle_mesas
        SET status         = '2',
            id_mesero      = :id_mesero,
            fecha_activada = CURDATE(),
            hora_activada  = CURTIME()
            {$acumSet}
      WHERE id = :id_mesa"
);
$stmt->execute([
    ':id_mesero' => $user['id_vendedor'],
    ':id_mesa'   => $id_mesa,
]);

sendSuccess([
    'docespera' => $docespera,
    'es_nueva'  => $esNuevo,
    'total'     => $total,
]);
