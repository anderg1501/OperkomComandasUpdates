<?php
/**
 * DELETE /api/pedidos/liberar-mesa
 * Libera una mesa activada por error:
 *   – Elimina los ítems no comandados del pedido.
 *   – Elimina la cabecera del pedido (factura_espera).
 *   – Deja la mesa disponible (status = '0').
 *
 * Restricciones:
 *   – Solo el mesero asignado puede liberar su propia mesa.
 *   – No se puede liberar si ya hay ítems enviados a cocina (res_comanda = '1').
 *
 * Body JSON:
 *   id_mesa    — id de restaurant_detalle_mesas
 *   docespera  — clave de factura_espera / detalle_factura_espera
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendError('Método no permitido', 405);
}

$user = validateToken();
$body = getRequestBody();

$id_mesa   = trim($body['id_mesa']   ?? '');
$docespera = trim($body['docespera'] ?? '');

if ($id_mesa === '' || $docespera === '') {
    sendError('Faltan campos requeridos: id_mesa, docespera');
}

$db = getDB();

// ── Verificar que la mesa existe y pertenece al mesero actual ─
$stmt = $db->prepare(
    "SELECT id, id_mesero, status FROM restaurant_detalle_mesas WHERE id = :id LIMIT 1"
);
$stmt->execute([':id' => $id_mesa]);
$mesa = $stmt->fetch();

if (!$mesa) {
    sendError('Mesa no encontrada', 404);
}

if ((int) $mesa['status'] === 0) {
    sendError('La mesa ya está disponible', 400);
}

if ((string) $mesa['id_mesero'] !== (string) $user['id_vendedor']) {
    sendError('Solo el mesero asignado puede liberar esta mesa', 403);
}

// ── Verificar que no hay ítems ya enviados a cocina ───────────
$stmt = $db->prepare(
    "SELECT COUNT(*) AS cnt
       FROM detalle_factura_espera
      WHERE DocEspera = :docespera AND res_comanda = '1'"
);
$stmt->execute([':docespera' => $docespera]);
$row = $stmt->fetch();

if ((int) $row['cnt'] > 0) {
    sendError('No se puede liberar: hay ítems ya enviados a cocina. Contacta al administrador.', 409);
}

// ── Eliminar ítems del pedido ─────────────────────────────────
$stmt = $db->prepare(
    "DELETE FROM detalle_factura_espera WHERE DocEspera = :docespera"
);
$stmt->execute([':docespera' => $docespera]);

// ── Eliminar cabecera del pedido ──────────────────────────────
$stmt = $db->prepare(
    "DELETE FROM factura_espera WHERE docespera = :docespera"
);
$stmt->execute([':docespera' => $docespera]);

// ── Liberar la mesa ───────────────────────────────────────────
$stmt = $db->prepare(
    "UPDATE restaurant_detalle_mesas
        SET status         = '0',
            id_mesero      = NULL,
            fecha_activada = NULL,
            hora_activada  = NULL,
            acumulado      = '0',
            pendiente      = '0'
      WHERE id = :id_mesa"
);
$stmt->execute([':id_mesa' => $id_mesa]);

sendSuccess(['liberada' => true]);
