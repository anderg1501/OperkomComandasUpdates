<?php
/**
 * GET /api/notas?categoria={id_categoria}
 * Retorna las notas preestablecidas de una categoría.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

validateToken();

$categoria = trim($_GET['categoria'] ?? '');
if ($categoria === '') {
    sendError('Parámetro categoria requerido');
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id, notas
       FROM inventario_notasres
      WHERE vinculado = :categoria
      ORDER BY notas ASC"
);
$stmt->execute([':categoria' => $categoria]);
$notas = $stmt->fetchAll();

sendSuccess($notas);
