<?php
/**
 * POST /api/comandas/enviar
 * Agrupa los ítems NO comandados (res_comanda='0') por impresora,
 * envía cada ticket al servicio VB6 (puerto 9000) y marca res_comanda='1'
 * solo cuando la impresora confirma la recepción.
 *
 * Body JSON: { docespera, mesa_nombre }
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$user = validateToken();
$body = getRequestBody();

$docespera   = trim($body['docespera']   ?? '');
$mesa_nombre = trim($body['mesa_nombre'] ?? '');

if ($docespera === '') {
    sendError('Parámetro docespera requerido');
}

$db = getDB();

// ── Cabecera del pedido ───────────────────────────────────────
$stmt = $db->prepare(
    "SELECT vendedor FROM factura_espera WHERE docespera = :doc LIMIT 1"
);
$stmt->execute([':doc' => $docespera]);
$cabecera = $stmt->fetch();

if (!$cabecera) {
    sendError('Pedido no encontrado');
}

// ── Solo ítems NO comandados ──────────────────────────────────
$stmt = $db->prepare(
    "SELECT id, articulo, cantidad, res_notas, res_imp_com
       FROM detalle_factura_espera
      WHERE DocEspera = :doc
        AND res_comanda = '0'
      ORDER BY id ASC"
);
$stmt->execute([':doc' => $docespera]);
$items = $stmt->fetchAll();

if (empty($items)) {
    sendError('No hay ítems nuevos para comandar — todo ya fue enviado');
}

// Impresora opcional para duplicado de comanda completa (sin filtrar por categoría)
$impresoraComandaCompleta = '';
try {
    $stmt = $db->prepare(
        "SELECT comanda_impresora2
           FROM restaurant_configuracion
          LIMIT 1"
    );
    $stmt->execute();
    $cfg = $stmt->fetch();
    $impresoraComandaCompleta = trim($cfg['comanda_impresora2'] ?? '');
} catch (Throwable $e) {
    // Si esta configuración no existe en alguna BD, el flujo normal por categoría sigue funcionando.
    $impresoraComandaCompleta = '';
}

// ── Agrupar por impresora ─────────────────────────────────────
$grupos       = [];
$sinImpresora = 0;

foreach ($items as $item) {
    $imp = trim($item['res_imp_com'] ?? '');
    if ($imp === '') {
        $sinImpresora++;
        continue;
    }
    $grupos[$imp][] = $item;
}

if (empty($grupos)) {
    sendError('Ningún producto tiene impresora asignada (campo res_imp_com vacío)');
}

// Datos del ticket
$mesero      = (!empty($cabecera['vendedor'])) ? $cabecera['vendedor'] : $user['nombres'];
$hora        = date('H:i');
$mesa        = $docespera;
$enviados    = [];
$enviadosCategorias = [];
$advertencias = [];

if ($sinImpresora > 0) {
    if ($impresoraComandaCompleta !== '') {
        $advertencias[] = "{$sinImpresora} ítem(s) sin impresora por categoría: solo saldrán en impresora global";
    } else {
        $advertencias[] = "{$sinImpresora} ítem(s) sin impresora asignada no serán impresos";
    }
}

// ── Enviar un ticket por impresora ────────────────────────────
foreach ($grupos as $impresora => $itemsGrupo) {

    $payload = json_encode([
        'impresora' => $impresora,
        'mesa'      => $mesa,
        'mesero'    => $mesero,
        'hora'      => $hora,
        'items'     => array_values(array_map(function ($i) {
            return [
                'cantidad' => (int) $i['cantidad'],
                'articulo' => $i['articulo'],
                'notas'    => $i['res_notas'] ?? '',
            ];
        }, $itemsGrupo)),
    ]);

    $ok = enviarAlServicioDeImpresion($impresora, $payload);

    if ($ok) {
        // Marcar como comandado solo los ítems de esta impresora
        $ids          = array_column($itemsGrupo, 'id');
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $db->prepare(
            "UPDATE detalle_factura_espera SET res_comanda='1' WHERE id IN ({$placeholders})"
        )->execute($ids);

        $enviados[] = $impresora;
        $enviadosCategorias[] = $impresora;
    } else {
        $advertencias[] = "Sin respuesta de la impresora: {$impresora}";
    }
}

// Enviar copia completa a la impresora global de comanda (si está configurada)
if ($impresoraComandaCompleta !== '') {
    $payloadCompleto = json_encode([
        'impresora' => $impresoraComandaCompleta,
        'mesa'      => $mesa,
        'mesero'    => $mesero,
        'hora'      => $hora,
        'items'     => array_values(array_map(function ($i) {
            return [
                'cantidad' => (int) $i['cantidad'],
                'articulo' => $i['articulo'],
                'notas'    => $i['res_notas'] ?? '',
            ];
        }, $items)),
    ]);

    $okCompleto = enviarAlServicioDeImpresion($impresoraComandaCompleta, $payloadCompleto);
    if ($okCompleto) {
        $enviados[] = $impresoraComandaCompleta;
    } else {
        $advertencias[] = "Sin respuesta de la impresora global: {$impresoraComandaCompleta}";
    }
}

if (empty($enviadosCategorias)) {
    // Ninguna impresora respondió
    sendError($advertencias[0] ?? 'No se pudo conectar con ninguna impresora');
}

sendSuccess([
    'tickets_enviados' => count($enviados),
    'impresoras'       => $enviados,
    'advertencias'     => $advertencias,
]);

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════

/**
 * Envía el payload JSON al servicio VB6 en el puerto 9000.
 * El segundo argumento ($impresora) ya no se necesita para el payload
 * pero se mantiene por compatibilidad con la firma.
 */
function enviarAlServicioDeImpresion(string $impresora, string $payload): bool
{
    if (function_exists('curl_init')) {
        $ch = curl_init(PRINT_SERVICE_URL);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => PRINT_TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => 3,
        ]);
        $result   = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $result !== false && $httpCode >= 200 && $httpCode < 300;
    }

    // Fallback sin cURL
    $context = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: application/json\r\nContent-Length: " . strlen($payload),
            'content'       => $payload,
            'timeout'       => PRINT_TIMEOUT,
            'ignore_errors' => true,
        ],
    ]);
    $result = @file_get_contents(PRINT_SERVICE_URL, false, $context);
    return $result !== false;
}
