<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
require_once __DIR__ . '/update-helper.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

requireUpdateAdministrator();
$currentVersion = getCurrentAppVersion();

try {
    $manifest = fetchUpdateManifest();
    sendSuccess([
        'current_version' => $currentVersion,
        'available_version' => $manifest['version'],
        'update_available' => isUpdateAvailable($currentVersion, $manifest['version']),
    ]);
} catch (RuntimeException $e) {
    sendError($e->getMessage(), 503);
}
