<?php
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';
require_once __DIR__ . '/update-helper.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

requireUpdateAdministrator();
$currentVersion = getCurrentAppVersion();

try {
    $manifest = fetchUpdateManifest();
    if (!isUpdateAvailable($currentVersion, $manifest['version'])) {
        sendSuccess(['started' => false, 'message' => 'La aplicación ya está actualizada.']);
    }

    $scriptPath = dirname(__DIR__, 3) . '/updater/Update-OperkomComandas.ps1';
    if (!file_exists($scriptPath)) {
        sendError('El actualizador local no está instalado.', 500);
    }

    // El actualizador no puede ser hijo del proceso Apache: se detiene ese
    // servicio durante la instalación y Windows puede finalizar también a sus
    // procesos hijos. Programador de tareas lo ejecuta de forma independiente.
    $taskName = 'OperkomComandasUpdate';
    $powershellArguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' . $scriptPath . '"';
    $registrationScript = '$ErrorActionPreference = "Stop"; '
        . '$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument ' . var_export($powershellArguments, true) . '; '
        . '$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest; '
        . 'Register-ScheduledTask -TaskName "' . $taskName . '" -Action $action -Principal $principal -Force | Out-Null; '
        . 'Start-ScheduledTask -TaskName "' . $taskName . '";';
    $encodedScript = base64_encode(iconv('UTF-8', 'UTF-16LE', $registrationScript));
    $command = 'powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ' . $encodedScript;
    exec($command, $output, $exitCode);
    if ($exitCode !== 0) {
        sendError('No se pudo iniciar el actualizador independiente.', 500);
    }

    sendSuccess([
        'started' => true,
        'version' => $manifest['version'],
        'message' => 'La actualización se está instalando. La aplicación se recargará en unos segundos.',
    ]);
} catch (RuntimeException $e) {
    sendError($e->getMessage(), 503);
}
