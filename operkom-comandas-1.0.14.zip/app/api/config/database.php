<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/../helpers/config-helper.php';

/**
 * Retorna una instancia PDO singleton.
 * En caso de error de conexión responde JSON 500 y termina.
 */
function getDB(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    // Verificar que la configuración esté completa
    if (!isConfigured()) {
        http_response_code(503);
        echo json_encode([
            'success' => false,
            'error'   => 'Base de datos no configurada',
            'setup'   => '../setup.html',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
    );

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        http_response_code(500);
        // No revelar detalles internos del error
        $errorMsg = 'Error de conexión a la base de datos';
        if (getenv('APP_DEBUG')) {
            $errorMsg .= ': ' . $e->getMessage();
        }
        echo json_encode([
            'success' => false,
            'error'   => $errorMsg,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    return $pdo;
}
