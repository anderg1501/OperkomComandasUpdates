<?php
/**
 * Persistent configuration paths.
 * Client settings live outside the deployable application directory so code
 * updates cannot overwrite credentials or local preferences.
 */

function getPersistentDataDirectory(): string
{
    $configuredDirectory = getenv('OPERKOM_DATA_DIR');
    if (is_string($configuredDirectory) && trim($configuredDirectory) !== '') {
        return rtrim(trim($configuredDirectory), "\\/");
    }

    $programData = getenv('PROGRAMDATA') ?: getenv('ALLUSERSPROFILE');
    if (is_string($programData) && trim($programData) !== '') {
        return rtrim($programData, "\\/") . DIRECTORY_SEPARATOR . 'Operkom' . DIRECTORY_SEPARATOR . 'Comandas';
    }

    return __DIR__;
}

function getPersistentConfigPath(): string
{
    return getPersistentDataDirectory()
        . DIRECTORY_SEPARATOR . 'config'
        . DIRECTORY_SEPARATOR . 'config.local.php';
}

function getLegacyConfigPath(): string
{
    return __DIR__ . DIRECTORY_SEPARATOR . 'config.local.php';
}

function getLocalConfigPath(): string
{
    $persistentPath = getPersistentConfigPath();
    if (file_exists($persistentPath)) {
        return $persistentPath;
    }

    return getLegacyConfigPath();
}

function hasLocalConfig(): bool
{
    return file_exists(getLocalConfigPath());
}
