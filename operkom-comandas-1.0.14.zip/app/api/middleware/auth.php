<?php
require_once dirname(__DIR__) . '/config/config.php';

/**
 * Valida el token de sesión enviado en el header Authorization: Bearer {token}.
 * Si el token no existe, es inválido o expiró → responde 401 y termina.
 * Si es válido → retorna el array de datos del usuario de la sesión.
 */
function validateToken(): array
{
    $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';

    // Fallback 1: Apache con mod_rewrite puede renombrar el header
    if (empty($authHeader) && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $authHeader = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }

    // Fallback 2: XAMPP/Windows — Apache no siempre pasa Authorization a PHP
    // getallheaders() lo obtiene directamente de Apache sin importar la config
    if (empty($authHeader) && function_exists('getallheaders')) {
        $allHeaders = getallheaders();
        // Buscar case-insensitive
        foreach ($allHeaders as $name => $value) {
            if (strtolower($name) === 'authorization') {
                $authHeader = $value;
                break;
            }
        }
    }

    if (empty($authHeader) || stripos($authHeader, 'Bearer ') !== 0) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Token no proporcionado'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $token = substr($authHeader, 7);
    // Sanitizar: solo caracteres hex minúsculas, exactamente 64 caracteres
    $token = strtolower(preg_replace('/[^a-fA-F0-9]/', '', $token));

    if (strlen($token) !== 64) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Token con formato inválido'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $sessionFile = SESSION_PATH . $token . '.json';

    if (!file_exists($sessionFile)) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Sesión no encontrada o expirada'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Lectura rápida sin bloqueo exclusivo.
    // Solo adquirimos LOCK_EX si necesitamos escribir (last_access vencido).
    $raw     = file_get_contents($sessionFile);
    $session = $raw ? json_decode($raw, true) : null;

    if (!is_array($session) || time() > ($session['expires_at'] ?? 0)) {
        @unlink($sessionFile);
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Sesión expirada'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Actualizar last_access solo si han pasado más de 30 s — minimiza escrituras
    if (time() - ($session['last_access'] ?? 0) > 30) {
        $fh = fopen($sessionFile, 'r+');
        if ($fh !== false) {
            flock($fh, LOCK_EX);
            // Re-leer por si otro proceso escribió mientras esperábamos
            $raw2 = stream_get_contents($fh);
            $s2   = $raw2 ? json_decode($raw2, true) : $session;
            if (is_array($s2)) {
                $s2['last_access'] = time();
                rewind($fh);
                ftruncate($fh, 0);
                fwrite($fh, json_encode($s2));
            }
            flock($fh, LOCK_UN);
            fclose($fh);
        }
    }

    return $session['user'];
}
