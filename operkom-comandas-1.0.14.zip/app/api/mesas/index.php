<?php
/**
 * GET /api/mesas?id_area={descripcion_area}
 * Retorna las mesas de un área específica.
 * El parámetro id_area corresponde a restaurant_mesas_area.descripcion
 * (ej: 'SALON', 'TERRANOVA' — es el valor guardado en restaurant_detalle_mesas.id_area).
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

validateToken();

$id_area = trim($_GET['id_area'] ?? '');
if ($id_area === '') {
    sendError('Parámetro id_area requerido');
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT rm.id, rm.nombre, rm.status AS estatus, rm.acumulado, rm.pagado, rm.pendiente,
            rm.id_mesero, rm.id_area, rm.indx, rm.fecha_activada, rm.hora_activada,
            v.nombres AS nombre_mesero
       FROM restaurant_detalle_mesas rm
       LEFT JOIN vendedores v ON rm.id_mesero = v.id_vendedor
      WHERE rm.id_area = :id_area
      ORDER BY rm.indx ASC, rm.nombre ASC"
);
$stmt->execute([':id_area' => $id_area]);
$mesas = $stmt->fetchAll();

// Normalizar tipos
foreach ($mesas as &$mesa) {
    $mesa['estatus'] = (int) $mesa['estatus'];
}
unset($mesa);

sendSuccess($mesas);
