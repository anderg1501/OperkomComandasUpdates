<?php
/**
 * GET /api/mesas/areas
 * Retorna todas las áreas del restaurante.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

validateToken();

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id, descripcion, indicador, deposito, nmesas
       FROM restaurant_mesas_area
      ORDER BY id ASC"
);
$stmt->execute();
$areas = $stmt->fetchAll();

sendSuccess($areas);
