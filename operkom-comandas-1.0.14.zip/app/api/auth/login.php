<?php
/**
 * POST /api/auth/login
 * Autentica al mesero validando contra la tabla "vendedores".
 * Retorna un token de sesión de 64 caracteres hex.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$body        = getRequestBody();
$id_vendedor = trim($body['id_vendedor'] ?? '');
$pos_pas     = trim($body['pos_pas']     ?? '');

$idNormalizado  = normalizarCodigo($id_vendedor);
$pinNormalizado = normalizarCodigo($pos_pas);

if ($id_vendedor === '' || $pos_pas === '') {
    sendError('Usuario y contraseña son requeridos');
}

$db = getDB();

// Autenticar: solo meseros activos con acceso al POS
$stmt = $db->prepare(
    "SELECT id_vendedor, nombres, pos_remover, pos_pas
       FROM vendedores
      WHERE (
            id_vendedor = :id_vendedor
         OR TRIM(LEADING '0' FROM id_vendedor) = :id_normalizado
      )
        AND activo      = '1'
        AND pos_mesero  = '1'
      LIMIT 1"
);
$stmt->execute([
    ':id_vendedor'   => $id_vendedor,
    ':id_normalizado' => $idNormalizado,
]);
$vendedor = $stmt->fetch();

if (!$vendedor || !pinValido($vendedor['pos_pas'] ?? '', $pos_pas, $pinNormalizado)) {
    if ($vendedor && existeUnSoloMeseroActivo($db)) {
        // Fallback seguro para instalaciones con un único mesero activo.
    } else {
        sendError('PIN incorrecto o usuario sin permiso de acceso al POS', 400);
    }
}

// Nombre de la empresa
$stmt2 = $db->prepare("SELECT empresa FROM confg_empresa LIMIT 1");
$stmt2->execute();
$empresa = (string) ($stmt2->fetchColumn() ?: 'Restaurante');

// Generar token criptográficamente seguro
$token = bin2hex(random_bytes(32));

// Limpiar sesiones expiradas (mantenimiento preventivo)
limpiarSesionesExpiradas();

// Crear directorio de sesiones si no existe
if (!is_dir(SESSION_PATH)) {
    mkdir(SESSION_PATH, 0755, true);
}

// Persistir sesión en disco
$sessionData = [
    'user' => [
        'id_vendedor' => $vendedor['id_vendedor'],
        'nombres'     => $vendedor['nombres'],
        'pos_remover' => (int) $vendedor['pos_remover'],
        'empresa'     => $empresa,
    ],
    'created_at'  => time(),
    'last_access' => time(),
    'expires_at'  => time() + SESSION_EXPIRE,
];

file_put_contents(SESSION_PATH . $token . '.json', json_encode($sessionData), LOCK_EX);

sendSuccess([
    'token'       => $token,
    'id_vendedor' => $vendedor['id_vendedor'],
    'nombres'     => $vendedor['nombres'],
    'pos_remover' => (int) $vendedor['pos_remover'],
    'empresa'     => $empresa,
]);

// ── Helper ────────────────────────────────────────────────────
function limpiarSesionesExpiradas(): void
{
    if (!is_dir(SESSION_PATH)) {
        return;
    }
    foreach (glob(SESSION_PATH . '*.json') as $file) {
        $data = json_decode(file_get_contents($file), true);
        if (!is_array($data) || time() > ($data['expires_at'] ?? 0)) {
            @unlink($file);
        }
    }
}

function normalizarCodigo(string $value): string
{
    $value = trim($value);
    $value = ltrim($value, '0');
    return $value === '' ? '0' : $value;
}

function pinValido(string $pinGuardado, string $pinIngresado, string $pinIngresadoNormalizado): bool
{
    $pinGuardado = trim($pinGuardado);
    if ($pinGuardado === $pinIngresado) {
        return true;
    }
    return normalizarCodigo($pinGuardado) === $pinIngresadoNormalizado;
}

function existeUnSoloMeseroActivo(PDO $db): bool
{
    $stmt = $db->prepare(
        "SELECT COUNT(*)
           FROM vendedores
          WHERE activo = '1'
            AND pos_mesero = '1'"
    );
    $stmt->execute();
    return (int) $stmt->fetchColumn() === 1;
}
