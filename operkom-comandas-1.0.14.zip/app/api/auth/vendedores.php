<?php
/**
 * GET /api/auth/vendedores
 * Lista los meseros activos con acceso al POS (sin token — pantalla de login).
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

$db   = getDB();
$stmt = $db->prepare(
    "SELECT id_vendedor, nombres,
            (SELECT empresa FROM confg_empresa LIMIT 1) AS empresa
       FROM vendedores
      WHERE activo     = '1'
        AND pos_mesero = '1'
      ORDER BY nombres ASC"
);
$stmt->execute();
$vendedores = $stmt->fetchAll();

sendSuccess($vendedores);
