<?php
/**
 * GET /api/auth/administradores
 * Lista los usuarios que pueden autenticar cambios de configuración.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

$db = getDB();
$stmt = $db->prepare(
    "SELECT id_vendedor, nombres
      FROM vendedores
      WHERE activo = '1'
        AND pos_admin = '1'
        AND (pos_mesero <> '1' OR pos_mesero IS NULL)
      ORDER BY nombres ASC"
);
$stmt->execute();

sendSuccess($stmt->fetchAll());
