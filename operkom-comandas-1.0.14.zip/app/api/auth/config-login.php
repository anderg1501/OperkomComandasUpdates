<?php
/**
 * POST /api/auth/config-login
 * Autentica únicamente vendedores activos con pos_admin = 1.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$body       = getRequestBody();
$idVendedor = trim($body['id_vendedor'] ?? '');
$pin        = trim($body['pos_pas'] ?? '');

if ($idVendedor === '' || $pin === '') {
    sendError('Usuario y contraseña son requeridos');
}

$db = getDB();
$idNormalizado = normalizarCodigoConfiguracion($idVendedor);
$stmt = $db->prepare(
    "SELECT id_vendedor, nombres, pos_pas
       FROM vendedores
      WHERE (
            id_vendedor = :id_vendedor
         OR TRIM(LEADING '0' FROM id_vendedor) = :id_normalizado
      )
        AND activo = '1'
        AND pos_admin = '1'
        AND (pos_mesero <> '1' OR pos_mesero IS NULL)
      LIMIT 1"
);
$stmt->execute([
    ':id_vendedor' => $idVendedor,
    ':id_normalizado' => $idNormalizado,
]);
$admin = $stmt->fetch();

if (!$admin || !pinValidoConfiguracion((string) $admin['pos_pas'], $pin)) {
    sendError('PIN incorrecto o usuario sin permiso de configuración', 403);
}

limpiarSesionesConfiguracionExpiradas();
if (!is_dir(SESSION_PATH)) {
    mkdir(SESSION_PATH, 0755, true);
}

$token = bin2hex(random_bytes(32));
$sessionData = [
    'user' => [
        'id_vendedor' => $admin['id_vendedor'],
        'nombres' => $admin['nombres'],
        'pos_admin' => 1,
    ],
    'created_at' => time(),
    'last_access' => time(),
    'expires_at' => time() + SESSION_EXPIRE,
];
file_put_contents(SESSION_PATH . $token . '.json', json_encode($sessionData), LOCK_EX);

sendSuccess([
    'token' => $token,
    'id_vendedor' => $admin['id_vendedor'],
    'nombres' => $admin['nombres'],
]);

function normalizarCodigoConfiguracion(string $value): string
{
    $value = ltrim(trim($value), '0');
    return $value === '' ? '0' : $value;
}

function pinValidoConfiguracion(string $pinGuardado, string $pinIngresado): bool
{
    return trim($pinGuardado) === trim($pinIngresado)
        || normalizarCodigoConfiguracion($pinGuardado) === normalizarCodigoConfiguracion($pinIngresado);
}

function limpiarSesionesConfiguracionExpiradas(): void
{
    if (!is_dir(SESSION_PATH)) return;
    foreach (glob(SESSION_PATH . '*.json') as $file) {
        $session = json_decode(file_get_contents($file), true);
        if (!is_array($session) || time() > ($session['expires_at'] ?? 0)) {
            @unlink($file);
        }
    }
}
