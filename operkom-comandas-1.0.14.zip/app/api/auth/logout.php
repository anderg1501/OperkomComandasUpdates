<?php
/**
 * POST /api/auth/logout
 * Invalida el token de sesión del mesero.
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$authHeader = $_SERVER['HTTP_AUTHORIZATION']
           ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
           ?? '';

if (stripos($authHeader, 'Bearer ') === 0) {
    $token = strtolower(preg_replace('/[^a-fA-F0-9]/', '', substr($authHeader, 7)));
    if (strlen($token) === 64) {
        $file = SESSION_PATH . $token . '.json';
        if (file_exists($file)) {
            @unlink($file);
        }
    }
}

sendSuccess(['message' => 'Sesión cerrada correctamente']);
