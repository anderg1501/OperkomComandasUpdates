<?php
/**
 * Persistencia de opciones propias de Operkom Comandas.
 * Se mantiene separada de las tablas del ERP para no alterar su esquema.
 */

function ensureAppSettingsTable(PDO $db): void
{
    $db->exec(
        "CREATE TABLE IF NOT EXISTS operkom_comandas_configuracion (
            clave VARCHAR(80) NOT NULL PRIMARY KEY,
            valor VARCHAR(255) NOT NULL,
            actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    );
}

function getAppSetting(PDO $db, string $clave, ?string $default = null): ?string
{
    try {
        $stmt = $db->prepare(
            'SELECT valor FROM operkom_comandas_configuracion WHERE clave = :clave LIMIT 1'
        );
        $stmt->execute([':clave' => $clave]);
        $value = $stmt->fetchColumn();
        return $value === false ? $default : (string) $value;
    } catch (PDOException $e) {
        // Antes de la primera configuración, la tabla aún no existe.
        return $default;
    }
}

function getAppBooleanSetting(PDO $db, string $clave, bool $default = false): bool
{
    $value = getAppSetting($db, $clave, $default ? '1' : '0');
    return in_array(strtolower(trim((string) $value)), ['1', 'true', 'yes', 'si'], true);
}

function saveAppSetting(PDO $db, string $clave, string $valor): void
{
    ensureAppSettingsTable($db);
    $stmt = $db->prepare(
        "INSERT INTO operkom_comandas_configuracion (clave, valor)
         VALUES (:clave, :valor)
         ON DUPLICATE KEY UPDATE valor = VALUES(valor)"
    );
    $stmt->execute([':clave' => $clave, ':valor' => $valor]);
}
