<?php
/**
 * Funciones de utilidad compartidas por todos los endpoints de la API.
 */

/** Envía una respuesta JSON exitosa y termina la ejecución. */
function sendSuccess($data, int $code = 200): void
{
    http_response_code($code);
    echo json_encode(['success' => true, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Envía una respuesta JSON de error y termina la ejecución. */
function sendError(string $message, int $code = 400): void
{
    http_response_code($code);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Lee y decodifica el cuerpo JSON de la petición actual. */
function getRequestBody(): array
{
    $raw = file_get_contents('php://input');
    if (empty($raw)) {
        return [];
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/**
 * Convierte un color VB6 (entero decimal en formato BGR) al formato CSS #RRGGBB.
 * Retorna null si el valor está vacío o es cero.
 */
function vb6ColorToCss($vbColor): ?string
{
    if ($vbColor === null || $vbColor === '' || $vbColor === '0') {
        return null;
    }
    $num = intval($vbColor);
    if ($num === 0) {
        return null;
    }
    $b = ($num >> 16) & 0xFF;
    $g = ($num >> 8)  & 0xFF;
    $r = $num         & 0xFF;
    return sprintf('#%02x%02x%02x', $r, $g, $b);
}

/**
 * Calcula los valores fiscales de un ítem del pedido.
 * Todos los valores numéricos del ERP se almacenan como VARCHAR,
 * por eso se castean antes de operar.
 *
 * @param array $producto  Fila de inventario con exento, impuestov
 * @param float $pu        Precio unitario
 * @param int   $cantidad  Cantidad pedida
 * @return array  [iva, tfiscal, imp, pv, totalp]  — todos como string formateado
 */
function calcularImpuesto(array $producto, float $pu, int $cantidad): array
{
    $totalp = $pu * $cantidad;

    if ($producto['exento'] === '1') {
        $pv_fmt = number_format($totalp, 2, ',', '.');
        return [
            'iva'    => 'E',
            'tfiscal' => $pv_fmt,
            'imp'    => '0,00',
            'pv'     => $pv_fmt,
            'pvb'    => $pv_fmt,   // sin IVA → pvb = pv completo
            'totalp' => $pv_fmt,
        ];
    }

    $tasaPct = floatval($producto['impuestov']);
    $tasa    = $tasaPct > 0 ? $tasaPct / 100.0 : 0.0;
    $tfiscal = $tasa > 0 ? $totalp / (1 + $tasa) : $totalp;
    $imp     = $totalp - $tfiscal;

    return [
        'iva'    => $producto['impuestov'],
        'tfiscal' => number_format($tfiscal, 2, ',', '.'),
        'imp'    => number_format($imp, 2, ',', '.'),
        'pv'     => number_format($totalp, 2, ',', '.'),
        'pvb'    => number_format($tfiscal, 2, ',', '.'),  // base sin IVA
        'totalp' => number_format($totalp, 2, ',', '.'),
    ];
}
