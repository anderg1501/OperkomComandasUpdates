<?php
/**
 * helpers/config-helper.php
 * Funciones para validar y gestionar configuración de BD
 */

/**
 * Verifica si la configuración de BD está completa.
 * Retorna true si todos los datos están presentes, false si falta algo.
 */
function isConfigured(): bool
{
    return !empty(DB_HOST) && !empty(DB_NAME) && !empty(DB_USER);
}

/**
 * Si la configuración no está completa, retorna JSON con error
 * y redirige (o detiene) la ejecución.
 * 
 * Usar al inicio de endpoints que requieran BD.
 */
function requireConfig(): void
{
    if (!isConfigured()) {
        http_response_code(503);
        echo json_encode([
            'success' => false,
            'error'   => 'Base de datos no configurada. Accede al asistente de configuración.',
            'setup'   => '../setup.html',
        ]);
        exit;
    }
}

/**
 * Obtiene información de configuración (sin revelar contraseña).
 */
function getConfigInfo(): array
{
    return [
        'db_host'     => DB_HOST,
        'db_port'     => DB_PORT,
        'db_name'     => DB_NAME,
        'db_user'     => DB_USER,
        'is_configured' => isConfigured(),
    ];
}
