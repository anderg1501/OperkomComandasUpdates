<?php
/**
 * DELETE /api/pedidos/liberar-mesa
 * Libera una mesa y elimina sus ítems:
 *   – Requiere pos_limpiar y pos_remover si todos están pendientes.
 *   – Requiere pos_limpiar y pos_remitemcom si existe algún comandado.
 *   – Elimina la cabecera del pedido (factura_espera).
 *   – Deja la mesa disponible (status = '0').
 *
 * Restricciones:
 *   – Solo el mesero asignado puede liberar su propia mesa.
 *   – Si el mesero no tiene el permiso correspondiente, debe ingresarse la
 *     clave única de un usuario autorizado.
 *
 * Body JSON:
 *   id_mesa    — id de restaurant_detalle_mesas
 *   docespera  — clave de factura_espera / detalle_factura_espera
 *   autorizador_pin — clave opcional de autorización puntual
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    sendError('Método no permitido', 405);
}

$user = validateToken();
$body = getRequestBody();

$id_mesa   = trim($body['id_mesa']   ?? '');
$docespera = trim($body['docespera'] ?? '');
$autorizadorPin = trim($body['autorizador_pin'] ?? '');

if ($id_mesa === '' || $docespera === '') {
    sendError('Faltan campos requeridos: id_mesa, docespera');
}

$db = getDB();

// ── Verificar que la mesa existe y pertenece al mesero actual ─
$stmt = $db->prepare(
    "SELECT id, id_mesero, status FROM restaurant_detalle_mesas WHERE id = :id LIMIT 1"
);
$stmt->execute([':id' => $id_mesa]);
$mesa = $stmt->fetch();

if (!$mesa) {
    sendError('Mesa no encontrada', 404);
}

if ((int) $mesa['status'] === 0) {
    sendError('La mesa ya está disponible', 400);
}

if ((string) $mesa['id_mesero'] !== (string) $user['id_vendedor']) {
    sendError('Solo el mesero asignado puede liberar esta mesa', 403);
}

// ── Determinar el permiso según el estado real de los ítems ───
$stmt = $db->prepare(
    "SELECT COUNT(*) AS total_items,
            SUM(CASE WHEN res_comanda IS NOT NULL
                           AND res_comanda <> ''
                           AND res_comanda <> '0'
                     THEN 1 ELSE 0 END) AS comandados
       FROM detalle_factura_espera
      WHERE DocEspera = :docespera"
);
$stmt->execute([':docespera' => $docespera]);
$row = $stmt->fetch();

if ((int) ($row['total_items'] ?? 0) > 0) {
    $hayComandados = (int) ($row['comandados'] ?? 0) > 0;
    $permiso = $hayComandados ? 'pos_remitemcom' : 'pos_remover';
    $permisosRequeridos = [$permiso, 'pos_limpiar'];
    $descripcionPermiso = $hayComandados ? 'productos ya comandados' : 'productos pendientes por comandar';
    $sesionAutorizada = array_reduce(
        $permisosRequeridos,
        fn(bool $autorizada, string $nombrePermiso): bool => $autorizada && (int) ($user[$nombrePermiso] ?? 0) === 1,
        true
    );

    if (!$sesionAutorizada) {
        if ($autorizadorPin === '') {
            sendError("Se requiere autorización para limpiar una mesa con {$descripcionPermiso}", 403);
        }

        $pinNormalizado = normalizarClaveLiberarMesa($autorizadorPin);
        $stmt = $db->prepare(
            "SELECT id_vendedor, nombres, pos_pas, {$permiso}, pos_limpiar
               FROM vendedores
              WHERE activo = '1'
                AND (TRIM(pos_pas) = :pin
                  OR TRIM(LEADING '0' FROM TRIM(pos_pas)) = :pin_normalizado)
              LIMIT 1"
        );
        $stmt->execute([
            ':pin' => $autorizadorPin,
            ':pin_normalizado' => $pinNormalizado,
        ]);
        $autorizador = $stmt->fetch();

        if (!$autorizador || !claveValidaLiberarMesa((string) $autorizador['pos_pas'], $autorizadorPin)) {
            sendError('Clave de autorización incorrecta', 403);
        }
        $autorizadorTienePermisos = array_reduce(
            $permisosRequeridos,
            fn(bool $autorizada, string $nombrePermiso): bool => $autorizada && (int) ($autorizador[$nombrePermiso] ?? 0) === 1,
            true
        );
        if (!$autorizadorTienePermisos) {
            sendError("El usuario no cuenta con los permisos necesarios para limpiar productos: pos_limpiar y {$permiso}", 403);
        }
    }
}

// ── Eliminar ítems del pedido ─────────────────────────────────
$stmt = $db->prepare(
    "DELETE FROM detalle_factura_espera WHERE DocEspera = :docespera"
);
$stmt->execute([':docespera' => $docespera]);

// ── Eliminar cabecera del pedido ──────────────────────────────
$stmt = $db->prepare(
    "DELETE FROM factura_espera WHERE docespera = :docespera"
);
$stmt->execute([':docespera' => $docespera]);

// ── Liberar la mesa ───────────────────────────────────────────
$stmt = $db->prepare(
    "UPDATE restaurant_detalle_mesas
        SET status         = '0',
            id_mesero      = NULL,
            fecha_activada = NULL,
            hora_activada  = NULL,
            acumulado      = '0',
            pendiente      = '0'
      WHERE id = :id_mesa"
);
$stmt->execute([':id_mesa' => $id_mesa]);

sendSuccess(['liberada' => true]);

function normalizarClaveLiberarMesa(string $value): string
{
    $value = ltrim(trim($value), '0');
    return $value === '' ? '0' : $value;
}

function claveValidaLiberarMesa(string $claveGuardada, string $claveIngresada): bool
{
    $claveGuardada = trim($claveGuardada);
    $claveIngresada = trim($claveIngresada);
    return hash_equals($claveGuardada, $claveIngresada)
        || normalizarClaveLiberarMesa($claveGuardada) === normalizarClaveLiberarMesa($claveIngresada);
}
