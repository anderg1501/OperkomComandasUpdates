/**
 * mesas.js — Vista de selección de mesa.
 */

const MesasView = {
    _autoRefreshTimer: null,
    _autoRefreshMs: 15000,
    _isAutoRefreshing: false,
    _eventsBound: false,
    _areaRequestId: 0,
    _accessUrl: '',

    init() {
        const session = AppState.session;
        if (!session?.token) { Router.navigate('login'); return; }

        // Header
        document.getElementById('mesas-empresa').textContent = session.empresa || 'Restaurante';
        document.getElementById('mesas-vendedor').textContent = session.nombres.split(' ')[0];
        const hora = new Date().getHours();
        const saludo = hora < 12 ? 'Buenos días' : hora < 19 ? 'Buenas tardes' : 'Buenas noches';
        const saludoEl = document.getElementById('mesas-saludo');
        if (saludoEl) saludoEl.textContent = `${saludo}, ${session.nombres.split(' ')[0]}`;
        const iniciales = session.nombres
            .split(/\s+/)
            .filter(Boolean)
            .slice(0, 2)
            .map(nombre => nombre[0])
            .join('')
            .toUpperCase();
        const inicialesEl = document.getElementById('mesas-vendedor-iniciales');
        if (inicialesEl) inicialesEl.textContent = iniciales || 'ME';
        const logo = document.getElementById('mesas-logo');
        const headerLogo = document.getElementById('mesas-header-logo');
        const logoFallback = document.getElementById('mesas-logo-fallback');
        const logoUrl = Api.configuracion.logoUrl(Date.now());
        if (logo) {
            logo.classList.add('hidden');
            logoFallback?.classList.remove('hidden');
            logo.onload = () => {
                logo.classList.remove('hidden');
                logoFallback?.classList.add('hidden');
            };
            logo.onerror = () => {
                logo.classList.add('hidden');
                logoFallback?.classList.remove('hidden');
            };
            logo.src = logoUrl;
        }
        if (headerLogo) {
            headerLogo.classList.add('hidden');
            headerLogo.onload = () => headerLogo.classList.remove('hidden');
            headerLogo.onerror = () => headerLogo.classList.add('hidden');
            headerLogo.src = logoUrl;
        }

        this._bindEvents();
        this._loadAreas();
        this._startAutoRefresh();
        UpdateNotifier.start();
    },

    async _loadAreas({ preserveSelected = false } = {}) {
        try {
            const res = await Api.mesas.areas();
            if (!res.success) { Toast.show(res.error, 'error'); return; }
            if (!this._isActive()) return;

            AppState.areas = res.data;
            this._renderAreaTabs();

            const previousArea = preserveSelected ? AppState.area_seleccionada : null;
            const selectedArea = previousArea
                ? res.data.find(area => area.id === previousArea.id || area.descripcion === previousArea.descripcion)
                : null;

            // Seleccionar la primera área automáticamente o conservar la actual al refrescar.
            if (res.data.length > 0) {
                this._selectArea(selectedArea || res.data[0]);
            } else {
                document.getElementById('mesas-grid').innerHTML =
                    '<p class="col-span-full text-center text-slate-500 py-12">No hay áreas configuradas</p>';
            }
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    _renderAreaTabs() {
        const container = document.getElementById('areas-tabs');
        container.innerHTML = AppState.areas.map(area => `
            <button
                onclick="MesasView._selectArea(${JSON.stringify(area).replace(/"/g, '&quot;')})"
                id="tab-area-${area.id}"
                class="area-tab flex-shrink-0 px-5 py-2.5 rounded-xl text-sm font-semibold
                       transition-all duration-150">
                ${area.descripcion}
            </button>
        `).join('');
    },

    async _selectArea(area, { showLoading = true, silent = false } = {}) {
        const requestId = ++this._areaRequestId;
        AppState.area_seleccionada = area;

        // Actualizar tab activo
        document.querySelectorAll('.area-tab').forEach(t => {
            t.classList.remove('area-tab-active');
        });
        const tab = document.getElementById(`tab-area-${area.id}`);
        if (tab) { tab.classList.add('area-tab-active'); }

        if (showLoading) {
            document.getElementById('mesas-grid').innerHTML =
                '<div class="col-span-full flex justify-center py-12"><div class="loading-spinner"></div></div>';
        }

        try {
            const res = await Api.mesas.byArea(area.descripcion);
            if (!res.success) {
                if (!silent) Toast.show(res.error, 'error');
                return;
            }
            if (requestId !== this._areaRequestId || !this._isActive()) return;
            AppState.mesas = res.data;
            this._renderMesas(area);
        } catch (err) {
            if (!silent) Toast.show(err.message, 'error');
        }
    },

    _renderMesas(area) {
        const container = document.getElementById('mesas-grid');
        const session   = AppState.session;

        const libres = AppState.mesas.filter(mesa => mesa.estatus === 0 || mesa.estatus === '0').length;
        const mias = AppState.mesas.filter(mesa =>
            !(mesa.estatus === 0 || mesa.estatus === '0') && mesa.id_mesero === session.id_vendedor
        ).length;
        const ocupadas = AppState.mesas.length - libres;
        const summaryLibres = document.getElementById('summary-libres');
        const summaryOcupadas = document.getElementById('summary-ocupadas');
        const summaryMias = document.getElementById('summary-mias');
        if (summaryLibres) summaryLibres.textContent = libres;
        if (summaryOcupadas) summaryOcupadas.textContent = ocupadas;
        if (summaryMias) summaryMias.textContent = mias;
        this._updateAttentionSummary();

        if (!AppState.mesas.length) {
            container.innerHTML =
                '<p class="col-span-full text-center text-slate-500 py-12">No hay mesas en esta área</p>';
            return;
        }

        container.innerHTML = AppState.mesas.map(mesa => {
            const libre = mesa.estatus === 0 || mesa.estatus === '0';
            const esMia = !libre && mesa.id_mesero === session.id_vendedor;

            let stateClass, statusTxt, clickable = true;

            if (libre) {
                stateClass = 'table-card--free';
                statusTxt = 'Disponible';
            } else if (esMia) {
                stateClass = 'table-card--mine';
                statusTxt = 'Mi mesa';
            } else {
                stateClass = 'table-card--busy';
                statusTxt = 'Ocupada';
                clickable = false;
            }

            const clickAttr = clickable
                ? `onclick="MesasView._activarMesa(${JSON.stringify(mesa).replace(/"/g, '&quot;')})"`
                : '';

            const acum = parseFloat(mesa.acumulado || 0);
            const timerTxt = this._buildMesaTimer(mesa.fecha_activada, mesa.hora_activada);

            return `
                <div ${clickAttr}
                     class="table-card-v2 table-card-simple ${stateClass} ${clickable ? 'is-clickable' : ''}">
                    <div class="table-card-content">
                        <div class="table-shape" aria-hidden="true"><i></i><i></i><span></span><i></i><i></i></div>
                        <div class="table-card-copy">
                            <div class="table-card-heading">
                                <strong>${mesa.nombre}</strong>
                                <span class="table-status">${statusTxt}</span>
                            </div>
                            <div class="table-card-body">
                                <p>${libre ? 'Lista para recibir clientes' : (mesa.nombre_mesero || 'Mesa en servicio')}</p>
                                <div class="table-card-meta">
                                    ${esMia && acum > 0 ? `<strong class="table-amount">$${acum.toLocaleString('es-CO')}</strong>` : ''}
                                    ${timerTxt ? `<span class="table-time">${timerTxt}</span>` : ''}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    },

    async _activarMesa(mesa) {
        const area    = AppState.area_seleccionada;
        const session = AppState.session;

        try {
            const payload = {
                id_mesa:        mesa.id,
                id_area:        area.indicador,
                indicador_area: area.descripcion + '-',
                nombre_mesa:    mesa.nombre,
                estacion:       (navigator.userAgent.match(/Android|iPhone|iPad/i)
                                    ? 'Movil' : 'Web') + '-' + Date.now().toString(36).slice(-6),
            };

            const res = await Api.pedidos.activarMesa(payload);
            if (!res.success) { Toast.show(res.error, 'error'); return; }

            AppState.mesa_activa = {
                ...mesa,
                area,
                fecha_activada: res.data.fecha_activada || mesa.fecha_activada,
                hora_activada: res.data.hora_activada || mesa.hora_activada,
            };
            AppState.docespera   = res.data.docespera;

            if (!res.data.es_nueva) {
                // Recuperar ítems existentes del pedido
                const resPedido = await Api.pedidos.get(res.data.docespera);
                if (resPedido.success) {
                    AppState.pedido_items = resPedido.data.items;
                    AppState.pedido_total = resPedido.data.total;
                }
            } else {
                AppState.pedido_items = [];
                AppState.pedido_total = '0';
            }

            Router.navigate('pedido');

        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    async _confirmarLiberarMesa(mesa) {
        const area = AppState.area_seleccionada;
        const docespera = area.descripcion + '-' + mesa.nombre;

        const result = await Swal.fire({
            title: `Liberar mesa`,
            html: `<span class="operkom-swal-text">¿Liberar <strong class="operkom-swal-emphasis">${mesa.nombre}</strong>?</span><br><span class="operkom-swal-sub">Los ítems sin enviar a cocina serán eliminados.</span>`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: '🔓 Sí, liberar',
            cancelButtonText: 'Cancelar',
            buttonsStyling: false,
            customClass: {
                popup:         'operkom-swal-popup',
                title:         'operkom-swal-title',
                htmlContainer: 'operkom-swal-html',
                confirmButton: 'btn btn-primary',
                cancelButton:  'btn btn-danger',
            },
        });
        if (!result.isConfirmed) return;

        try {
            const res = await Api.pedidos.liberarMesa({
                id_mesa:   mesa.id,
                docespera: docespera,
            });
            if (!res.success) { Toast.show(res.error, 'error'); return; }
            Toast.show(`Mesa ${mesa.nombre} liberada`, 'success');
            this._selectArea(area);
        } catch (err) {
            Toast.show(err.message, 'error');
        }
    },

    _buildMesaTimer(fecha, hora) {
        const mins = this._getMesaElapsedMinutes(fecha, hora);
        if (mins === null) return '';
        return this._formatElapsedMinutes(mins);
    },

    _getMesaElapsedMinutes(fecha, hora) {
        if (!fecha || !hora) return null;
        try {
            const inicio = new Date(`${fecha}T${hora}`);
            if (Number.isNaN(inicio.getTime())) return null;
            const mins   = Math.floor((new Date() - inicio) / 60000);
            return Number.isFinite(mins) && mins >= 0 ? mins : null;
        } catch { return null; }
    },

    _formatElapsedMinutes(mins) {
        if (mins >= 1440) return 'Más de 24 h';
        if (mins < 60) return `${mins} min`;
        const h = Math.floor(mins / 60);
        const m = mins % 60;
        return m > 0 ? `${h} h ${m} min` : `${h} h`;
    },

    _updateAttentionSummary() {
        const attention = AppState.mesas
            .filter(mesa => !(mesa.estatus === 0 || mesa.estatus === '0'))
            .map(mesa => ({
                mesa,
                minutes: this._getMesaElapsedMinutes(mesa.fecha_activada, mesa.hora_activada),
            }))
            .filter(item => item.minutes !== null && item.minutes >= 45)
            .sort((a, b) => b.minutes - a.minutes);

        const card = document.getElementById('summary-attention');
        const title = document.getElementById('summary-attention-title');
        const detail = document.getElementById('summary-attention-detail');
        const badge = document.getElementById('summary-attention-badge');
        if (!card || !title || !detail || !badge) return;

        card.classList.toggle('has-alert', attention.length > 0);
        if (!attention.length) {
            title.textContent = 'Salón al día';
            detail.textContent = 'Sin mesas con espera mayor a 45 min';
            badge.textContent = 'AL DÍA';
            return;
        }

        const oldest = attention[0];
        title.textContent = `${attention.length} ${attention.length === 1 ? 'mesa lleva' : 'mesas llevan'} más de 45 min`;
        detail.textContent = `Mayor tiempo: ${oldest.mesa.nombre} · ${this._formatElapsedMinutes(oldest.minutes)}`;
        badge.textContent = 'REVISAR';
    },

    _bindEvents() {
        if (this._eventsBound) return;
        this._eventsBound = true;

        const btnLogout  = document.getElementById('btn-logout');
        const btnRefresh = document.getElementById('btn-refresh-mesas');
        const btnAccessQr = document.getElementById('btn-access-qr');

        btnLogout?.addEventListener('click',  () => this._logout());
        btnRefresh?.addEventListener('click', () => this._loadAreas({ preserveSelected: true }));
        btnAccessQr?.addEventListener('click', () => this._openAccessQr());
        document.getElementById('btn-close-access-qr')?.addEventListener('click', () => this._closeAccessQr());
        document.querySelector('[data-close-access-qr]')?.addEventListener('click', () => this._closeAccessQr());
        document.getElementById('btn-copy-access-url')?.addEventListener('click', () => this._copyAccessUrl());
        document.addEventListener('keydown', event => {
            if (event.key === 'Escape') this._closeAccessQr();
        });
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) this._refreshMesas();
        });
    },

    async _openAccessQr() {
        const modal = document.getElementById('access-qr-modal');
        const qrContainer = document.getElementById('access-qr-code');
        const loading = document.getElementById('access-qr-loading');
        const error = document.getElementById('access-qr-error');
        const urlInput = document.getElementById('access-qr-url');
        if (!modal || !qrContainer || !loading || !error || !urlInput) return;

        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('access-qr-open');
        document.getElementById('btn-close-access-qr')?.focus();
        qrContainer.innerHTML = '';
        qrContainer.classList.remove('is-ready');
        error.textContent = '';
        urlInput.value = '';
        loading.textContent = 'Preparando enlace…';
        loading.hidden = false;

        try {
            const response = await fetch(`${OperkomConfig.resolveApiBase()}/config/access-url.php`, {
                headers: { Accept: 'application/json' },
                cache: 'no-store',
            });
            const result = await response.json();
            if (!response.ok || !result.success || !result.data?.url) {
                throw new Error(result.error || 'No fue posible determinar la ruta de acceso.');
            }

            this._accessUrl = result.data.url;
            urlInput.value = this._accessUrl;
            if (typeof QRCode !== 'function') {
                throw new Error('No se pudo cargar el generador de QR. Puedes copiar el enlace manualmente.');
            }

            new QRCode(qrContainer, {
                text: this._accessUrl,
                width: 220,
                height: 220,
                colorDark: '#17392f',
                colorLight: '#ffffff',
                correctLevel: QRCode.CorrectLevel.M,
            });
            qrContainer.classList.add('is-ready');
            loading.hidden = true;
        } catch (err) {
            loading.hidden = true;
            error.textContent = err.message || 'No fue posible generar el código QR.';
        }
    },

    _closeAccessQr() {
        const modal = document.getElementById('access-qr-modal');
        if (!modal?.classList.contains('is-open')) return;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('access-qr-open');
        document.getElementById('btn-access-qr')?.focus();
    },

    async _copyAccessUrl() {
        if (!this._accessUrl) return;
        const button = document.getElementById('btn-copy-access-url');
        try {
            await navigator.clipboard.writeText(this._accessUrl);
        } catch {
            const input = document.getElementById('access-qr-url');
            input?.select();
            document.execCommand('copy');
        }
        if (button) {
            button.textContent = 'Copiado';
            window.setTimeout(() => { button.textContent = 'Copiar'; }, 1400);
        }
    },

    _isActive() {
        return AppState.vista_actual === 'mesas';
    },

    _startAutoRefresh() {
        this._stopAutoRefresh();
        this._autoRefreshTimer = window.setInterval(() => this._refreshMesas(), this._autoRefreshMs);
    },

    _stopAutoRefresh() {
        if (this._autoRefreshTimer !== null) {
            window.clearInterval(this._autoRefreshTimer);
            this._autoRefreshTimer = null;
        }
        this._isAutoRefreshing = false;
    },

    async _refreshMesas() {
        if (document.hidden || !this._isActive() || this._isAutoRefreshing) return;

        const area = AppState.area_seleccionada;
        if (!area) return;

        this._isAutoRefreshing = true;
        try {
            await this._selectArea(area, { showLoading: false, silent: true });
        } finally {
            this._isAutoRefreshing = false;
        }
    },

    async _logout() {
        this._stopAutoRefresh();
        try { await Api.auth.logout(); } catch { /* Continuar aunque falle */ }
        sessionStorage.removeItem('operkom_session');
        AppState.session = null;
        AppState.categorias = [];
        AppState.productos  = {};
        Router.navigate('login');
    },
};
