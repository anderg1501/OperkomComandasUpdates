<?php
/**
 * Acceso local de recuperación para Configuración.
 * PIN inicial: 2442. Solo se almacena el hash, nunca el PIN en texto plano.
 * Una instalación puede sobrescribir LOCAL_CONFIG_PIN_HASH desde config.local.php.
 */
if (!defined('LOCAL_CONFIG_PIN_HASH')) {
    define('LOCAL_CONFIG_PIN_HASH', '$2y$10$r6mr8C39r9rP0rmUEodY.OWbEH5NIsMO1MhTJngfqrgaQALwUTNMe');
}
