<?php
/** POST /api/auth/config-local-login — acceso administrativo sin MySQL. */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/local-admin.php';
require_once dirname(__DIR__) . '/helpers/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$clientIp = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'] ?? ($_SERVER['REMOTE_ADDR'] ?? ''))[0]);
$allowed = in_array($clientIp, ['127.0.0.1', '::1', 'localhost'], true);
$segments = defined('ALLOWED_SEGMENTS')
    ? array_filter(array_map('trim', explode(',', (string) ALLOWED_SEGMENTS)))
    : [];
foreach ($segments as $segment) {
    if ($segment !== '' && str_starts_with($clientIp, $segment . '.')) {
        $allowed = true;
        break;
    }
}
if (!$allowed) {
    sendError('El acceso local de configuración no está autorizado desde esta red', 403);
}

$body = getRequestBody();
$pin = trim((string) ($body['pin'] ?? ''));
if ($pin === '' || !password_verify($pin, LOCAL_CONFIG_PIN_HASH)) {
    usleep(500000);
    sendError('PIN local incorrecto', 403);
}

if (!is_dir(SESSION_PATH) && !mkdir(SESSION_PATH, 0750, true) && !is_dir(SESSION_PATH)) {
    sendError('No se pudo iniciar la sesión local', 500);
}

$token = bin2hex(random_bytes(32));
$sessionData = [
    'user' => [
        'id_vendedor' => '__LOCAL__',
        'nombres' => 'ADMINISTRADOR LOCAL',
        'pos_admin' => 1,
        'local_config' => 1,
    ],
    'created_at' => time(),
    'last_access' => time(),
    'expires_at' => time() + SESSION_EXPIRE,
];
if (file_put_contents(SESSION_PATH . $token . '.json', json_encode($sessionData), LOCK_EX) === false) {
    sendError('No se pudo guardar la sesión local', 500);
}

sendSuccess([
    'token' => $token,
    'id_vendedor' => '__LOCAL__',
    'nombres' => 'ADMINISTRADOR LOCAL',
]);
