<?php
/**
 * POST /api/pedidos/activar-mesa
 * Activa una mesa: crea el registro en factura_espera (si no existe)
 * y marca la mesa como ocupada en restaurant_detalle_mesas.
 *
 * Body JSON:
 *   id_mesa        — id de restaurant_detalle_mesas
 *   id_area        — indicador del área (restaurant_mesas_area.indicador, varchar 10)
 *   indicador_area — siglas del área (restaurant_mesas_area.indicador)
 *   nombre_mesa    — nombre de la mesa (restaurant_detalle_mesas.nombre)
 *   estacion       — identificador del dispositivo
 */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Método no permitido', 405);
}

$user = validateToken();
$body = getRequestBody();

$id_mesa        = trim($body['id_mesa']        ?? '');
$id_area        = trim($body['id_area']        ?? '');
$indicador_area = trim($body['indicador_area'] ?? '');
$nombre_mesa    = trim($body['nombre_mesa']    ?? '');

if ($id_mesa === '' || $id_area === '' || $indicador_area === '' || $nombre_mesa === '') {
    sendError('Faltan campos requeridos: id_mesa, id_area, indicador_area, nombre_mesa');
}

// Construir la clave de negocio del pedido
$docespera = $indicador_area . $nombre_mesa;

$db = getDB();

try {
// ── Verificar si ya existe un pedido para esta mesa ───────────
$stmt = $db->prepare(
    "SELECT id, total FROM factura_espera WHERE docespera = :docespera LIMIT 1"
);
$stmt->execute([':docespera' => $docespera]);
$pedidoExistente = $stmt->fetch();

$esNuevo = false;

if (!$pedidoExistente) {
    // Cada comanda inicia a nombre del cliente genérico configurado en el
    // administrativo. El mesero se conserva en restaurant_detalle_mesas, no
    // en la cabecera de factura que posteriormente procesa facturación.
    // Las bases de los clientes no siempre usan la misma llave interna
    // (algunas ni siquiera tienen la columna `id`). Se consultan los datos
    // disponibles sin depender de esa columna.
    $stmtCliente = $db->prepare(
        "SELECT *
           FROM clientes
          WHERE UPPER(TRIM(nombres)) = :nombre
          LIMIT 1"
    );
    $stmtCliente->execute([':nombre' => 'CONSUMIDOR FINAL']);
    $cliente = $stmtCliente->fetch();
    if (!$cliente) {
        sendError('No existe el cliente CONSUMIDOR FINAL en la base de datos. Créalo antes de abrir comandas.', 503);
    }

    $clienteNormalizado = array_change_key_case($cliente, CASE_LOWER);
    $rifCliente = trim((string) ($clienteNormalizado['rif'] ?? ''));
    if ($rifCliente === '') {
        $rifCliente = trim((string) ($clienteNormalizado['id_cliente'] ?? ''));
    }

    // Crear nuevo registro de pedido con la cabecera que espera el módulo de
    // facturación. Las instalaciones del administrativo no siempre tienen
    // exactamente las mismas columnas (por ejemplo, algunas no tienen
    // `direccion`), así que solo se incluyen los campos que existan.
    // NFactura queda vacío hasta que el administrativo asigne el consecutivo
    // definitivo al facturar la comanda.
    $hora = date('H:i:s');
    $camposFactura = [];
    foreach ($db->query('SHOW COLUMNS FROM factura_espera')->fetchAll() as $campo) {
        $nombreCampo = (string) ($campo['Field'] ?? '');
        if ($nombreCampo !== '') {
            $camposFactura[strtolower($nombreCampo)] = $nombreCampo;
        }
    }

    $valoresCabecera = [
        'fecha'     => ['CURDATE()', null],
        'hora'      => [':hora', $hora],
        'docespera' => [':docespera', $docespera],
        'autobck'   => ["'1'", null],
        'nfactura'  => ["''", null],
        'rif'       => [':rif', $rifCliente],
        'nombres'   => [':nombres', trim((string) ($clienteNormalizado['nombres'] ?? 'CONSUMIDOR FINAL'))],
        'direccion' => [':direccion', trim((string) ($clienteNormalizado['direccion1'] ?? $clienteNormalizado['direccion'] ?? ''))],
        'total'     => ["'0,00'", null],
        'subtotal'  => ["'0,00'", null],
        'impuesto'  => ["'0,00'", null],
        'exento'    => ["'0,00'", null],
        'servicio'  => ["'0,00'", null],
    ];

    $camposInsertar = [];
    $valoresInsertar = [];
    $parametrosInsertar = [];
    foreach ($valoresCabecera as $campoNormalizado => [$valorSql, $valorParametro]) {
        if (!isset($camposFactura[$campoNormalizado])) {
            continue;
        }

        $campoReal = str_replace('`', '``', $camposFactura[$campoNormalizado]);
        $camposInsertar[] = '`' . $campoReal . '`';
        $valoresInsertar[] = $valorSql;
        if ($valorParametro !== null) {
            $parametrosInsertar[$valorSql] = $valorParametro;
        }
    }

    foreach (['fecha', 'hora', 'docespera', 'autobck', 'total'] as $campoRequerido) {
        if (!isset($camposFactura[$campoRequerido])) {
            sendError('La tabla factura_espera no tiene el campo requerido: ' . $campoRequerido, 503);
        }
    }

    $stmt = $db->prepare(
        'INSERT INTO factura_espera (' . implode(', ', $camposInsertar) . ') VALUES (' . implode(', ', $valoresInsertar) . ')'
    );
    $stmt->execute($parametrosInsertar);
    $esNuevo = true;
    $total   = '0';
} else {
    $total = $pedidoExistente['total'];
}

// ── Marcar mesa como ocupada ──────────────────────────────────
$acumSet = $esNuevo ? ", acumulado = '0,00', pendiente = '0,00'" : '';
$stmt = $db->prepare(
    "UPDATE restaurant_detalle_mesas
        SET status         = '2',
            id_mesero      = :id_mesero,
            fecha_activada = CURDATE(),
            hora_activada  = CURTIME()
            {$acumSet}
      WHERE id = :id_mesa"
);
$stmt->execute([
    ':id_mesero' => $user['id_vendedor'],
    ':id_mesa'   => $id_mesa,
]);

$stmt = $db->prepare(
    'SELECT fecha_activada, hora_activada
       FROM restaurant_detalle_mesas
      WHERE id = :id_mesa
      LIMIT 1'
);
$stmt->execute([':id_mesa' => $id_mesa]);
$activacionMesa = $stmt->fetch() ?: [];
} catch (PDOException $e) {
    error_log('Error activando mesa: ' . $e->getMessage());
    sendError('No se pudo crear la comanda. Verifica la estructura y configuración de la base de datos.', 500);
}

sendSuccess([
    'docespera' => $docespera,
    'es_nueva'  => $esNuevo,
    'total'     => $total,
    'fecha_activada' => $activacionMesa['fecha_activada'] ?? null,
    'hora_activada'  => $activacionMesa['hora_activada'] ?? null,
]);
