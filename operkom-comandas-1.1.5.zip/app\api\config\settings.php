<?php
/**
 * GET/PATCH /api/config/settings
 * Opciones de Operkom Comandas, protegidas por vendedor administrador.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../helpers/response.php';
require_once __DIR__ . '/../helpers/app-settings.php';
require_once __DIR__ . '/../middleware/auth.php';

if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'PATCH'], true)) {
    sendError('Método no permitido', 405);
}

$user = validateToken(false);
if ((int) ($user['pos_admin'] ?? 0) !== 1) {
    sendError('Se requiere un usuario administrador para modificar la configuración', 403);
}

try {
    $db = getDB();
    ensureAppSettingsTable($db);
} catch (PDOException $e) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        sendSuccess([
            'agrupar_items' => false,
            'database_available' => false,
        ]);
    }
    sendError('No hay conexión con MySQL. Revisa la configuración del servidor.', 503);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    sendSuccess([
        'agrupar_items' => getAppBooleanSetting($db, 'agrupar_items', false),
        'database_available' => true,
    ]);
}

$body = getRequestBody();
if (!array_key_exists('agrupar_items', $body)) {
    sendError('Falta la opción agrupar_items');
}

$agruparItems = filter_var($body['agrupar_items'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
if ($agruparItems === null) {
    sendError('El valor de agrupar_items no es válido');
}

saveAppSetting($db, 'agrupar_items', $agruparItems ? '1' : '0');
sendSuccess(['agrupar_items' => $agruparItems]);
