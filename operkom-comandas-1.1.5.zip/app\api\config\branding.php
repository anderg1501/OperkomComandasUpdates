<?php
/** GET/PATCH /api/config/branding.php — color visual persistente de la aplicación. */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/config-paths.php';
require_once __DIR__ . '/../helpers/response.php';

function brandingFile(): string
{
    return getPersistentDataDirectory() . DIRECTORY_SEPARATOR . 'branding' . DIRECTORY_SEPARATOR . 'theme.json';
}

function currentBrandColor(): string
{
    $path = brandingFile();
    if (!is_file($path)) return '#164d3b';
    $data = json_decode((string) file_get_contents($path), true);
    $color = strtolower(trim((string) ($data['primary_color'] ?? '')));
    return preg_match('/^#[0-9a-f]{6}$/', $color) ? $color : '#164d3b';
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    sendSuccess(['primary_color' => currentBrandColor()]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'PATCH') sendError('Método no permitido', 405);
require_once __DIR__ . '/../middleware/auth.php';
$user = validateToken(false);
if ((int) ($user['pos_admin'] ?? 0) !== 1) sendError('Se requiere un usuario administrador', 403);

$body = getRequestBody();
$color = strtolower(trim((string) ($body['primary_color'] ?? '')));
if (!preg_match('/^#[0-9a-f]{6}$/', $color)) sendError('El color seleccionado no es válido');

$path = brandingFile();
$directory = dirname($path);
if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
    sendError('No se pudo crear el directorio de marca', 500);
}
if (file_put_contents($path, json_encode(['primary_color' => $color]), LOCK_EX) === false) {
    sendError('No se pudo guardar el color', 500);
}
sendSuccess(['primary_color' => $color]);
