<?php
/** GET /api/license/status.php — diagnóstico administrativo de licencia. */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/helpers/license.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendError('Método no permitido', 405);
}

$user = validateToken(false);
if ((int) ($user['pos_admin'] ?? 0) !== 1 && (int) ($user['local_config'] ?? 0) !== 1) {
    sendError('Se requiere acceso administrativo', 403);
}

$force = filter_var($_GET['refresh'] ?? false, FILTER_VALIDATE_BOOLEAN);
sendSuccess(getOperationalLicenseStatus($force));
