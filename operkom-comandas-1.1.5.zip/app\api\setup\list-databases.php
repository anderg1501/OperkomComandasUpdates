<?php
/** POST /api/setup/list-databases.php — prueba credenciales y lista bases disponibles. */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/response.php';

$allowedIps = ['127.0.0.1', '::1', 'localhost'];
$clientIp = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'] ?? ($_SERVER['REMOTE_ADDR'] ?? ''))[0]);
$allowed = in_array($clientIp, $allowedIps, true);
$segments = defined('ALLOWED_SEGMENTS') ? array_filter(array_map('trim', explode(',', (string) ALLOWED_SEGMENTS))) : [];
foreach ($segments as $segment) {
    if ($segment !== '' && str_starts_with($clientIp, $segment . '.')) $allowed = true;
}
if (!$allowed) sendError('Acceso no autorizado desde esta red', 403);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') sendError('Método no permitido', 405);

if (hasLocalConfig()) {
    require_once dirname(__DIR__) . '/middleware/auth.php';
    $user = validateToken(false);
    if ((int) ($user['local_config'] ?? 0) !== 1) sendError('Se requiere el PIN local de configuración', 403);
}

$body = getRequestBody();
$host = trim((string) ($body['db_host'] ?? ''));
$port = filter_var($body['db_port'] ?? 3306, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]);
$dbUser = trim((string) ($body['db_user'] ?? ''));
$password = (string) ($body['db_pass'] ?? '');
$keepPassword = filter_var($body['keep_db_pass'] ?? false, FILTER_VALIDATE_BOOLEAN);
if ($password === '' && $keepPassword && defined('DB_PASS')) $password = DB_PASS;

if ($host === '' || $port === false || $dbUser === '') sendError('Completa host, puerto y usuario');
if (!preg_match('/^[a-zA-Z0-9._:-]+$/', $host)) sendError('El host contiene caracteres inválidos');

try {
    $pdo = new PDO(
        "mysql:host={$host};port={$port};charset=utf8mb4",
        $dbUser,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NUM,
            PDO::ATTR_TIMEOUT => 5,
        ]
    );
    $excluded = ['information_schema', 'mysql', 'performance_schema', 'sys'];
    $databases = [];
    foreach ($pdo->query('SHOW DATABASES')->fetchAll() as $row) {
        $name = (string) ($row[0] ?? '');
        if ($name !== '' && !in_array(strtolower($name), $excluded, true)) $databases[] = $name;
    }
    natcasesort($databases);
    sendSuccess(['databases' => array_values($databases)]);
} catch (PDOException $e) {
    sendError('No fue posible conectar con esas credenciales. Verifica host, puerto, usuario y contraseña.', 422);
}
