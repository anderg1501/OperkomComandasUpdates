/**
 * config.js — Acceso y opciones administrativas de Operkom Comandas.
 */
const ConfigView = {
    _administradores: [],
    _adminSeleccionado: null,
    _pin: '',
    _token: null,
    _actualizacionPendiente: false,
    _logoObjectUrl: null,

    init() {
        this._administradores = [];
        this._adminSeleccionado = null;
        this._pin = '';
        this._token = null;
        this._revokeLogoObjectUrl();
        this._mostrarAdministradores();
    },

    _escapeHtml(text) {
        return String(text || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    },

    cerrar() {
        this._token = null;
        this._pin = '';
        Router.navigate('login');
    },

    solicitarActualizacion() {
        this._actualizacionPendiente = true;
        Router.navigate('config');
    },

    async _mostrarAdministradores() {
        const content = document.getElementById('config-content');
        if (!content) return;

        content.innerHTML = `
            <section class="config-panel">
                <div class="config-intro">
                    <span class="config-eyebrow">ACCESO RESTRINGIDO</span>
                    <h2>Configuración</h2>
                    <p>Selecciona un administrador e ingresa su PIN.</p>
                </div>
                <div id="config-admin-grid" class="config-admin-grid">
                    <div id="config-db-admins" class="config-admin-list-slot">
                        <div class="config-loading"><div class="loading-spinner"></div></div>
                    </div>
                </div>
                <div class="config-recovery-card">
                    <span class="config-section-title">RECUPERACIÓN DEL SERVIDOR</span>
                    <strong>Conexión a la base de datos</strong>
                    <p>Disponible aunque el servidor de datos no responda. El acceso está limitado a este equipo o a la red local autorizada.</p>
                    <button type="button" class="config-text-btn" onclick="ConfigView.abrirConexion()">Configurar conexión</button>
                </div>
            </section>`;

        try {
            const res = await Api.auth.administradores();
            if (!res.success) throw new Error(res.error || 'No fue posible cargar administradores');

            this._administradores = res.data || [];
            const grid = document.getElementById('config-db-admins');
            if (!grid) return;

            if (!this._administradores.length) {
                grid.innerHTML = `<p class="config-empty">No hay vendedores activos con permiso de administrador.</p>`;
                return;
            }

            grid.innerHTML = this._administradores.map((admin, index) => {
                const nombre = this._escapeHtml(admin.nombres);
                const initials = this._escapeHtml(String(admin.nombres || '').trim().split(/\s+/)
                    .map(word => word[0]).slice(0, 2).join('').toUpperCase());
                return `<button class="config-admin-btn" onclick="ConfigView.seleccionarAdministrador(${index})">
                    <span class="config-admin-avatar">${initials}</span>
                    <span>${nombre}</span>
                </button>`;
            }).join('');
        } catch (err) {
            const grid = document.getElementById('config-db-admins');
            if (grid) {
                grid.innerHTML = `<div class="config-empty">
                    <p>No se pudo cargar el acceso administrativo.</p>
                    <button class="config-text-btn" onclick="ConfigView._mostrarAdministradores()">Reintentar</button>
                </div>`;
            }
            console.error('[ConfigView] administradores:', err);
        }
    },

    seleccionarAdministrador(index) {
        const admin = this._administradores[index];
        if (!admin) return;

        this._adminSeleccionado = admin;
        this._pin = '';
        const content = document.getElementById('config-content');
        if (!content) return;

        content.innerHTML = `
            <section class="config-panel config-pin-panel">
                <button class="config-back-btn" onclick="ConfigView._mostrarAdministradores()" aria-label="Cambiar administrador">
                    ← Cambiar administrador
                </button>
                <div class="config-intro">
                    <span class="config-admin-avatar">${this._escapeHtml(String(admin.nombres || '').trim().split(/\s+/).map(word => word[0]).slice(0, 2).join('').toUpperCase())}</span>
                    <h2>${this._escapeHtml(admin.nombres)}</h2>
                    <p>Ingresa tu PIN de administrador.</p>
                </div>
                <div class="config-pin-dots" aria-label="PIN ingresado">
                    ${Array.from({ length: 6 }, (_, indexDot) => `<span class="config-pin-dot" data-index="${indexDot}"></span>`).join('')}
                </div>
                <div class="config-keypad">
                    ${['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(value => `<button onclick="ConfigView.pinKey('${value}')">${value}</button>`).join('')}
                    <button class="config-key-clear" onclick="ConfigView.pinKey('clear')">C</button>
                    <button onclick="ConfigView.pinKey('0')">0</button>
                    <button class="config-key-clear" onclick="ConfigView.pinKey('back')" aria-label="Borrar último dígito">←</button>
                </div>
                <button id="btn-config-login" class="config-primary-btn" onclick="ConfigView.ingresar()">INGRESAR</button>
            </section>`;
        this._actualizarPin();
    },

    pinKey(value) {
        if (value === 'clear') this._pin = '';
        else if (value === 'back') this._pin = this._pin.slice(0, -1);
        else if (this._pin.length < 20) this._pin += value;
        this._actualizarPin();
    },

    _actualizarPin() {
        document.querySelectorAll('.config-pin-dot').forEach((dot, index) => {
            dot.classList.toggle('is-filled', index < this._pin.length);
        });
    },

    async ingresar() {
        if (!this._adminSeleccionado || !this._pin) {
            Toast.show('Ingresa el PIN del administrador', 'error');
            return;
        }

        const button = document.getElementById('btn-config-login');
        button.disabled = true;
        button.textContent = 'VERIFICANDO...';

        try {
            const res = await Api.auth.loginConfiguracion(this._adminSeleccionado.id_vendedor, this._pin);
            if (!res.success) throw new Error(res.error || 'No fue posible validar el acceso');
            this._token = res.data.token;
            this._mostrarOpciones();
        } catch (err) {
            this._pin = '';
            this._actualizarPin();
            Toast.show(err.userMessage || err.message || 'PIN incorrecto', 'error');
        } finally {
            if (button?.isConnected) {
                button.disabled = false;
                button.textContent = 'INGRESAR';
            }
        }
    },

    async _mostrarOpciones() {
        const content = document.getElementById('config-content');
        if (!content || !this._token) return;

        content.innerHTML = `<section class="config-panel"><div class="config-loading"><div class="loading-spinner"></div></div></section>`;
        try {
            const res = await Api.configuracion.obtener(this._token);
            if (!res.success) throw new Error(res.error || 'No fue posible cargar la configuración');

            content.innerHTML = `
                <section class="config-panel">
                    <div class="config-intro config-intro-left">
                        <span class="config-eyebrow">ADMINISTRACIÓN</span>
                        <h2>Parámetros</h2>
                        <p>Administra las preferencias de operación y la identidad visual del sistema.</p>
                    </div>
                    <div class="config-section">
                        <span class="config-section-title">PEDIDOS</span>
                    <label class="config-setting-row" for="setting-agrupar-items">
                        <span>
                            <strong>Agrupar productos iguales</strong>
                            <small>Suma la cantidad en una sola línea cuando el producto no tiene notas y aún no ha sido enviado a cocina.</small>
                        </span>
                        <input id="setting-agrupar-items" type="checkbox" ${res.data.agrupar_items ? 'checked' : ''} ${res.data.database_available === false ? 'disabled' : ''}>
                        <span class="config-switch" aria-hidden="true"></span>
                    </label>
                    ${res.data.database_available === false ? '<p class="config-action-note">Esta preferencia estará disponible cuando se restablezca la conexión con MySQL.</p>' : ''}
                    <button id="btn-save-settings" class="config-primary-btn" onclick="ConfigView.guardar()" ${res.data.database_available === false ? 'disabled' : ''}>GUARDAR CAMBIOS</button>
                    </div>
                    <div class="config-section">
                        <span class="config-section-title">MARCA</span>
                        <div class="config-logo-row">
                            <div class="config-logo-preview">
                                <img id="config-logo-preview" src="${Api.configuracion.logoUrl(Date.now())}" alt="Logo actual">
                                <span>Sin logo</span>
                            </div>
                            <div class="config-logo-copy">
                                <strong>Logo de la empresa</strong>
                                <small>Se mostrará en la navegación de Mesas y junto al saludo en móvil. Usa PNG, JPG o WEBP de máximo 2 MB.</small>
                                <input id="setting-logo-file" type="file" accept="image/png,image/jpeg,image/webp">
                                <div class="config-logo-actions">
                                    <button id="btn-upload-logo" type="button" class="config-text-btn" onclick="ConfigView.subirLogo()">Cargar logo</button>
                                    <button type="button" class="config-text-btn config-text-danger" onclick="ConfigView.eliminarLogo()">Quitar</button>
                                </div>
                            </div>
                        </div>
                        <div class="config-color-row">
                            <div>
                                <strong>Color principal</strong>
                                <small>Se aplicará a la navegación, botones y elementos destacados de la aplicación.</small>
                            </div>
                            <div class="config-color-control">
                                <input id="setting-brand-color" type="color" value="${BrandTheme.color}" aria-label="Seleccionar color principal"
                                       oninput="document.getElementById('setting-brand-color-value').textContent=this.value.toUpperCase()">
                                <span id="setting-brand-color-value">${BrandTheme.color.toUpperCase()}</span>
                                <div class="config-color-actions">
                                    <button id="btn-save-brand-color" type="button" class="config-text-btn" onclick="ConfigView.guardarColorMarca()">Aplicar color</button>
                                    <button id="btn-reset-brand-color" type="button" class="config-text-btn" onclick="ConfigView.restablecerColorMarca()">Restablecer</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="config-section config-section-connection">
                        <span class="config-section-title">SISTEMA</span>
                        <div id="config-license-status" class="config-action-row">
                            <span class="config-action-icon" aria-hidden="true">◈</span>
                            <span class="config-action-content"><strong>Licencia remota</strong><small>Consultando estado...</small></span>
                        </div>
                        <button type="button" class="config-action-row" onclick="ConfigView.abrirConexion()">
                            <span class="config-action-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                    <ellipse cx="12" cy="5" rx="7" ry="3"></ellipse>
                                    <path d="M5 5v7c0 1.66 3.13 3 7 3s7-1.34 7-3V5M5 12v7c0 1.66 3.13 3 7 3s7-1.34 7-3v-7"></path>
                                </svg>
                            </span>
                            <span class="config-action-content">
                                <strong>Conexión a la base de datos</strong>
                                <small>${res.data.database_available === false ? 'MySQL no está disponible. Revisa o cambia los datos del servidor.' : 'Cambia el servidor, base de datos, usuario o contraseña.'}</small>
                            </span>
                            <span class="config-action-arrow" aria-hidden="true">›</span>
                        </button>
                        <button id="btn-check-update" type="button" class="config-action-row" onclick="ConfigView.buscarActualizacion()">
                            <span class="config-action-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                    <path d="M20 11a8.1 8.1 0 0 0-15.5-2M4 5v4h4M4 13a8.1 8.1 0 0 0 15.5 2M20 19v-4h-4"></path>
                                </svg>
                            </span>
                            <span class="config-action-content">
                                <strong>Buscar actualización</strong>
                                <small>Descarga e instala la versión más reciente sin modificar la configuración local.</small>
                            </span>
                            <span class="config-action-arrow" aria-hidden="true">›</span>
                        </button>
                    </div>
                    </section>`;

            this._bindLogoPreview();
            this._cargarLicencia(false);

            if (this._actualizacionPendiente) {
                this._actualizacionPendiente = false;
                setTimeout(() => this.buscarActualizacion(), 0);
            }
        } catch (err) {
            content.innerHTML = `<section class="config-panel config-empty">
                <p>No se pudo cargar la configuración.</p>
                <button class="config-text-btn" onclick="ConfigView._mostrarOpciones()">Reintentar</button>
            </section>`;
            console.error('[ConfigView] opciones:', err);
        }
    },

    async guardar() {
        const toggle = document.getElementById('setting-agrupar-items');
        const button = document.getElementById('btn-save-settings');
        if (!toggle || !button || !this._token) return;

        button.disabled = true;
        button.textContent = 'GUARDANDO...';
        try {
            const res = await Api.configuracion.guardar(this._token, {
                agrupar_items: toggle.checked,
            });
            if (!res.success) throw new Error(res.error || 'No fue posible guardar los cambios');
            Toast.show('Configuración guardada', 'success');
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No fue posible guardar', 'error');
        } finally {
            button.disabled = false;
            button.textContent = 'GUARDAR CAMBIOS';
        }
    },

    async _cargarLicencia(refresh = false) {
        const container = document.getElementById('config-license-status');
        if (!container || !this._token) return;

        if (refresh) {
            container.querySelector('small').textContent = 'Comprobando con el servidor remoto...';
        }

        try {
            const res = await Api.licencia.estado(this._token, refresh);
            const license = res.data || {};
            const labels = {
                active: 'Activa', blocked: 'Bloqueada', expired: 'Vencida',
                grace: 'Período de gracia', offline: 'Sin conexión · activa localmente', unreachable: 'Sin conexión',
                unconfigured: 'Pendiente de configurar', unknown: 'Sin estado',
            };
            const label = labels[license.status] || license.status || 'Sin estado';
            const last = license.last_success_at
                ? ` Última validación: ${new Date(license.last_success_at).toLocaleString('es-CO')}.`
                : '';
            container.innerHTML = `
                <span class="config-action-icon" aria-hidden="true">${license.allowed ? '✓' : '!'}</span>
                <span class="config-action-content">
                    <strong>Licencia remota · ${this._escapeHtml(label)}</strong>
                    <small>${this._escapeHtml(license.message || '')}${this._escapeHtml(last)}</small>
                </span>
                <button type="button" class="config-text-btn" onclick="ConfigView._cargarLicencia(true)">Validar ahora</button>`;
        } catch (err) {
            container.querySelector('small').textContent = err.userMessage || err.message || 'No fue posible consultar la licencia.';
        }
    },

    async abrirConexion() {
        const result = await Swal.fire({
            title: 'Conexión a la base de datos',
            text: 'Ingresa el PIN local de configuración.',
            input: 'password',
            inputAttributes: { inputmode: 'numeric', autocomplete: 'current-password' },
            showCancelButton: true,
            confirmButtonText: 'Continuar',
            cancelButtonText: 'Cancelar',
            buttonsStyling: false,
            customClass: {
                popup: 'operkom-swal-popup',
                title: 'operkom-swal-title',
                confirmButton: 'btn btn-primary',
                cancelButton: 'btn btn-secondary',
            },
            inputValidator: value => value?.trim() ? undefined : 'Ingresa el PIN local',
        });
        if (!result.isConfirmed) return;

        try {
            const res = await Api.auth.loginConfiguracionLocal(result.value.trim());
            if (!res.success) throw new Error(res.error || 'PIN local incorrecto');
            sessionStorage.setItem('operkom_setup_token', res.data.token);
            window.location.href = 'setup.html?edit=1';
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'PIN local incorrecto', 'error');
        }
    },

    async subirLogo() {
        const input = document.getElementById('setting-logo-file');
        const button = document.getElementById('btn-upload-logo');
        const file = input?.files?.[0];
        if (!file || !this._token) {
            Toast.show('Selecciona un archivo de imagen', 'error');
            return;
        }
        if (button) {
            button.disabled = true;
            button.textContent = 'Cargando...';
        }
        try {
            const res = await Api.configuracion.subirLogo(this._token, file);
            if (!res.success) throw new Error(res.error || 'No se pudo guardar el logo');
            this._revokeLogoObjectUrl();
            await this._loadLogoPreview(Api.configuracion.logoUrl(res.data?.version || Date.now()));
            input.value = '';
            this._refreshVisibleLogos();
            Toast.show('Logo actualizado', 'success');
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No se pudo cargar el logo', 'error');
        } finally {
            if (button) {
                button.disabled = false;
                button.textContent = 'Cargar logo';
            }
        }
    },

    async eliminarLogo() {
        if (!this._token) return;
        try {
            const res = await Api.configuracion.eliminarLogo(this._token);
            if (!res.success) throw new Error(res.error || 'No se pudo quitar el logo');
            const preview = document.getElementById('config-logo-preview');
            if (preview) {
                preview.style.display = 'none';
                preview.parentElement?.classList.remove('has-logo');
            }
            this._revokeLogoObjectUrl();
            const input = document.getElementById('setting-logo-file');
            if (input) input.value = '';
            this._refreshVisibleLogos(true);
            Toast.show('Logo eliminado', 'success');
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No se pudo quitar el logo', 'error');
        }
    },

    _bindLogoPreview() {
        const input = document.getElementById('setting-logo-file');
        const preview = document.getElementById('config-logo-preview');
        if (!input || !preview) return;

        preview.addEventListener('load', () => {
            preview.style.display = '';
            preview.parentElement?.classList.add('has-logo');
        });
        preview.addEventListener('error', () => {
            preview.style.display = 'none';
            preview.parentElement?.classList.remove('has-logo');
        });
        input.addEventListener('change', () => {
            const file = input.files?.[0];
            this._revokeLogoObjectUrl();
            if (!file) return;
            this._logoObjectUrl = URL.createObjectURL(file);
            preview.style.display = '';
            preview.src = this._logoObjectUrl;
        });
    },

    _loadLogoPreview(url) {
        const preview = document.getElementById('config-logo-preview');
        if (!preview) return Promise.resolve();
        return new Promise((resolve, reject) => {
            preview.onload = () => {
                preview.style.display = '';
                preview.parentElement?.classList.add('has-logo');
                resolve();
            };
            preview.onerror = () => {
                preview.style.display = 'none';
                preview.parentElement?.classList.remove('has-logo');
                reject(new Error('El servidor guardó el archivo, pero no pudo volver a mostrarlo.'));
            };
            preview.src = url;
        });
    },

    _revokeLogoObjectUrl() {
        if (!this._logoObjectUrl) return;
        URL.revokeObjectURL(this._logoObjectUrl);
        this._logoObjectUrl = null;
    },

    _refreshVisibleLogos(remove = false) {
        const targets = [
            ['login-company-logo', 'login-logo-fallback'],
            ['mesas-logo', 'mesas-logo-fallback'],
            ['mesas-header-logo', null],
            ['pedido-logo', 'pedido-logo-fallback'],
        ];
        const url = Api.configuracion.logoUrl(Date.now());
        targets.forEach(([imageId, fallbackId]) => {
            const image = document.getElementById(imageId);
            const fallback = fallbackId ? document.getElementById(fallbackId) : null;
            if (!image) return;
            if (remove) {
                image.classList.add('hidden');
                fallback?.classList.remove('hidden');
                image.removeAttribute('src');
                return;
            }
            image.onload = () => {
                image.classList.remove('hidden');
                fallback?.classList.add('hidden');
            };
            image.onerror = () => {
                image.classList.add('hidden');
                fallback?.classList.remove('hidden');
            };
            image.src = url;
        });
    },

    async guardarColorMarca() {
        const input = document.getElementById('setting-brand-color');
        const button = document.getElementById('btn-save-brand-color');
        if (!input || !button || !this._token) return;
        button.disabled = true;
        button.textContent = 'Aplicando...';
        try {
            const res = await Api.configuracion.guardarMarca(this._token, input.value);
            if (!res.success) throw new Error(res.error || 'No se pudo guardar el color');
            BrandTheme.apply(res.data.primary_color);
            Toast.show('Color de la aplicación actualizado', 'success');
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No se pudo guardar el color', 'error');
        } finally {
            button.disabled = false;
            button.textContent = 'Aplicar color';
        }
    },

    async restablecerColorMarca() {
        const input = document.getElementById('setting-brand-color');
        const value = document.getElementById('setting-brand-color-value');
        const button = document.getElementById('btn-reset-brand-color');
        if (!input || !button || !this._token) return;
        button.disabled = true;
        button.textContent = 'Restableciendo...';
        try {
            const res = await Api.configuracion.guardarMarca(this._token, BrandTheme.defaultColor);
            if (!res.success) throw new Error(res.error || 'No se pudo restablecer el color');
            input.value = BrandTheme.defaultColor;
            if (value) value.textContent = BrandTheme.defaultColor.toUpperCase();
            BrandTheme.apply(BrandTheme.defaultColor);
            Toast.show('Color predeterminado restaurado', 'success');
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No se pudo restablecer el color', 'error');
        } finally {
            button.disabled = false;
            button.textContent = 'Restablecer';
        }
    },

    async buscarActualizacion() {
        if (!this._token) return;

        const button = document.getElementById('btn-check-update');
        if (button) button.disabled = true;

        try {
            const status = await Api.actualizaciones.estado(this._token);
            if (!status.success) throw new Error(status.error || 'No fue posible comprobar actualizaciones');

            if (!status.data.update_available) {
                Toast.show(`La aplicación ya está actualizada (v${status.data.current_version}).`, 'success');
                return;
            }

            const confirmacion = window.confirm(
                `Hay una actualización disponible (v${status.data.available_version}). ` +
                'La aplicación se reiniciará durante unos segundos. ¿Deseas instalarla ahora?'
            );
            if (!confirmacion) return;

            const result = await Api.actualizaciones.iniciar(this._token);
            if (!result.success || !result.data.started) {
                throw new Error(result.error || result.data?.message || 'No se pudo iniciar la actualización');
            }

            Toast.show('Actualización iniciada. La aplicación se recargará en unos segundos.', 'success');
            setTimeout(() => window.location.reload(), 8000);
        } catch (err) {
            Toast.show(err.userMessage || err.message || 'No fue posible actualizar la aplicación', 'error');
        } finally {
            if (button?.isConnected) button.disabled = false;
        }
    },
};
