<?php
/** GET /api/setup/access.php — valida una autorización local para editar la conexión. */
require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/helpers/response.php';
require_once dirname(__DIR__) . '/middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') sendError('Método no permitido', 405);
$user = validateToken(false);
if ((int) ($user['local_config'] ?? 0) !== 1) {
    sendError('Se requiere el PIN local de configuración', 403);
}
sendSuccess(['authorized' => true]);
