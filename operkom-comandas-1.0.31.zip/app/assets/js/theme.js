/* theme.js - gestor de tema global (solo estado) */

const ThemeToggle = {
    _key: 'operkom_theme',

    init() {
        const saved = localStorage.getItem(this._key) || 'light';
        this.apply(saved);
    },

    toggle() {
        const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
        const next = current === 'dark' ? 'light' : 'dark';
        this.apply(next);
        localStorage.setItem(this._key, next);
    },

    apply(theme) {
        const html = document.documentElement;
        html.setAttribute('data-theme', theme);
        html.classList.toggle('dark', theme === 'dark');
        this._updateMetaThemeColor(theme);
        this._updateIcons(theme);
    },

    _updateMetaThemeColor(theme) {
        const meta = document.querySelector('meta[name="theme-color"]');
        if (!meta) return;
        meta.setAttribute('content', theme === 'dark' ? '#031D33' : '#005190');
    },

    _updateIcons(theme) {
        document.querySelectorAll('.theme-icon-sun').forEach(el => {
            el.classList.toggle('hidden', theme === 'light');
        });
        document.querySelectorAll('.theme-icon-moon').forEach(el => {
            el.classList.toggle('hidden', theme === 'dark');
        });
    },
};

const BrandTheme = {
    defaultColor: '#164d3b',
    color: '#164d3b',

    async init() {
        try {
            const result = await Api.configuracion.marca();
            if (result.success) this.apply(result.data.primary_color);
        } catch (err) {
            console.warn('[BrandTheme] No se pudo cargar el color de marca:', err);
        }
    },

    apply(color) {
        if (!/^#[0-9a-f]{6}$/i.test(color || '')) return;
        this.color = color.toLowerCase();
        const root = document.documentElement;
        root.style.setProperty('--brand-primary', this.color);
        root.style.setProperty('--brand-secondary', this.color);
        root.style.setProperty('--btn-primary-bg', this.color);
        root.style.setProperty('--table-head-bg', this.color);
        root.style.setProperty('--modal-header-bg', this.color);
        root.style.setProperty('--btn-primary-hover', `color-mix(in srgb, ${this.color} 82%, black)`);

        const rgb = this.color.slice(1).match(/.{2}/g).map(value => parseInt(value, 16));
        const luminance = (0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]) / 255;
        root.style.setProperty('--brand-on-primary', luminance > 0.62 ? '#17221e' : '#ffffff');
    },
};

// Aplicar tema temprano para evitar parpadeo inicial.
(function bootstrapTheme() {
    const saved = localStorage.getItem('operkom_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    document.documentElement.classList.toggle('dark', saved === 'dark');
})();
