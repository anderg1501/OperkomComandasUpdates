<?php
/**
 * GET    /api/config/logo.php  Entrega el logo local de la empresa.
 * POST   /api/config/logo.php  Reemplaza el logo (administrador).
 * DELETE /api/config/logo.php  Elimina el logo (administrador).
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/config-paths.php';
require_once __DIR__ . '/../helpers/response.php';

function logoDirectory(): string
{
    return getPersistentDataDirectory() . DIRECTORY_SEPARATOR . 'branding';
}

function findLogoFile(): ?string
{
    foreach (['png', 'jpg', 'jpeg', 'webp'] as $extension) {
        $path = logoDirectory() . DIRECTORY_SEPARATOR . 'company-logo.' . $extension;
        if (is_file($path)) return $path;
    }
    return null;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $path = findLogoFile();
    if (!$path) {
        $assetDirectory = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'img';
        $path = $assetDirectory . DIRECTORY_SEPARATOR . 'logo-1.png';
    }
    if (!$path || !is_file($path)) {
        http_response_code(404);
        exit;
    }
    $mime = str_ends_with(strtolower($path), '.svg')
        ? 'image/svg+xml'
        : (mime_content_type($path) ?: 'application/octet-stream');
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: public, max-age=300');
    readfile($path);
    exit;
}

require_once __DIR__ . '/../middleware/auth.php';
$user = validateToken();
if ((int) ($user['pos_admin'] ?? 0) !== 1) {
    sendError('Se requiere un usuario administrador para modificar el logo', 403);
}

if ($method === 'DELETE') {
    $existing = findLogoFile();
    if ($existing && !@unlink($existing)) {
        sendError('No se pudo eliminar el logo');
    }
    sendSuccess(['logo_url' => null]);
}

if ($method !== 'POST') sendError('Método no permitido', 405);
if (!isset($_FILES['logo']) || !is_uploaded_file($_FILES['logo']['tmp_name'])) {
    sendError('Selecciona un archivo de imagen');
}

$file = $_FILES['logo'];
if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    sendError('No se pudo recibir el archivo');
}
if (($file['size'] ?? 0) > 2 * 1024 * 1024) {
    sendError('El logo no puede superar 2 MB');
}

$imageInfo = @getimagesize($file['tmp_name']);
$mime = $imageInfo['mime'] ?? '';
$extensions = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp'];
if (!isset($extensions[$mime])) {
    sendError('Formato no permitido. Usa PNG, JPG o WEBP');
}

$directory = logoDirectory();
if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
    sendError('No se pudo crear el directorio del logo');
}
foreach (glob($directory . DIRECTORY_SEPARATOR . 'company-logo.*') ?: [] as $oldFile) {
    @unlink($oldFile);
}

$destination = $directory . DIRECTORY_SEPARATOR . 'company-logo.' . $extensions[$mime];
if (!move_uploaded_file($file['tmp_name'], $destination)) {
    sendError('No se pudo guardar el logo');
}
@chmod($destination, 0640);

sendSuccess(['logo_url' => 'api/config/logo.php?v=' . time()]);
